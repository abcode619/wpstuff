<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'appointment');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'r/%-GMk~8!*|N+w=2Vg)+wh:ep|#l@1&D_5CNW`zj})X4+{Ep-sh.5A++frQ>/@g');
define('SECURE_AUTH_KEY',  'd;XZ@Yi%#-It:5=ih1`6:pSt@RBXdb6.eDpQ)~|{8*AZ.V9f|OkQ|s*yqia^CR~l');
define('LOGGED_IN_KEY',    'FJvFyk#X-N|%|2uw~FGD5N=bNpTd:1dZ+9=UN^ku_WRD&RU-1PO#>{AZ<fbIH!Cy');
define('NONCE_KEY',        'yG7kTtX|: ?Z=Bc7d);-.pa~xL(nD%_2.CSOL+l/(yZB*|-wyfIgL: S,5U3FCE+');
define('AUTH_SALT',        '7g,83G}pI/zXOKOLJX5*|nvu2P 9i1XZoOyBbZ_y/[8j*|gaN_k-*w0T)}p9~DPi');
define('SECURE_AUTH_SALT', 'Rsfz!ORam*mEAY%wm_RZ)+0gkAo)4Wr8K(9~t.+b2v[JOhPF&<)gLbI%OA,i|kgt');
define('LOGGED_IN_SALT',   'D8lVjGj_7^&i3R*^9$/,_I1--Jt?-H0JF;mAsJy+v.`}]1`S!,2Avd %dD^l56Rz');
define('NONCE_SALT',       '!LJ))tr>[RBwo{&+Ab.d6y83.hy>E[.7FE%f<K: &G+8p)cj0:bLxr.Qt%-%`e2T');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'apoint_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
