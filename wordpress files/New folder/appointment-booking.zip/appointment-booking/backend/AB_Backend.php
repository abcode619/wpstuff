<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class AB_Backend {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'addAdminMenu' ) );

        // Backend controllers.
        $this->apearanceController     = new AB_AppearanceController();
        $this->calendarController      = new AB_CalendarController();
        $this->customerController      = new AB_CustomerController();
        $this->exportController        = new AB_ExportController();
        $this->notificationsController = new AB_NotificationsController();
        $this->paymentController       = new AB_PaymentController();
        $this->serviceController       = new AB_ServiceController();
        $this->settingsController      = new AB_SettingsController();
        $this->staffController         = new AB_StaffController();
        $this->couponsController       = new AB_CouponsController();
        $this->customFieldsController  = new AB_CustomFieldsController();

        // Frontend controllers that work via admin-ajax.php.
        $this->bookingController      = new AB_BookingController();
        $this->authorizeNetController = new AB_AuthorizeNetController();
        $this->stripeController       = new AB_StripeController();

        add_action( 'wp_loaded', array( $this, 'init' ) );
        add_action( 'admin_init', array( $this, 'addTinyMCEPlugin' ) );
        add_action( 'admin_notices', array( $this->settingsController, 'showAdminNotice' ) );
        
        //Add custom user fields
        add_action( 'show_user_profile', array( $this, 'ab_add_custom_user_profile_fields' ) );
        add_action( 'edit_user_profile', array( $this, 'ab_add_custom_user_profile_fields' ) );

        //Save custom user fields
        add_action( 'personal_options_update', array( $this, 'ab_save_custom_user_profile_fields' ) );
        add_action( 'edit_user_profile_update', array( $this, 'ab_save_custom_user_profile_fields' ) );
    }

    /**
     * Add custom user fields
     */
    function ab_add_custom_user_profile_fields( $user ) {
        
        if( !in_array( 'administrator' , $user->roles ) ) {

            $card_number= get_user_meta( $user->ID, 'ab_card_number', true );
            $card_month = get_user_meta( $user->ID, 'ab_card_month', true );
            $card_year  = get_user_meta( $user->ID, 'ab_card_year', true );
            $card_code  = get_user_meta( $user->ID, 'ab_card_code', true );

            $user_phone     = get_user_meta( $user->ID, 'ab_user_phone', true );
            $user_zipcode   = get_user_meta( $user->ID, 'ab_user_zipcode', true );

    ?>
            <h3><?php _e('Credit Card Details', 'esbab'); ?></h3>

            <table class="form-table">
                <tr>
                    <th>
                        <label for="ab_card_number"><?php _e('Credit Card Number', 'esbab'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="ab_card_number" id="ab_card_number" value="<?php echo esc_attr( $card_number ); ?>" class="regular-text" /><br />
                        <span class="description"><?php _e('Please enter your credit card number.', 'esbab'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="ab_card_number"><?php _e('Expiration Date', 'esbab'); ?></label>
                    </th>
                    <td>
                        <select style="width: 65px;float: left;" name="ab_card_month">
                                <option value=""><?php _e('--Select--', 'esbab'); ?></option>
                            <?php for ( $i = 1; $i <= 12; ++ $i ): ?>
                                <option value="<?php echo $i ?>" <?php selected( $card_month, $i ) ?>><?php printf( '%02d', $i ) ?></option>
                            <?php endfor; ?>
                        </select>
                        <select style="width: 65px;float: left; margin-left: 10px;" name="ab_card_year">
                                <option value=""><?php _e('--Select--', 'esbab'); ?></option>
                            <?php for ( $i = date('Y'); $i <= date('Y')+10; ++ $i ): ?>
                                <option value="<?php echo $i ?>" <?php selected( $card_year, $i ) ?>><?php echo $i ?></option>
                            <?php endfor ?>
                        </select><br /><br />
                        <span class="description"><?php _e('Please select your expiration date.', 'esbab'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="ab_card_code"><?php _e('Card Security Code', 'esbab'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="ab_card_code" id="ab_card_code" value="<?php echo esc_attr( $card_code ); ?>" class="small-text" /><br />
                        <span class="description"><?php _e('Please enter your credit card security code.', 'esbab'); ?></span>
                    </td>
                </tr>
            </table>
            
            <h3><?php _e('Other Details', 'esbab'); ?></h3>

            <table class="form-table">
                <tr>
                    <th>
                        <label for="ab_user_phone"><?php _e('Phone Number', 'esbab'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="ab_user_phone" id="ab_user_phone" value="<?php echo esc_attr( $user_phone ); ?>" class="regular-text" /><br />
                        <span class="description"><?php _e('Please enter your phone number.', 'esbab'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>
                        <label for="ab_user_zipcode"><?php _e('Zipcode', 'esbab'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="ab_user_zipcode" id="ab_user_zipcode" value="<?php echo esc_attr( $user_zipcode ); ?>" class="regular-text" /><br />
                        <span class="description"><?php _e('Please enter your zipcode.', 'esbab'); ?></span>
                    </td>
                </tr>
            </table>
            
    <?php 
        }
    }

    /**
     * Save custom user fields
     */
    function ab_save_custom_user_profile_fields( $user_id ) {

        if ( !current_user_can( 'edit_user', $user_id ) )
                return FALSE;

        if( isset( $_POST['ab_card_number'] ) ) {
            update_user_meta( $user_id, 'ab_card_number', stripslashes_deep( $_POST['ab_card_number'] ) );
        }
        if( isset( $_POST['ab_card_code'] ) ) {
            update_user_meta( $user_id, 'ab_card_code', stripslashes_deep( $_POST['ab_card_code'] ) );
        }
        if( isset( $_POST['ab_card_month'] ) ) {
            update_user_meta( $user_id, 'ab_card_month', stripslashes_deep( $_POST['ab_card_month'] ) );
        }
        if( isset( $_POST['ab_card_year'] ) ) {
            update_user_meta( $user_id, 'ab_card_year', stripslashes_deep( $_POST['ab_card_year'] ) );
        }
        if( isset( $_POST['ab_user_phone'] ) ) {
            update_user_meta( $user_id, 'ab_user_phone', stripslashes_deep( $_POST['ab_user_phone'] ) );
        }
        if( isset( $_POST['ab_user_zipcode'] ) ) {
            update_user_meta( $user_id, 'ab_user_zipcode', stripslashes_deep( $_POST['ab_user_zipcode'] ) );
        }
    }
    
    public function addTinyMCEPlugin() {
        /** @var WP_User $current_user */
        global $current_user;
        new AB_TinyMCE_Plugin();
    }

    public function init() {
        if ( !session_id() ) {
            @session_start();
        }

        if ( isset( $_POST[ 'action' ] ) ) {
            switch ( $_POST[ 'action' ] ) {
                case 'ab_update_staff':
                    $this->staffController->updateStaff();
                    break;
            }
        }
    }

    public function addAdminMenu() {
        /** @var wpdb $wpdb */
        global $wpdb;
        /** @var WP_User $current_user */
        global $current_user;

        // translated submenu pages
        $calendar       = __( 'Calendar', 'esbab' );
        $staff_members  = __( 'Staff members', 'esbab' );
        $services       = __( 'Services', 'esbab' );
        $customers      = __( 'Customers', 'esbab' );
        $notifications  = __( 'Notifications', 'esbab' );
        $payments       = __( 'Payments', 'esbab' );
        $appearance     = __( 'Appearance', 'esbab' );
        $settings       = __( 'Settings', 'esbab' );
        $export         = __( 'Export', 'esbab' );
        $coupons        = __( 'Coupons', 'esbab' );
        $custom_fields  = __( 'Custom fields', 'esbab' );

        if ( in_array( 'administrator', $current_user->roles )
            || $wpdb->get_var( $wpdb->prepare(
                'SELECT COUNT(id) AS numb FROM ab_staff WHERE wp_user_id = %d', $current_user->ID
            ) ) ) {
            if ( function_exists( 'add_options_page' ) ) {
                $dynamic_position = '80.0000001' . mt_rand( 1, 1000 ); // position always is under `Settings`
                add_menu_page( 'Appointments', 'Appointments', 'read', 'ab-system', '' );
                add_submenu_page( 'ab-system', $calendar, $calendar, 'read', 'ab-calendar',
                    array( $this->calendarController, 'index' ) );
                add_submenu_page( 'ab-system', $staff_members, $staff_members, 'manage_options', 'ab-system-staff',
                    array( $this->staffController, 'index' ) );
                add_submenu_page( 'ab-system', $services, $services, 'manage_options', 'ab-services',
                    array( $this->serviceController, 'index' ) );
                add_submenu_page( 'ab-system', $customers, $customers, 'manage_options', 'ab-customers',
                    array( $this->customerController, 'index' ) );
                add_submenu_page( 'ab-system', $notifications, $notifications, 'manage_options', 'ab-notifications',
                    array( $this->notificationsController, 'index' ) );
//                add_submenu_page( 'ab-system', $payments, $payments, 'manage_options', 'ab-payments',
//                    array( $this->paymentController, 'index' ) );
//                add_submenu_page( 'ab-system', $appearance, $appearance, 'manage_options', 'ab-appearance',
//                    array( $this->apearanceController, 'index' ) );
//                add_submenu_page( 'ab-system', $custom_fields, $custom_fields, 'manage_options', 'ab-custom-fields',
//                    array( $this->customFieldsController, 'index' ) );
//                add_submenu_page( 'ab-system', $coupons, $coupons, 'manage_options', 'ab-coupons',
//                    array( $this->couponsController, 'index' ) );
                add_submenu_page( 'ab-system', $settings, $settings, 'manage_options', 'ab-settings',
                    array( $this->settingsController, 'index' ) );
//                add_submenu_page( 'ab-system', $export, $export, 'manage_options', 'ab-export',
//                    array( $this->exportController, 'index' ) );

                global $submenu;
                unset( $submenu[ 'ab-system' ][ 0 ] );
            }
        }
    }

}
