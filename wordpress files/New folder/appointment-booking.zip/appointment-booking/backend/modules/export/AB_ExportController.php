<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Class AB_ExportController
 */
class AB_ExportController extends AB_Controller {

    public function index() {
        /** @var WP_Locale $wp_locale */
        global $wp_locale;

        $this->enqueueStyles( array(
            'backend' => array(
                'css/ab_style.css',
                'bootstrap/css/bootstrap.min.css',
                'css/daterangepicker.css',
                'css/bootstrap-select.min.css',
            )
        ) );

        $this->enqueueScripts( array(
            'backend' => array(
                'bootstrap/js/bootstrap.min.js' => array( 'jquery' ),
                'js/date.js' =>  array( 'jquery' ),
                'js/daterangepicker.js' => array( 'jquery' ),
                'js/bootstrap-select.min.js',
            )
        ) );

        wp_localize_script( 'ab-daterangepicker.js', 'BooklyL10n', array(
            'today'        => __( 'Today', 'esbab' ),
            'yesterday'    => __( 'Yesterday', 'esbab' ),
            'last_7'       => __( 'Last 7 Days', 'esbab' ),
            'last_30'      => __( 'Last 30 Days', 'esbab' ),
            'this_month'   => __( 'This Month', 'esbab' ),
            'last_month'   => __( 'Last Month', 'esbab' ),
            'custom_range' => __( 'Custom Range', 'esbab' ),
            'apply'        => __( 'Apply', 'esbab' ),
            'clear'        => __( 'Clear', 'esbab' ),
            'to'           => __( 'To', 'esbab' ),
            'from'         => __( 'From', 'esbab' ),
            'months'       => array_values( $wp_locale->month ),
            'days'         => array_values( $wp_locale->weekday_abbrev )
        ));
        $this->render( 'index' );
    }

    /**
     * Export Appointment to CSV
     */
    public function executeExportToCSV() {
        $start_date = new DateTime( $this->getParameter( 'date_start' ) );
        $start_date = $start_date->format( 'Y-m-d H:i:s' );
        $end_date   = new DateTime( $this->getParameter( 'date_end' ) );
        $end_date->modify( '+1 day' );
        $end_date   = $end_date->format( 'Y-m-d H:i:s' );

        header( 'Content-Type: text/csv; charset=' . ( get_locale() == 'ru_RU' ? 'windows-1251' : 'utf-8' ) );
        header( 'Content-Disposition: attachment; filename=appointment.csv' );

        if ( get_locale() == 'ru_RU' ) {
            $headings = array(
                iconv( 'utf-8', 'windows-1251', __( 'Customer name', 'esbab' ) ),
                iconv( 'utf-8', 'windows-1251', __( 'Service title', 'esbab' ) ),
                iconv( 'utf-8', 'windows-1251', __( 'Start date', 'esbab' ) ),
                iconv( 'utf-8', 'windows-1251', __( 'End date', 'esbab' ) ),
            );
        }
        else {
            $headings = array(
                __( 'Customer name', 'esbab' ),
                __( 'Service title', 'esbab' ),
                __( 'Start date', 'esbab' ),
                __( 'End date', 'esbab' ),
            );
        }
        $output = fopen( 'php://output', 'w' );
        fputcsv( $output, $headings );

        $appointments = $this->getWpdb()->get_results( "
        SELECT c.name AS customer_name,
               s.title AS service_title,
               a.start_date AS start_date,
               a.end_date AS end_date
        FROM ab_customer_appointment ca
        LEFT JOIN ab_appointment a ON a.id = ca.appointment_id
        LEFT JOIN ab_service s ON a.service_id = s.id
        LEFT JOIN ab_customer c ON ca.customer_id = c.id
        WHERE a.start_date between '{$start_date}' AND '{$end_date}'
        ORDER BY a.start_date DESC
        ", ARRAY_A );

        foreach( $appointments as $appointment ) {
            if ( get_locale() == 'ru_RU' ) {
                $appointment[ 'customer_name' ] = iconv( 'utf-8', 'windows-1251', $appointment[ 'customer_name' ] );
                $appointment[ 'service_title' ] = iconv( 'utf-8', 'windows-1251', $appointment[ 'service_title' ] );
            }
            fputcsv( $output, $appointment );
        }
        fclose( $output );

        exit();
    }

    /**
     * Override parent method to add 'wp_ajax_ab_' prefix
     * so current 'execute*' methods look nicer.
     */
    protected function registerWpActions( $prefix = '' ) {
        parent::registerWpActions( 'wp_ajax_ab_' );
    }
}