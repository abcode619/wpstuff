<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="ab-title"><?php _e('Settings', 'esbab') ?></div>
<div style="min-width: 800px;">
    <div class="ab-left-bar">
        <div id="ab_settings_general" class="ab-left-tab <?php echo ( ! isset( $_GET[ 'type' ] ) || $_GET[ 'type' ] == '_general' ) ? 'ab-active' : ''  ?>"><?php _e( 'General','esbab' ) ?></div>
        <?php /* ?>
        <div id="ab_settings_company" class="ab-left-tab <?php echo isset( $_GET['type'] ) && $_GET['type'] == '_company' ? 'ab-active' : ''  ?>"><?php _e( 'Company','esbab' ) ?></div>
        <?php */ ?>
        <div id="ab_settings_payments" class="ab-left-tab <?php echo isset( $_GET['type'] ) && $_GET['type'] == '_payments' ? 'ab-active' : ''  ?>"><?php _e( 'Payments','esbab' ) ?></div>
        <div id="ab_settings_hours" class="ab-left-tab <?php echo isset( $_GET['type'] ) && $_GET['type'] == '_hours' ? 'ab-active' : ''  ?>"><?php _e( 'Business hours','esbab' ) ?></div>
        <div id="ab_settings_holidays" class="ab-left-tab <?php echo isset( $_GET['type'] ) && $_GET['type'] == '_holidays' ? 'ab-active' : ''  ?>"><?php _e( 'Holidays','esbab' ) ?></div>
    </div>
    <div class="ab-right-content" id="content_wrapper">
        <div id="general-form" class="<?php echo ( ! isset( $_GET[ 'type' ] ) || $_GET[ 'type' ] == '_general' ) ? '' : 'hidden' ?> ab-staff-tab-content">
            <?php include '_generalForm.php' ?>
        </div>
        <?php /* ?>
        <div id="company-form" class="<?php echo ( isset( $_GET['type'] ) && $_GET['type'] == '_company' ) ? '' : 'hidden' ?>">
            <?php include '_companyForm.php' ?>
        </div>
        <?php */ ?>
        <div id="payments-form" class="<?php echo ( isset( $_GET['type'] ) && $_GET['type'] == '_payments' ) ? '' : 'hidden' ?>">
            <?php include '_paymentsForm.php' ?>
        </div>
        <div id="hours-form" class="<?php echo ( isset( $_GET['type'] ) && $_GET['type'] == '_hours' ) ? '' : 'hidden' ?>">
            <?php include '_hoursForm.php' ?>
        </div>
        <div id="holidays-form" class="<?php echo ( isset( $_GET['type'] ) && $_GET['type'] == '_holidays' ) ? '' : 'hidden' ?> ab-staff-tab-content">
            <?php include '_holidaysForm.php' ?>
        </div>
    </div>
</div>