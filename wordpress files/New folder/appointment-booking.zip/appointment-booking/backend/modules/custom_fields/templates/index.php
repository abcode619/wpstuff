<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="ab-title"><?php _e('Custom Fields', 'esbab') ?></div>

<div style="min-width: 800px;">

    <ul id="ab-custom-fields"></ul>

    <div id="ab-add-fields">
        <button class="button" data-type="text-field"><i class="icon-plus"></i> <?php _e( 'Text Field', 'esbab' ) ?></button>&nbsp;
        <button class="button" data-type="textarea"><i class="icon-plus"></i> <?php _e( 'Text Area', 'esbab' ) ?></button>&nbsp;
        <button class="button" data-type="checkboxes"><i class="icon-plus"></i> <?php _e( 'Checkbox Group', 'esbab' ) ?></button>&nbsp;
        <button class="button" data-type="radio-buttons"><i class="icon-plus"></i> <?php _e( 'Radio Button Group', 'esbab' ) ?></button>&nbsp;
        <button class="button" data-type="drop-down"><i class="icon-plus"></i> <?php _e( 'Drop Down', 'esbab' ) ?></button>
    </div>

    <input type="submit" value="<?php _e( 'Save', 'esbab' ) ?>" class="btn btn-info ab-update-button" />
    <span class="spinner left"></span>
    <button class="ab-reset-form" type="reset"><?php _e( ' Reset ', 'esbab' ) ?></button>

    <ul id="ab-templates" style="display:none">

        <li data-type="text-field">
            <i class="ab-handle icon-move"></i>
            <h2 class="ab-field-title">
                <?php _e( 'Text Field', 'esbab' ) ?>
                <i class="ab-delete icon-remove"></i>
            </h2>
            <div class="input-append">
                <input class="ab-label" type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
                <span class="add-on">
                    <label>
                        <input class="ab-required" type="checkbox" />
                        <span><?php _e( 'Required field', 'esbab' ) ?></span>
                    </label>
                </span>
            </div>
        </li>

        <li data-type="textarea">
            <i class="ab-handle icon-move"></i>
            <h2 class="ab-field-title">
                <?php _e( 'Text Area', 'esbab' ) ?>
                <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove field', 'esbab' ) ?>"></i>
            </h2>
            <div class="input-append">
                <input class="ab-label" type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
                <span class="add-on">
                    <label>
                        <input class="ab-required" type="checkbox" />
                        <span><?php _e( 'Required field', 'esbab' ) ?></span>
                    </label>
                </span>
            </div>
        </li>

        <li data-type="checkboxes">
            <i class="ab-handle icon-move"></i>
            <h2 class="ab-field-title">
                <?php _e( 'Checkbox Group', 'esbab' ) ?>
                <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove field', 'esbab' ) ?>"></i>
            </h2>
            <div class="input-append">
                <input class="ab-label" type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
                <span class="add-on">
                    <label>
                        <input class="ab-required" type="checkbox" />
                        <span><?php _e( 'Required field', 'esbab' ) ?></span>
                    </label>
                </span>
            </div>
            <ul class="ab-items"></ul>
            <button class="button" data-type="checkboxes-item"><i class="icon-plus"></i> <?php _e( 'Checkbox', 'esbab' ) ?></button>
        </li>

        <li data-type="radio-buttons">
            <i class="ab-handle icon-move"></i>
            <h2 class="ab-field-title">
                <?php _e( 'Radio Button Group', 'esbab' ) ?>
                <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove field', 'esbab' ) ?>"></i>
            </h2>
            <div class="input-append">
                <input class="ab-label" type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
                <span class="add-on">
                    <label>
                        <input class="ab-required" type="checkbox" />
                        <span><?php _e( 'Required field', 'esbab' ) ?></span>
                    </label>
                </span>
            </div>
            <ul class="ab-items"></ul>
            <button class="button" data-type="radio-buttons-item"><i class="icon-plus"></i> <?php _e( 'Radio Button', 'esbab' ) ?></button>
        </li>

        <li data-type="drop-down">
            <i class="ab-handle icon-move"></i>
            <h2 class="ab-field-title">
                <?php _e( 'Drop Down', 'esbab' ) ?>
                <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove field', 'esbab' ) ?>"></i>
            </h2>
            <div class="input-append">
                <input class="ab-label" type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
                <span class="add-on">
                    <label>
                        <input class="ab-required" type="checkbox" />
                        <span><?php _e( 'Required field', 'esbab' ) ?></span>
                    </label>
                </span>
            </div>
            <ul class="ab-items"></ul>
            <button class="button" data-type="drop-down-item"><i class="icon-plus"></i> <?php _e( 'Option', 'esbab' ) ?></button>
        </li>

        <li data-type="checkboxes-item">
            <i class="ab-inner-handle icon-move"></i>
            <input type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
            <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove item', 'esbab' ) ?>"></i>
        </li>

        <li data-type="radio-buttons-item">
            <i class="ab-inner-handle icon-move"></i>
            <input type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
            <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove item', 'esbab' ) ?>"></i>
        </li>

        <li data-type="drop-down-item">
            <i class="ab-inner-handle icon-move"></i>
            <input type="text" value="" placeholder="<?php _e( 'Enter a label', 'esbab' ) ?>" />
            <i class="ab-delete icon-remove" title="<?php echo esc_attr( 'Remove item', 'esbab' ) ?>"></i>
        </li>

    </ul>

</div>

