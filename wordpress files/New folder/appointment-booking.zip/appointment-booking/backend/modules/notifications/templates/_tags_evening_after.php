<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<tr>
    <th><?php _e('Subject', 'esbab') ?></th>
    <th><?php _e('Message', 'esbab') ?></th>
</tr>
<tr>
    <td><?php _e('[[COMPANY_NAME]] - name of the company', 'esbab') ?></td>
    <td><?php _e('[[CLIENT_NAME]] - name of client', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[APPOINTMENT_DATE]] - date of appointment', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[APPOINTMENT_TIME]] - time of appointment', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[SERVICE_NAME]] - name of service', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[SERVICE_PRICE]] - price of service', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[CATEGORY_NAME]] - name of category', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[COMPANY_NAME]] - name of the company', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[COMPANY_LOGO]] - company logo', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[COMPANY_ADDRESS]] - address of your company', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[COMPANY_PHONE]] - company phone', 'esbab') ?></td>
</tr>
<tr>
    <td></td>
    <td><?php _e('[[COMPANY_WEBSITE]] - this web-site address', 'esbab') ?></td>
</tr>