<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<tr>
    <th><?php _e('Subject', 'esbab') ?></th>
    <th><?php _e('Message', 'esbab') ?></th>
</tr>
<tr>
    <td><?php _e('[[TOMORROW_DATE]] - date of next day', 'esbab') ?></td>
    <td><?php _e('[[NEXT_DAY_AGENDA]] - staff agenda for next day', 'esbab') ?></td>
</tr>