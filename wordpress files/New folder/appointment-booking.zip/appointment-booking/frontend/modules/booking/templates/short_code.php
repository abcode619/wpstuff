<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div id="ab-booking-form-<?php echo $form_id ?>" class="ab-booking-form"></div>
<script type="text/javascript">
    jQuery(function ($) {
        <?php $lang = isset($_REQUEST['lang']) ? '?lang=' . $_REQUEST['lang'] : '';?>
        $('#ab-booking-form-<?php echo $form_id ?>').appointmentBooking({
            ajaxurl: <?php echo json_encode( admin_url('admin-ajax.php') . $lang ); ?>,
            attributes: <?php echo $attributes ?>,
            last_step: <?php echo (int)$booking_finished  ?>,
            cancelled: <?php echo (int)$booking_cancelled  ?>,
            form_id: <?php echo json_encode( $form_id ) ?>,
            start_of_week: <?php echo json_encode( get_option( 'start_of_week' ) ) ?>,
            today_text: <?php echo json_encode( __( 'Today', 'esbab' ) ) ?>,
            date_min: <?php echo json_encode( AB_BookingConfiguration::getDateMin() ) ?>,
            custom_fields: '<?php echo get_option('ab_custom_fields') ?>'
        });
    });
</script>