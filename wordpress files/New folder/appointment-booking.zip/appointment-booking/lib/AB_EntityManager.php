<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

abstract class AB_EntityManager {

    static protected $table_name = null;

    static protected $entity_class = null;

    static protected $instance = null;

    /**
     * Constructor.
     */
    protected function __construct() {
        /** @var WPDB $wpdb */
        global $wpdb;

        // Reference to global database object.
        $this->wpdb = $wpdb;
    }

    /**
     * Get instance of entity manager.
     *
     * @return AB_EntityManager
     */
    static public function getInstance() {
        if ( static::$instance === null ) {
            static::$instance = new static();
        }

        return static::$instance;
    }

    /**
     * Find all entities.
     *
     * @param array $order_by
     * @return array
     */
    public function findAll( array $order_by = array() ) {
        return $this->findBy( array(), $order_by );
    }

    /**
     * Find entities in database by fields values.
     *
     * @param array $fields
     * @param array $order_by
     * @return array
     */
    public function findBy( array $fields, array $order_by = array() ) {
        $result = array();

        // Prepare WHERE clause.
        $where = array();
        $values = array();
        foreach ( $fields as $field => $value ) {
            if ( $value === null ) {
                $where[] = sprintf( '`%s` IS NULL', $field );
            }
            else {
                $where[] = sprintf( '`%s` = %s', $field, $this->formats[ $field ] );
                $values[] = $value;
            }
        }
        // Prepare ORDER BY clause.
        $order = array();
        foreach ( $order_by as $field => $direction ) {
            $order[] = sprintf( '`%s` %s', $field, $direction );
        }

        $rows = $this->wpdb->get_results( $this->wpdb->prepare(
            sprintf(
                'SELECT * FROM `%s`%s%s',
                static::$table_name,
                empty( $where ) ? '' : ' WHERE ' . implode( ' AND ', $where ),
                empty( $order ) ? '' : ' ORDER BY ' . implode( ', ',  $order )
            ),
            $values
        ), ARRAY_A );

        if ( is_array( $rows ) ) {
            foreach ( $rows as $row ) {
                $entity = new static::$entity_class;
                $entity->setData( $row, true );

                $result[] = $entity;
            }
        }

        return $result;
    }
}