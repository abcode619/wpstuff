<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly

class AB_CustomersManager extends AB_EntityManager {

    static protected $table_name = 'ab_customer';

    static protected $entity_class = 'AB_Customer';

    static protected $instance = null;
}