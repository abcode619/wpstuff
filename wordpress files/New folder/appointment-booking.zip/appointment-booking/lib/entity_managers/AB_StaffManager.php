<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly

class AB_StaffManager extends AB_EntityManager {

    static protected $table_name = 'ab_staff';

    static protected $entity_class = 'AB_Staff';

    static protected $instance = null;
}