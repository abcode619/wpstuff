<?php

class Settings extends MY_Controller {

   public function __construct(){

	   /**
		*  This is  completely different from the original one
		* ????????? DO NOT EDIT THIS ??? UNLESS YOU KNOW WHAT YOU ARE DOING
		*/
	   parent::__construct();
		$this->tpl->page_title = 'My Settings';

		if(!$this->session->userdata('user')) {
			//check logged in - if not send them to the login page
			redirect(site_url('login'));
			exit;
		}
	}


	public function index() {
		$this->tpl->content = $this->load->view(''.$this->router->class, '', true);
		$this->load->view('myid_template', array('tpl' => $this->tpl));
	}

}
