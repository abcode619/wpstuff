<?php

/*
	This is supposed to be a user management module.
	For now, it can only list users though
*/

class Myiduser extends CIID_Controller {

	var $new_password = false;

	public function __construct()
	{
		parent::__construct();

		$this->set_table('users_myid', 'MYID User', 'MYID Users');
		$this->sortable = true;
		$this->allow_edit = false;
		$this->allow_add = false;
		$this->allow_delete = false;

	   if($this->site_model->user_level >=9){

			$this->allow_edit = true;
			$this->allow_add = true;

	   }
        // only user level 10 can manage complete user details
		if($this->site_model->user_level >= 10)
		{
			$this->allow_delete = true;
			//array_push($this->access_level,array('label' => 'level 10', 'value' => '10', 'colour' => '#D00'));
		}

		$this->primary_key = 'id';

		$status = array(
			array('label' => 'Active',   'value' => '1', 'colour' => '#3C3', 'default' => TRUE),
			array('label' => 'Inactive', 'value' => '0', 'colour' => '#D00'),
		);

		$this->form->add_group('Product')
			->add_field('username', 'Login', 'textbox')
			->add_field('full_name', 'Full Name', 'textbox')->validate('required')
			->add_field('user_level', 'User level', 'select')->set_options($this->access_level)->validate('required')
			->add_field('email', 'Email', 'textbox')->validate('required|unique')
			->add_field('status', 'Status', 'select')->set_options($status)->validate('required')
			//->add_field('*', 'Categories', 'checkbox_group')->join('store_category')
			;

			if($this->form->mode =='add'){
				$this->new_password = true;
				$this->form->current_group()
					->add_field('password', 'Password (New)', 'password')->validate('required')->footnote('Enter a new password above. If left unchanged, the existing password will remain');
			}
			if($this->form->mode == 'edit'){

				$this->form->current_group()
					->add_field('password', 'Password(update)', 'password')->validate('required')->footnote('Enter a new password above. If left unchanged, the existing password will remain');
			}


		$this->overview
			->add_item('Login', 'active', 'username')
			->add_item('Level', 'active', 'user_level')
			->add_item('Name', 'active', 'full_name')
			->add_item('Last edited', 'active', 'updated_date')
			;

		$this->init();

	}

	function _before_save_callback()
	{

		if ($this->new_password)
			$this->record->set_item('password', md5($this->input->post('password')));
	}

	// function _before_add_save_callback() {

	// 	$this->record->set_item('password', md5($this->new_password));
	// }

	// function _before_save_callback()
	// {


	// 	if ($this->new_password)
	// 		$this->record->set_item('password', md5($this->new_password));
	// }

}
