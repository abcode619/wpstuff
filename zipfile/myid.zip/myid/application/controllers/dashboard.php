<?php

class Dashboard extends MY_Controller{

	public function __construct(){
		parent::__construct();
		$this->tpl->page_title = 'Dashboard';

		if(!$this->session->userdata('user')) {
			//check logged in - if not send them to the login page
			redirect(site_url('login'));
			exit;
		}
	}
	
	public function index() {
		$this->load->model('dashboard_model');

		if (!isset($this->tpl->page))
			$this->tpl->page = new stdClass();

		if (!isset($this->tpl->header))
			$this->tpl->header = new stdClass();

		$this->tpl->page->title	 = 'Welcome ' . $this->session->userdata('username');;
		
		$output = array();

		if ($this->tpl->dashboard) {
			$output[] = $this->load->view('widgets/dashboard_overview', $this->tpl, true);
		}

		$this->tpl->content = implode("\n", $output);
		$this->tpl->content = $this->load->view('overview', array('tpl' => $this->tpl), true);
		$this->tpl->content = $this->load->view('module', array('tpl' => $this->tpl), true);
		

		$this->load->view('myid_template', array('tpl' => $this->tpl));
	}

}

/* End of file homepage.php */
/* Location: ./system/application/controllers/homepage.php */
