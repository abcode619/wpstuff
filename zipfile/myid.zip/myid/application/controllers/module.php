<?php

class Module extends CIID_Controller {

	function __construct() {
		parent::__construct();
		$this->load->model('dashboard_model');

		$this->set_table('modules', 'Module', 'Modules');

		$this->sortable = true;

		$this->primary_key = 'id';

		$status = array(
			array('label' => 'Enabled', 'value' => 'enabled', 'colour' => '#3C3', 'default' => TRUE),
			array('label' => 'Disabled', 'value' => 'disabled', 'colour' => '#D00'),
		);

		$visibility = array(
			array('label' => 'Sidebar', 'value' => 'visible', 'colour' => '#3C3', 'default' => TRUE),
			array('label' => 'Nav bar', 'value' => 'nav', 'colour' => '#33C'),
			array('label' => 'Hide', 'value' => 'hidden', 'colour' => '#D00'),
		);

		$modules = $this->dashboard_model->get_modules();

		$this->form->add_group('Module')
			->add_field('name', 'Name', 'textbox')->validate('required')
			->add_field('url', 'URL', 'textbox')->validate('required')
			->add_field('parent', 'Submodule of', 'select')->set_options($modules)
			->add_field('visibility', 'Visibility', 'select')->set_options($visibility)
			->add_field('status', 'Status', 'select')->set_options($status)
			->add_field('user_level', 'User Level', 'textbox')->set_default('1')->validate('required|number')
//			->add_field('coordinates', 'Map', 'map')
			;

		$this->overview
			->add_item('Name', 'active', 'name')
			->add_item('URL', 'active', 'url')
			->add_switch('Visibility', 'visibility', $visibility)
			->add_switch('Status', 'status', $status)
			->add_item('Parent', 'active', 'parent', $modules)
			->add_item('User Level', 'active', 'user_level')
			->order_by('name');

		$this->embedded = $this->overview;

		$this->init();

	}

		/* For redactor */
	public function upload() {
		$path = 'resources/redactor';
		if (!move_uploaded_file($_FILES['file']['tmp_name'], getcwd()."/../$path/".$_FILES['file']['name'])) {
			file_put_contents('/tmp/myid.log', date("[Y-m-d h:i:s] ").'Error while moving '.$_FILES['file']['tmp_name'].' to '.getcwd()."/../$path/".$_FILES['file']['name'], FILE_APPEND);
		}
		$array = array(
			'filelink' => '/'.$path.'/'.$_FILES['file']['name']
		);
		echo stripslashes(json_encode($array));
	}
}
