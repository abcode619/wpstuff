<?php

class Enquiry_forms extends CIID_Controller {

	function __construct() {

		parent::__construct();

		$this->set_table('enquiry_forms', 'Enquiry Forms', 'Enquiry Forms');

		$this->sortable = false;
		$this->allow_delete = false;
		$this->allow_add= false;
		$this->allow_edit = true;
                
                $this->tpl->custom_button = '<a class="btn_sml meta_bold_hover" href="'.site_url('modules/enquiry_forms/download_csv').'">';
		$this->tpl->custom_button .= '<span>Download CSV</span>';
		$this->tpl->custom_button .='</a>';

		$this->form->add_group('Download Available')
			->add_field('name', 'Name', 'textbox')->readonly()
			->add_field('email_address', 'Email Address', 'textbox')->readonly()
			->add_field('subject', 'Subject', 'textbox')->readonly()
			->add_field('message', 'Message', 'textarea')->readonly()
			;

		$this->overview
			->add_item('Name', 'active', 'name')
			->add_item('Email Address', 'active', 'email_address')			
			->add_item('Subject', 'active', 'subject')			
			->add_item('Created Date', 'active', 'created_date')
//			->add_icon('csv_icon.png', 'exports/csv/{table_map}')
                        ->order_by('enquiry_forms_id DESC');
		$this->init();

	}
        
        public function download_csv()
	{
		$this->load->library('parsecsv');
                
		$alljobs = $this->db->order_by('enquiry_forms_id DESC')->get('enquiry_forms')->result();
		$array = array(array('Contact Person', 'Email ID', 'Subject', 'Message', 'Created Date'));

		foreach($alljobs as $jobs) {
			$array[] = array($jobs->name, $jobs->email_address, $jobs->subject, $jobs->message, $jobs->created_date);
		}

		$csv = new parseCSV();
		$csv->output(true,'All Enquiries - Orgone Energy Australia.csv',$array);
	}

	public function csv($table){
     // dump_exit($table);
		$this->load->library('parsecsv');

		if($table == 'order'){
			$this->db->where('owing <=', 0);
		}
		//$this->db->order_by("created_date");
		// WE NEED TO ADD CUSTOME FUNCTION DEPENDING ON TABLE

		$emails = $this->db->get($table)->result();
		$fields = $this->db->list_fields($table);
		  //dump_exit($fields);

		$csv = new parseCSV();
		$csv->output(true, $table.'.csv', $emails, $fields);
	}

}
