<?php

class Setting extends CIID_Controller {

	function __construct() {
		parent::__construct();

		$this->set_table('setting', 'Setting', 'Settings');
		$this->group_key = 'category';


		if ($this->site_model->user_level >= 10) {
			$this->allow_add = true;
			$this->allow_delete = true;
			$this->sortable = true;

			$this->form->add_group('Settings')
				->add_field('category', 'Category', 'textbox')
				->add_field('name', 'Name', 'textbox')
				->add_field('value', 'Value', 'textbox')
				->add_field('help', 'Help', 'textarea_mce')
				;

		} else {
			$this->allow_add = false;
			$this->allow_delete = false;
			$this->sortable = false;

			$this->form->add_group('Settings')
				->add_field('category', 'Category', 'textbox')->readonly()
				->add_field('name', 'Name', 'textbox')->readonly()
				->add_field('value', 'Value', 'textbox')
				->add_field('help', 'Help', 'textarea')->readonly()
				;
		}

		$this->overview
			->add_item('Name', 'active', 'name')
			->add_item('Value', 'active', 'value')
			->add_item('Last changed', 'active', 'updated_date')
			->order_by('category, name')
			;

		$this->init();
	}
}