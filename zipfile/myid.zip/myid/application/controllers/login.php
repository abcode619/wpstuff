<?php

class Login extends MY_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('login_model');

		if (!isset($this->tpl))
			$this->tpl = new stdClass();
		if (!isset($this->tpl->page))
			$this->tpl->page = new stdClass();
	}


	/*
	 * @access: Public
	 * @return: Null (view)
	 *
	 * @description: Show login form for myid and validate it.
	 * If validation passes then store the session details
	 */
	public function index() {
		$this->load->library('form');

		if($this->session->userdata('user')) {
			//if not send them to the login page
			redirect(site_url('dashboard'));
		}

		$this->tpl->page->title = 'Login';

		addScript('assets/js/jquery.toggleval.js');
		addScript('assets/js/toggle.js');
		$this->tpl->scripts = $this->script['javascript'];

		$this->form
		->open('login','','class="login_form"')
		->text('username', '', 'required', 'Username', array('class' => 'toggle'))
		->password('password', '', 'required', '', array('class' => 'toggle'))
		->button('<span>LOGIN</span>', 'submit', 'submit', array('value' => 'LOGIN', 'class' => 'btn_sml meta_bold_hover'))
		->model('login_model', 'authenticate', '', 'Incorrect username or password');

		$this->tpl->content = $this->form->get();
		if ($this->form->valid) {
			$id = $this->form->models['login_model']['return'];

			session_start();
			$_SESSION['tinybrowser_secure'] = true;

			$this->session->set_userdata(array(
				'user' => $id->id,
				'username' => $id->full_name,
				'user_level' => $id->user_level,
			));

			redirect(site_url('dashboard'));
		}
		if (isset($this->form->login_model->error_message))
			$this->tpl->error = $this->form->login_model->error_message;

		$this->load->view('login', array('tpl' => $this->tpl));
	}
}

/* End of file myid.php */
/* Location: ./system/application/controllers/myid.php */
