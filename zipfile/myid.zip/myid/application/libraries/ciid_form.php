<?php

class CIID_Form {

	var $groups = array();
	var $errors;
	var $controller;
	var $title;
	var $output = '';
	var $controls = 'always';
	var $allow_save = 'always';
	var $mode = '';
	var $throw_errors = array();
	var $has_errors = false;

	function __construct(&$c, $mode) {

		if (preg_match('!^ajax_edit!', $mode))
			$mode = 'edit';
		if (preg_match('!^ajax_add!', $mode))
			$mode = 'add';

		$this->controller = $c;
		$this->mode = $mode;
	}

	function _post() {
	}

	function set_controls($mode='always') {
		$this->controls = $mode;
	}

	function set_save($mode='always') {
		$this->allow_save = $mode;
	}

	function validate() {
		// loop through groups and fields and run each validation
		foreach($this->groups as &$group) {
			if($group->availability != 'always' && $group->availability != $this->mode) {
				continue;
			}
			foreach($group->fields as &$field) {
				if($field->availability != 'always' && $field->availability != $this->mode) {
					// we can skip validatation if element is not visible
					continue;
				}

				$rules = explode('|', $field->rules);
				$field_parent_class = get_parent_class($field);
				if(count($rules)) {
					foreach($rules as $rule) {
						$rule_value = '';
						if($rule_start = strpos($rule,'[')) {
							$rule_end = strpos($rule, ']');
							if($rule_end) {
								$rule_value = substr($rule, $rule_start + 1, ($rule_end - 1) - $rule_start);
								$rule = substr($rule, 0, $rule_start);
							}
						}

						switch($rule) {
							case 'required' :
								if($field_parent_class == 'CIID_Field_Basic' || $field_parent_class == 'CIID_Field_Single_Selectable') {
									if( trim($this->controller->input->post($field->name)) == '') {
										$group->errors[] = 'The ' . $field->label . ' field is required';
										$this->has_errors = true;
									}
								} elseif( $field_parent_class == 'CIID_Field_Multi_Selectable' ) {
									if( !is_array($this->controller->input->post($field->name) )) {
										$group->errors[] = 'The ' . $field->label . ' field is required';
										$this->has_errors = true;
									} else {
										if(count($this->controller->input->post($field->name)) == 0 ) {
											$group->errors[] = 'The ' . $field->label . ' field is required';
											$this->has_errors = true;
										}
									}
								} elseif( $field_parent_class = 'CIID_Field_Binary') {
									if($this->mode == 'add') {
										if(@$_FILES[$field->name]['tmp_name'] == '') {
											$group->errors[] = 'The ' . $field->label . ' field is required';
											$this->has_errors = true;
										}
									}
								}

							break;
							case 'number' :
								if($field_parent_class == 'CIID_Field_Basic') {
									if(!is_numeric( $this->controller->input->post($field->name))) {
										$group->errors[] = 'The ' . $field->label . ' field is must be a numeric value';
										$this->has_errors = true;
									}
								}

							break;
							case 'unique' :
								if($field_parent_class == 'CIID_Field_Basic') {
									$table = $this->controller->table;
									if(@$this->controller->primary_key) {
										$primary_key = $this->controller->primary_key;
									} else {
										$primary_key = $table . '_id';
									}

									$primary_key_value = @$this->controller->record->item($primary_key)->value;
									$field_name = $field->name;
									if(!$this->controller->model->is_unique($table, $field_name, $this->controller->input->post($field_name), $primary_key, $primary_key_value )) {
										$group->errors[] = 'The ' . $field->label . ' field must contain a unique value';
										$this->has_errors = true;
										// not unique
									}
								}
							break;

							case 'length' :
								if(strlen($this->controller->input->post($field->name)) != $rule_value) {
									$group->errors[] = 'The ' . $field->label . ' field is must have a length of ' . $rule_value;
									$this->has_errors = true;
								}

							break;

							case 'max_length' :
								if(strlen($this->controller->input->post($field->name)) > $rule_value) {
									$group->errors[] = 'The ' . $field->label . ' field must be less than or equal to' . $rule_value . ' characters in length. (Currently ' . strlen($this->controller->input->post($field->name)) . ')';
									$this->has_errors = true;
								}
							break;

							case 'min_length' :
								if(strlen($this->controller->input->post($field->name)) < $rule_value) {
									$group->errors[] = 'The ' . $field->label . ' field must be greater than or equal to' . $rule_value . ' characters in length. (Currently ' . strlen($this->controller->input->post($field->name)) . ')';
									$this->has_errors = true;
								}

							break;
						}
					}
				}
			}
		}

		if (sizeof($this->throw_errors) > 0) {
			$this->has_errors = true;
		}


		if($this->has_errors) {
			$this->repopulate();
			return false;
		} else {
			return true;
		}
	}

	function add_group($label='') {
		$this->groups[] = new CIID_Group($this, $label);
		return $this->groups[ count($this->groups) - 1];
	}

	function current_group() {
		return $this->groups[ count($this->groups) - 1];
	}

	function create_field_index() {
		$this->field_index = array();
		foreach($this->groups as &$group) {
			foreach($group->fields as &$field) {
				if($field->name == '*') {
					// set
					$this->field_index[$field->join['table'] . '_set'] =& $field;
					$field->name = $field->join['table'] . '_set';
					$field->mapped = true;
				} else {
					// basic
					$this->field_index[$field->name] =& $field;
				}
			}
		}
	}

	function find_field($field_name) {
		if(isset($this->field_index[$field_name])) {
			return $this->field_index[$field_name];
		} else {
			return false;
		}
	}

	function repopulate() {

		$expected_fields = array();
		$parsed_fields = array();

		foreach($this->field_index as &$field) {
			if( ($field->availability == 'always' || $field->availability == $this->mode) && $field->read_only == false) {
				$expected_fields[$field->name] =& $field;
			}
			unset($field);
		}

		foreach($_POST as $key => $value) {
			$post_value = $this->controller->input->post($key);
			$field =& $this->find_field($key);
			if($field) {
				if( get_parent_class($field) == 'CIID_Field_Basic' || get_parent_class($field) == 'CIID_Field_Single_Selectable' ) {
					$field->value = $post_value;
				} elseif(get_parent_class($field) == 'CIID_Field_Multi_Selectable') {
					if( is_array($value) ) {
						$field->chosen_options = $value;
					} else {
						$field->chosen_options = array();
					}
				}
				$parsed_fields[] = $field->name;
			}
			unset($field);
		}

		foreach($expected_fields as &$field) {
			// expected values that got posted as nothing or ''
			// we will set them to blank
			if(!in_array($field->name, $parsed_fields)) {
				if( get_parent_class($field) == 'CIID_Field_Basic' || get_parent_class($field) == 'CIID_Field_Single_Selectable' ) {
					$field->value = '';
				} elseif(get_parent_class($field) == 'CIID_Field_Multi_Selectable') {
					$field->chosen_options = array();
				}
			}
		}
	}

	function _post_to_options() {
	}

	function render() {
		switch($this->mode) {

			case 'add' :
				$action = 'Add';
			break;

			case 'edit' :
				$action = 'Edit';
			break;

			case 'clone' :
				$action = 'Clone';
			break;

		}

		addScript('assets/css/jquery.ui/jquery-ui-1.8.6.custom.css', 'css');
		addScript('assets/js/form.js');

		addScript('assets/js/redactor/redactor.css', 'css');
		addScript('assets/js/redactor/init.js');
		addScript('assets/js/redactor/redactor.min.js');

		addScript('assets/js/tinymce/jscripts/tiny_mce/jquery.tinymce.js');
		addScript('assets/js/tinymce/jscripts/tiny_mce/plugins/tinybrowser/tb_tinymce.js.php');
		addScript('assets/js/wsywig.js');

		if (!isset($this->controller->tpl->page))
			$this->controller->tpl->page = new stdClass();

		$this->controller->tpl->scripts	 = $this->controller->script['javascript'];
		$this->controller->tpl->css			= $this->controller->script['css'];
		$this->controller->tpl->page->title = $this->controller->plural . ' &gt; ' . $action;
		$this->controller->log_link();

		if(count($this->throw_errors) > 0) {
			$this->output .= '<ul class="error_wrapper" style="margin:0;">';
			foreach($this->throw_errors as $error)
				$this->output .= '<li>' . $error . '</li>';
			$this->output .= '</ul>';
		}

		$a_group_has_errors = false;
		foreach($this->groups as $group) {
			if( count($group->errors) > 0) {
				$a_group_has_errors = true;
			}
		}

		// if form has errors somewhere show a global error view at the top
		if ($this->has_errors && $a_group_has_errors) {
			$this->output .= '<ul class="error_wrapper" style="margin:0;">';
			foreach($this->groups as $group) {
				if($group->availability != 'always' && $group->availability != $this->mode) {
					continue;
				}
				if( count($group->errors) > 0) {
					foreach($group->errors as $error) {
						$this->output .= '<li>' . $error . '</li>';
					}
				}
			}
			$this->output .= '</ul>';
		}

		$this->output .= '<form method="post" enctype="multipart/form-data">';

		if($this->controls == 'always' || $this->controls == $this->mode) {
			$this->output .= '<div class="top_buttons">';
			$this->output .= '<a class="btn_sml meta_bold_hover" href="'.site_url('modules/' . $this->controller->router->class).'"><span>CANCEL</span></a>';
			if($this->allow_save == 'always' || $this->allow_save == $this->mode) {
				$this->output .= '<button type="submit" name="submit" id="submit_top" class="btn_sml meta_bold_hover" value="SAVE"><span>SAVE</span></button>';
			}
			$this->output .= '</div>';
		}
		$this->output .= '<div class="clearer"></div>';
		$i = 0;
		foreach($this->groups as $group) {
			if($group->availability != 'always' && $group->availability != $this->mode) {
				continue;
			}
			$this->output .= '<div class="page_header_corner">
								<div class="page_header" style="cursor:pointer" onclick="//$(\'#panel_' . $i . '\').stop(true,true).slideToggle();">
									<div>' . $group->label . $group->inner_html . '</div>
								</div>
							  </div>';

			if (count($group->errors) > 0 && !$a_group_has_errors) {
				$this->output .= '<ul class="error_wrapper" style="margin:0;">';
				foreach($group->errors as $error) {
					$this->output .= '<li>' . $error . '</li>';
				}
				$this->output .= '</ul>';
			}

			$this->output .= '<div id="panel_' . $i . '">';
			$has_html = false;
			if(count($group->htmls) > 0) {
				$has_html = true;
			}
			$j = 0;
			foreach($group->fields as $field) {
				if($has_html) {
					if(isset($group->htmls[$j])) {
						$this->output .= $group->htmls[$j];
						unset($group->htmls[$j]);
					}
				}
				if($field->availability == 'always' || $field->availability == $this->mode) {
					if($field->read_only) {
						$this->output .= "
							<div class='element_wrapper'>
								<label class='left'>
									{$field->label}
								</label>
								<div style='margin:0; padding: 10px 0 0 130px;'>
									{$field->value}
								</div>
								<div class='clearer'></div>
							</div>";
					} else {
						$this->output .= $field->render();
					}
				}
				$j++;
				if($has_html) {
					if(isset($group->htmls[$j])) {
						$this->output .= $group->htmls[$j];
						unset($group->htmls[$j]);
					}
				}
			}

			if(count($group->fields) == 0) {
				if($has_html) {
					foreach($group->htmls as $html) {
						$this->output .= $html;
					}
				}
			}

			$i++;
			$this->output .= '</div>';
		}

		if($this->controls == 'always' || $this->controls == $this->mode) {
			$this->output .= '<a class="btn_sml meta_bold_hover" href="'.site_url('modules/' . $this->controller->router->class).'"><span>CANCEL</span></a>';
			if($this->allow_save == 'always' || $this->allow_save == $this->mode) {
				$this->output .= '<button type="submit" name="submit" id="submit_bottom" class="btn_sml meta_bold_hover" value="SAVE"><span>SAVE</span></button>';
			}
		}

		$this->output .= '<div class="clearer"></div>';
		$this->output .= '</form>';

		return $this->output;
	}
}

class CIID_Group {

	var $label;
	var $fields = array();
	var $form;
	var $errors = array();
	var $htmls = array();
	var $availability = 'always';
	var $show_when_not_available = false;
	var $inner_html = '';

	function __construct(&$form, $label='') {
		$this->form = $form;
		$this->label = $label;
		return $this;
	}

	function add_field($name = '', $label = '', $type = '', $config = array()) {
		$field_class = 'CIID_' . $type;

		if(class_exists($field_class)) {
			$this->fields[] = new $field_class($this, array('label' => $label, 'name' => $name, 'config' => $config) );
		} else {
			die($field_class . ' does not exist');
		}

		return $this->fields[count($this->fields) - 1];
	}

	function element() {
		// element only
	}

	function inner_html($html) {
		$this->inner_html .= $html;
		return $this;
	}

	function html($html) {

		$count = count($this->fields);

		if( isset($this->htmls[ $count ] )) {
			$this->htmls[ $count ] .= $html;
		} else {
			$this->htmls[ $count ] = $html;
		}

		return $this;
	}

	function set_availability($mode='always', $show = false) {
		$this->availability = $mode;
		$this->show_when_not_available = $show;
		return $this;
	}
}

abstract class CIID_Field {

	var $label;
	var $name;
	var $config;
	var $attributes = array();
	var $rules;
	var $field;
	var $group;
	var $availability = 'always'; // available always, add or edit
	var $show_when_not_available = false;
	var $detach = false; // detach from actual form -- dont save or try to save ??
	var $html;
	var $ignore = false;
	var $read_only = false;
	var $errors = array();
	var $classes = array();
	var $mapped = false;
	var $urlify = false;
	var $url_field;
	var $footnote = '';
	var $placeholder = '';
	var $nofield = false;

	function __construct(&$group, $params) {

		$this->group = $group;
		$this->name = $params['name'];
		$this->label = $params['label'];

		foreach($params['config'] as $key => $value) {
			$this->config[$key] = $value;
		}

		$this->init(); // fake constructor for extended fields
		return $this;

	}

	function init() {
	}

	function set_default($value = '') {
		if ($value != '') {
			$this->value = $value;
		}

		return $this;
	}

	function validate($rules='') {
		$this->rules = $rules;
		return $this;

	}

	function add_class($class_name='') {
		$this->classes[] = $class_name;
		return $this;
	}

	function append() {
		return $this;
	}

	function add_field($label='', $name='', $type, $config=array()) {
		return $this->group->add_field($label, $name, $type, $config);
	}

	function set_availability($mode='always', $show=false) {
		$this->availability = $mode;
		$this->show_when_not_available = $show;
		return $this;
	}

	function read_only($read_only = true) {
		$this->read_only = $read_only;
		if($read_only) {
			$this->ignore = true;
		}

		return $this;
	}

	function readonly() {
		$this->read_only();
		return $this;
	}

	function html($html) {
		return $this->group->html($html);
	}

	// do not create a related field in database table
	function nofield() {
		$this->nofield = true;
		return $this;
	}

	function render(&$form) {
		$form->text($this->name,$this->name,$this->name);
	}

	function _basic_wrapper($label, $input) {
		return '<div class="element_wrapper">'
					. '<label class="left">' . $label . '</label>'
					. $input
					. ($this->footnote != '' ? '<div style="padding-left:130px; padding-bottom:5px; clear:both"><strong>' . $this->footnote . '</strong></div>' : '')
					. '<div class="clearer"></div>'
			 . '</div>';
	}

	function urlify($to_field) {
		$this->urlify = true;
		$this->url_field = $to_field;
		return $this;
	}

	function thumbify($to_field, $width, $height) {
		if( get_class($this) != 'CIID_image') {
			die('CANNOT thumbify a non image field');
		}
		$this->thumbify = true;
		$this->thumb_params[] = array(
			'field' => $to_field,
			'width' => $width,
			'height' => $height,
		);

		return $this;
	}

	function footnote($str) {
		$this->footnote = $str;
		return $this;
	}

	function placeholder($str) {
		if (get_class($this) != 'CIID_textbox') {
			die('CANNOT use placeholder on non textbox field');
		}

		$this->placeholder = $str;
		return $this;
	}

}

abstract class CIID_Field_Binary extends CIID_Field {

	var $temp;
	var $file = array();
	var $value;

	function delete_checkbox() {
		if(strpos($this->rules, 'required') === FALSE) {
			if($this->value != '') {
				return "<input style='float:right;width:auto;margin:0 5px 0 0;' type='checkbox' name='delete_binary[{$this->name}]' />
					<span style='display:block;float:right;background:url(".base_url()."assets/images/deny_icon.png);width:20px;height:20px;' /></span>";
			}
		}
	}

	function do_upload() {
		if(isset($_FILES[$this->name])) {
			$file = $_FILES[$this->name];
			if(@$file['name'] == '') {
				return false;
			}

			$ext = get_extension($file['name']);
			$name = get_without_extension($file['name']);
			if($this->accepted_types != '*')  {
				if(!in_array(trim(strtolower($ext)), $this->accepted_types)) {
					die('Invalid File Type ' . $ext);
				}
			}

			$rename = true;
			$name = preg_replace("/[^a-z0-9-_]+/i", '', $name);
			$current_name = $name . '.' . $ext;
			$increment = 1;
			while($rename) {
				if(file_exists('..' . RESOURCE_PATH . $current_name)) {
					$current_name = $name . '(' . $increment++ . ').' . $ext ;
				} else {
					$this->file = $current_name;
					$rename = false;
				}
			}

			$this->temp = 'temp/' . $file['name'];

			if(move_uploaded_file($file['tmp_name'], $this->temp)) {
				// need some way of handling errors via this function
				if($this->process()) {
					$this->_clear();
					return true;
				} else {
					$this->_clear();
					return false;
				}
			} else {
				die('File upload error');
			}
		}
	}

	function _clear() {
		if(file_exists($this->temp)) {
			unlink($this->temp);
		}
	}


	function process() {
		// made to be overridden by each file type
		return false;
	}

}

abstract class CIID_Field_Basic extends CIID_Field {

	var $value;
	function _validate() {
	}

	function value() {
		return $this->value;
	}

}

abstract class CIID_Field_Selectable extends CIID_Field {

	var $foreign_table;
	var $foreign_key;

	function join($table, $args=array()) {

		$this->foreign_table = $table;
		$this->foreign_key = $table . '_id';
		$this->join = array('table' => $table, 'args'=>$args);

		return $this;
	}

	/* set_options
		accepts array in format of
		array(
			array( 'label' => $label, 'value' => $value),
			array( 'label' => $label, 'value' => $value),
		);
	*/
	function set_options($options=array()) {

		// manually set options
		$this->available_options = $options;
		return $this;
	}

	/* set_chosen_options
		accepts array in format of
		array(1,3,6); (ids for example)
	*/
	function set_chosen_options($options=array()) {

		// manually set CHOSEN options
		$this->chosen_options = $options;
		return $this;
	}

	function _get_available_options($type='checkbox') {

		if( is_array($this->join) && !isset($this->available_options) ) {
			$result = $this->group->form->controller->model->get_options($this->join['table'], $this->join['args']);
			$options = extract_options($result, 'name', $this->join['table'] . '_id');
			return $options;
		} else {
			return $this->available_options;
		}
	}
}

abstract class CIID_Field_Single_Selectable extends CIID_Field_Selectable {

	var $available_options;
	var $value;
	var $join;

	function _validate() {

	}

	function value() {
		return $this->value;
	}
}

abstract class CIID_Field_Multi_Selectable extends CIID_Field_Selectable {

	//var $available_options = array();
	var $chosen_options = array();
	var $join;

	function _validate() {
	}

	function value() {
		return $this->chosen_options;
	}
}

class CIID_Option {

	var $label;
	var $value;
	var $current_value;

	function __construct($label, $value, $current_value = '') {
		$this->label = $label;
		$this->value = $value;
		$this->current_value = $current_value;
	}
}

class CIID_textbox extends CIID_Field_Basic {

	function render($element_only=false) {
		if($this->read_only) {
			$input = '<div class="form_value">' . $this->value . '</div>';
		} else {
			$input = '<input type="text" class="form_text '.implode(' ' , $this->classes).'" id="'.elt($this->name).'" value="'.elt($this->value).'" name="'.elt($this->name).'" placeholder="'.$this->placeholder.'" />';
		}

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}
}

class CIID_hidden extends CIID_Field_Basic {
	function render($element_only=false) {
		return '<input type="hidden" id="' . elt($this->name) . '" name="' . elt($this->name) . '" value="' . elt($this->value) . '" />';
	}
}

class CIID_checkbox_group extends CIID_Field_Multi_Selectable {

	function render($element_only=false) {

		$this->available_options = $this->_get_available_options();
		$input = '<div style="padding:5px 0px 5px 0px;float:left;width:570px">';
		$i = 0;

		foreach($this->available_options as $option) {
			$input .= '<div class="checkbox_wrapper">'
						. '<input id="' . $this->name . '_' . $i . '" class="form_checkbox" type="checkbox" title="' . elt($option['label']) . '" value="' . $option['value'] . '" name="' . $this->name . '[]" ' . (in_array($option['value'], $this->chosen_options) || (count($this->chosen_options) == 0 && in_array($option['value'], is_array(@$this->value) ? $this->value : array()))  ? 'checked="checked"' : '') . ' />'
						. '<label class="check" for="'. $this->name . '_' . $i++ . '" title="' . elt($option['label']) . '">' . $option['label']. '</label>'
					. '</div>';
		}
		$input .= '<div class="clearer"></div>';
		$input .= '</div>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}

	}

}
/*
 *   This is can be used for radio buttons tooo -  use set options  example 	->add_field('comments', 'Comments', 'radio_group')->set_options($radio) // $radio array
 */
class CIID_radio_group extends CIID_Field_Single_Selectable {

	function render($element_only=false) {
	    $options = array();
		$this->available_options = $this->_get_available_options('checkbox');
		$options = $this->available_options;
		//$form->radiogroup($this->name, $this->available_options, $this->label, array(), $this->rules);
		$input = '<div style="padding:5px 0px 5px 0px">';
		$i=0;
		if(is_array($options)){
			foreach($options as $option) {
				# setting for default value
				if(empty($this->value) && isset($option['default'])){
					$this->value = $option['default'];
				}
				$input .= '<div class="checkbox_wrapper">'
					. '<input id="' . $this->name . '_' . $i . '" class="form_checkbox" type="radio" title="' . elt($option['label']) . '" value="' . $option['value'] . '" name="' . $this->name . '" ' . ( $option['value'] == $this->value ? 'checked="checked"' : '') . ' />'
					. '<label class="check" title="' . elt($option['label']) . '" for="'. $this->name . '_' . $i++ . '">' . $option['label']. '</label>'
					. '</div>';

			}
		}

		$input .= '<div class="clearer"></div>';
		$input .= '</div>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}

	}

}



class CIID_checkbox extends CIID_Field_Basic {

	function render($element_only=false) {
		$input = '<input class="form_checkbox" id="' . elt($this->name) . '" type="checkbox" name="' . $this->name . '" value="1" ' . ($this->value ? 'checked="checked"' : '') . ' />';
		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}
}

class CIID_select extends CIID_Field_Single_Selectable {

	function render($element_only=false) {

		$this->available_options = $this->_get_available_options('x');

		$input = '<select class="form_select" name="' . $this->name . '" id="' . elt($this->name) . '">';
		$input .= '<option value="">Please Select</option>';
		foreach($this->available_options as $option) {

			$input .= '<option value="' . $option['value'] . '"' . ($option['value'] == $this->value || ($this->value == "" && @$option['default']) ? ' selected="selected"' : '') . '>' . $option['label'] . '</option>';

		}
		$input .= '</select>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}

	}

}

class CIID_multiselect extends CIID_Field_Multi_Selectable {

	function render($element_only=false) {

		$this->available_options = $this->_get_available_options();
		$input = '<div class="ms_container">';
		$input .= '<select size="2" class="ms_list ms_list_out" id="ms_' . $this->name . '">';
		$chosen_options = array();
		$i=0;

		foreach($this->available_options as $option) {
			if(in_array($option['value'], $this->chosen_options)) {
				$chosen_options[] = array('label' => $option['label'], 'value' => $option['value'], 'index' => $i);
			} else {
				$input .= '<option value="' . $option['value'] . '" data-id="' . $i . '">' . $option['label'] . '</option>';
			}
			$i++;
		}

		$input .= '</select>';
		$input .= '<a href="javascript:void(0)" class="ms_out">&lt;</a>';
		$input .= '<a href="javascript:void(0)" class="ms_in">&gt;</a>';
		$input .= '<select size="2" class="ms_list ms_list_in" id="' . $this->name . '_chosen" name="' . $this->name . '[]">';
		foreach($chosen_options as $chosen_option) {
			$input .= '<option value="' . $chosen_option['value'] . '" data-id="' . $chosen_option['index'] . '">' . $chosen_option['label'] . '</option>';
		}

		$input .= '</select>';
		$input .= '</div>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}

	}

}

class CIID_textarea extends CIID_Field_Basic {

	function render($element_only=false) {

		$input = '<textarea class="form_textarea ' . implode(' ' , $this->classes) . '" id="' . elt($this->name) . '" name="' . $this->name . '">' . $this->value . '</textarea>';
		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}
}

class CIID_textarea_mce extends CIID_Field_Basic {

	var $browser = false;

	function render($element_only=false) {
		$input = '<textarea class="editor large" name="' . $this->name . '">' . $this->value . '</textarea>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}

	}


}

class CIID_textarea_mce_light extends CIID_Field_Basic {

	var $browser = false;

	function render($element_only=false) {
		//$form->textarea($this->name,$this->label, $this->rules, $this->value, array('class' => 'editor small'));
		$input = '<textarea class="editor-light medium" name="' . $this->name . '">' . $this->value . '</textarea>';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}
}

class CIID_file extends CIID_Field_Binary {

	var $accepted_types  = '*';
	function process() {
		$this->value = RESOURCE_PATH . $this->file;
		copy($this->temp, '..' . $this->value);
		return true;
	}

	function render($element_only=false) {

		$input = '<input type="file" name="' . $this->name . '" />';
		$input .= $this->delete_checkbox();
		if($this->value != '') {
			$input .= '<div class="clearer"></div>
						<label>&nbsp</label>
						<div>Current File: <a href="' . $this->value . '" target="_blank">' . $this->value . '</a></div>
						<div class="clearer"></div>';

		}
		return $this->_basic_wrapper($this->label, $input);
	}
}

class CIID_image_gallery extends CIID_Field_Binary {
	var $collection = array();
	/* TODO */
}

class CIID_image extends CIID_Field_Binary {

	var $thumbify;
	var $thumb_params = array();

	var $accepted_types = array('png', 'gif', 'jpg', 'jpeg');

	function process() {
		if(!file_exists($this->temp)) {
			return false;
		}

		// Validate Image
		if(@$this->config['width'] != '' || @$this->config['height'] != '') {
			// crop time
			$this->_auto_crop();
		}

		$this->value = RESOURCE_PATH . $this->file;
		copy($this->temp, '..' . $this->value);
		if(@$this->config['max'] != '') {
			$ci =& get_instance();
			$ci->load->library('image_tools');
			$path = '..' . $this->value;
			$image_size = getimagesize($path);
			$w = $image_size[0];
			$h = $image_size[1];

			if($w > @$this->config['max'] || $h > @$this->config['max']) {
				if($w > $h) {
					$this->config['width'] = $this->config['max'];
					$ratio = $w / $h;
					$this->config['height'] = $this->config['max'] / $ratio;
				} elseif($h > $w) {
					$this->config['height'] = $this->config['max'];
					$ratio = $h / $w;
					$this->config['width'] = $this->config['max'] / $ratio;
				} else {
					$this->config['width'] = $this->config['max'];
					$this->config['height'] = $this->config['max'];
				}

				$config = array(
					'source_image' 	=> $path,
					'width'			=> $this->config['width'],
					'height'		=> $this->config['height'],
					'master_dim'	=> isset($this->config['master']) ? $this->config['master'] : '',
				);

				$ci->image_tools->resizeandcrop($config);
			}
		}

		if(@$this->thumbify) {
			// create thumbnail with _thumb inserted into the filename
			$ci =& get_instance();
			$ci->load->library('image_tools');
			$src = '..' . $this->value;
			$pathinfo = pathinfo($src);
			foreach($this->thumb_params as &$thumb_param) {
				$newfile = $pathinfo['dirname'] . '/' . $pathinfo['filename'] . '_' . $thumb_param['field'] . '.' . $pathinfo['extension'];
				copy($src, $newfile);

				// strip the dots at the start
				$thumb_param['new_name'] = substr($newfile,2);

				/* TODO AUTO Width or Height when not supplied */

				if($thumb_param['width'] != 0 && $thumb_param['height'] == 0) {
					$thumb_param['master'] = 'width';
				} elseif($thumb_param['height'] != 0 && $thumb_param['width'] == 0) {
					$thumb_param['master'] = ' height';
				}

				$config = array(
					'source_image' 	=> $newfile,
					'width'			=> $thumb_param['width'],
					'height'		=> $thumb_param['height'],
					'master_dim'	=> isset($thumb_param['master']) ? $thumb_param['master'] : '',
				);

				$ci->image_tools->resizeandcrop($config);
			}
		}

		return true;
	}

	function render($element_only=false) {

		// check if preview is on
		$input = '<input type="file" name="' . $this->name . '" id="' . $this->name . '" />
					' . $this->delete_checkbox() . '
					<div class="clearer"></div>';

		if(@$this->config['preview'] && @$this->value != '' ) {
			$input .= '<div class="element_wrapper">';
			if(@$this->config['toolkit']) {
				// Cropper and rotator
				$input .= '<div style="float:left; width:100px; padding-top:8px; margin:5px 15px;">';
				$input .= 'Current Image:<br />';
				$input .= '<a class="image_crop_trigger" href="javascript:void(0);" data-table="' . $this->group->form->controller->table .'" data-id="' . $this->group->form->controller->record->pk() . '" data-name="' . $this->name . '" data-width="' . $this->config['width'] . '" data-height="' . $this->config['height'] . '">crop</a>';
				$input .= '&nbsp|&nbsp;';
				$input .= '<!--<a class="image_delete_trigger" href="javascript:void(0);" data-table="' . $this->group->form->controller->table .'" data-id="' . $this->group->form->controller->record->pk() . '" data-name="' . $this->name . '">delete</a>-->';
				$input .= '</div>';
			} else {
				$input .= '<label>Current Image:</label>';
			}

			$width = "";
			if (file_exists('../'.$this->value)) {
				$a = getimagesize('../'.$this->value);
				if ($a[0] > 705) {
					$width = 'width="705"';
					$src = 'src="/tt?src=' . urlencode($this->value) . '&w=705"';
				} else {
					$src = 'src="' . $this->value . '"';
				}
			}
			if (isset($src))
				$input .= '<div style="padding-top:12px">' . str_replace(RESOURCE_PATH, '',  $this->value) . '<br /><img id="' . $this->name . '_image' .'" '.$src.' '.$width.' /></div>	';
			$input .= '</div>';
		}

		return $this->_basic_wrapper($this->label, $input);
	}

	function _auto_crop() {
		// get settings
		$ci =& get_instance();
		$ci->load->library('image_tools');
		$config = array(
			'source_image' 	=> $this->temp,
			'width'			=> $this->config['width'],
			'height'		=> $this->config['height'],
			'master_dim'	=> isset($this->config['master']) ? $this->config['master'] : '',
		);
		$ci->image_tools->resizeandcrop($config);
	}

	function _rotate() {
	}

	function _crop() {
	}

	function _load_image() {
		return imagecreatefromstring(file_get_contents($this->temp));
	}
}



class CIID_date extends CIID_Field_Basic {

	function render($element_only=false) {

//                $display = '';


		if ($this->value) {
			$display = date('d/m/Y', strtotime($this->value));
                } else {
                    $display = $display = date('d/m/Y', time());
                }

		if ($display == '00/00/0000' || $display == '01/01/1970') {
                        $display = date('m/d/Y h:i:s a', time());
                } else {
                    $display = $display = date('d/m/Y', time());
                }

                $input = '<input type="text" class="datepicker" value="' . $display . '" link_to="' . $this->name . '" readonly="readonly" /><input id="' . $this->name . '" type="hidden" name="' . $this->name . '" value="' . $this->value . '" />';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}

}

/**
 *  @jai written
 */
class CIID_time extends CIID_Field_Basic {

	function render($element_only=false) {

		$display = '';

		if ($this->value) {
			$display = date('H:i:s', strtotime($this->value));
		}

		// if ($display == '00/00/0000' || $display == '01/01/1970') {
		// 	$display = '';
		// }
		//$input = '<input type="text" class="datepicker" value="' . $display . '" link_to="' . $this->name . '" readonly="readonly" /><input id="' . $this->name . '" type="hidden" name="' . $this->name . '" value="' . $this->value . '" />';
		 $input='<input id=" " type="text"  value="' . $display . '" class="time ui-timepicker-input basicTimeselector" link_to="' . $this->name . '"  autocomplete="off"><input class="jairam" id="' . $this->name . '" type="hidden" name="' . $this->name . '" value="' . $this->value . '"  />';
		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}

}

/**
 *  @jai written password
 */
class CIID_password extends CIID_Field_Basic {

	function render($element_only=false) {

		$password_value  = '';

		if ($this->value) {
			$password_value = md5($this->value);
		}


		if($this->read_only) {
			$input = '<div class="form_value">' . $password_value . '</div>';
		} else {
			$input = '<input type="password" class="form_text '.implode(' ' , $this->classes).'" id="'.elt($this->name).'" value="'.elt($password_value).'" name="'.elt($this->name).'" placeholder="'.$this->placeholder.'" />';
		}

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}

}

class CIID_datetime extends CIID_Field_Basic {

	function render($element_only=false) {

		$input = '<input type="text" class="datetimepicker" value="' . ($this->value ? date('d/m/Y H:i:s', strtotime($this->value)) : '') . '" link_to="' . $this->name . '" readonly="readonly" /><input id="' . $this->name . '" type="hidden" name="' . $this->name . '" value="' . $this->value . '" />';

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}

}





class CIID_custom extends CIID_Field {
	function render($element_only=false) {

		if($element_only) {
			return $input;
		} else {
			return $this->_basic_wrapper($this->label, $input);
		}
	}
}

class CIID_foreign extends CIID_Field {
	var $fields = array();
	var $where = array();
	var $parent_id;
	function render($element_only = false) {
		$output = "
			<div id='{$this->name}'></div>
			<div class='edit_embedded' id='{$this->name}-edit'></div>
			<script>
				reload_embedded('{$this->name}', '{$this->foreign_key}', {$this->parent_id});
			</script>
			";
		return $this->_basic_wrapper($this->label, $output);
	}

	function set_options($options) {
		$this->fields = $options['fields'];
		return $this;
	}

	function set_fields() {
	    $this->fields = array_slice(func_get_args(), 0);
		return $this;
	}

	function set_foreign_key($foreign_key, $foreign_id) {
		$this->foreign_key = $foreign_key;
		$this->parent_id = $foreign_id;
		return $this;
	}

	function where($str) {
		$this->where[] = $str;
		return $this;
	}
}

	class CIID_map extends CIID_Field_Basic {

		function render ($element_only = false) {

			if (!isset($this->value)) {
				$this->value = '-27, 135';
			}

			$input = "
        <div class='myid-map-wrapper'>
            <div style='float: left;'><br />Search: &nbsp; </div>
			<input type='text' class='my-map-search' id='{$this->name}-search' style='width: 504px;' />
            <input type='hidden' class='myid-map-id' value='{$this->name}' />
            <div style='clear: both;'></div>
            <div class='myid-map' id='{$this->name}-map'></div>
            <input type='hidden' id='myid-map-coordinates-{$this->name}' class='myid-map-value' name='{$this->name}' value='{$this->value}' /><br />
        </div>
        ";

			if($element_only) {
				return $input;
			} else {
				return $this->_basic_wrapper($this->label, $input);
			}
		}
	}


	/* TODO */

/* BETTER WAY TO BUILD EACH ELEMENT
foreach($this->attributes as $key => $value) {

	$this->input.= ' ' . $key . '="'. htmlentities($value) . '"';

}
*/
