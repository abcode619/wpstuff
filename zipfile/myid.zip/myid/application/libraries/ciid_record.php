<?php

class CIID_Record {
	
	var $controller;
	var $table;
	var $primary_key;
	
	private $items = array();
	private $sets = array();
	
	function __construct(&$c) {
	
		$this->controller =& $c;
		$this->table = $this->controller->table;
		
		if($this->controller->primary_key == '') {
			$this->primary_key = $this->table . '_id';
		} else {
			$this->primary_key = $this->controller->primary_key;
		}
	}
	
	function build_record() {
		// build object structure based on form or table?
		$this->items = array();
		$this->sets = array();
		
		$columns = $this->controller->model->get_table_structure($this->table);
		foreach($columns as $column) {
			$this->add_item($column->Field, '',  $this->controller->form->find_field($column->Field));
		}
		
		foreach($this->controller->form->groups as &$group) {
			foreach($group->fields as &$field) {
				if($field->mapped) {
					$this->add_sets($field->name, array(), $field);
				}
			}		
		}
	}
	
	function load_record($id) {
		//$this->build_record();
		$loaded_record = $this->controller->model->load_record($id);
		foreach($loaded_record['basics'] as $key => $value) {
			// load values into fields
			$field =& $this->controller->form->find_field($key);			
			if($field) {
				$field->value = $value;
			}	
			$this->add_item($key, $value, $field);
		}
		
		foreach($loaded_record['sets'] as $key => $value) {
			$field =& $this->controller->form->find_field($key);	
			if($field) {
				if( is_array($value) ) {
					if( count($value) > 0) {
						foreach($value as $row) {
							$field->chosen_options[] = $row->{$field->foreign_key};
						}
					} else {
						$field->chosen_options = array();
					}
				} else {
					$field->chosen_options =  array();
				}
				$this->add_sets($key, $field->chosen_options, $field);
			}
		}
	}
	
	function get_values_from_form() {
		foreach($this->items as &$item) {
			if(isset($item->field)) {
				if(@!$item->field->ignore) {
					if(method_exists($item->field, 'value')) {
						$item->value = $item->field->value();
					} elseif(method_exists($item->field, 'do_upload')) {
						if($item->field->do_upload()) {
							$item->value = $item->field->value;
						}
					}
				}
			}
		}
		
		foreach($this->sets as &$set) {
			if(isset($item->field)) {
				if(@!$item->field->ignore) {
					if(method_exists($set->field, 'value')) {
						$set->chosen_options = $set->field->value();
					}
				}
			}
		}
	}
	
	function save() {
		// to save we need
		// tablename, fields + mappings
		if($this->controller->model->save($this)) {
			return true;
		} else {
			return false;
		}
	}
	
	function delete() {
		// to delte we need
		// tablename + mappings
		if($this->controller->model->delete($this)) {
			return true;
		} else {
			return false;
		}
	}
	
	function pk() {
		return @$this->item($this->primary_key)->value;
	}
	
	function set_pk($value) {
		$this->item($this->primary_key)->value = $value; 
	}
	
	function add_item($key, $value, &$field) {
		$this->items[$key] = new CIID_Record_Item_Basic($value, $field);
	}
	
	function title_item() {
		return @$this->item($this->controller->title_key)->value;
	}
	
	function item($key) {
		if(isset($this->items[$key])) {
			return $this->items[$key];
		} else {
			return false;
		}
	}

	function unset_item($key) {
		unset($this->items[$key]);
	}
	
	function get_items() {
		return $this->items;
	}
	
	function set_item($key, $value) {
		if(isset($this->items[$key])) {
			$this->items[$key]->value = $value;
		} else {
			return false;
		}
	}
	
	function add_sets($key, $chosen_options, &$field) {
		$this->sets[$key] = new CIID_Record_Item_Set($chosen_options, $field);
	}
	
	function sets($key) {
		if(isset($this->sets[$key])) {
			return $this->sets[$key];
		} else {
			return false;
		}
	}
	
	function get_sets() {
		return $this->sets;
	}
	
	function set_sets($key, $value) {
		if(isset($this->sets[$key])) {
			$this->sets[$key]->chosen_options = $value;
		} else {
			return false;
		}
	}
}

class CIID_Record_Item {
	var $field; // reference to field
}

class CIID_Record_Item_basic extends CIID_Record_Item {
	var $value;
	function __construct($value, &$field) {
		$this->value = $value;
		$this->field = $field;
	}
}

class CIID_Record_Item_Set extends CIID_Record_Item {
	var $chosen_options = array();
	function __construct($chosen_options, &$field) {
		$this->chosen_options = $chosen_options;
		$this->field = $field;
	}
}
