<?php

class Image_tools {
	/*
	 * Version 1.1
	 * -
	 * Usage:
	 * resizeandcrop(array(
	 *	 'source_image' => ''
	 *	 'width'		=> 0
	 *	 'height'	   => 0
	 *	 'master_dim'   => 'width/height'  (optional)
	 *	 'create_thumb' => TRUE/FALSE  (optional)
	 * ))
	 *
	 * 'create_thumb' hasn't really been tested
	 */

	public function resizeandcrop($config) {
		if (@$config['create_thumb']) {
			$pathinfo = pathinfo($config['source_image']);
			$newfile = $pathinfo['dirname'] . '/' . $pathinfo['filename'] . '_thumb.' . $pathinfo['extension'];
			copy($config['source_image'], $newfile);

			$config['source_image'] = $newfile;
		}
		return $this->process($config);
	}

	private function process($config) {
		$file = $config['source_image'];

		if (@$config['master_dim'])
			$master_dim = $config['master_dim'];
		else
			$master_dim = false;

		if (!file_exists($file))
			show_error("File not found: '{$file}'");

	  
		$CI = & get_instance();
		$CI->load->library('image_lib');

		$result = true;

		list($src_width, $src_height, $type, $attr) = getimagesize($file);

		if (!$master_dim) {
			$config_resize['master_dim'] = 'width';
			$resize_width = $config['width'];
			$resize_height = round($src_height / $src_width * $config['width']);

			$config_resize['maintain_ratio'] = TRUE;
		   
			if ($resize_height < $config['height'])
				$config_resize['master_dim'] = 'height';

			if ($resize_height > $config['height'])
				$config_resize['master_dim'] = 'width';

		} else {
			$config_resize['maintain_ratio'] = TRUE;
			$config_resize['master_dim'] = $master_dim;
		}


		$config_resize = array_merge($config_resize, array(
			'image_library' => 'gd2',
			'quality' => '90%',
			'source_image' => $file,
			'width' => $config['width'],
			'height' => $config['height'],
		));



		$CI->image_lib->initialize($config_resize);
		if (!$CI->image_lib->resize())
			$result = false;


		// convert to jpg
		//$CI->image_lib->convert('jpg', TRUE);


		if (!$master_dim) {

			list($src_width, $src_height, $type, $attr) = getimagesize($file);

			$config_crop['source_image'] = $file;


			if ($config['width'] > $config['height'] || $config['width'] > $src_width) {
				$crop = ($src_height - $config['height']);
				$config_crop['x_axis'] = 0;
				$config_crop['y_axis'] = $crop / 2;
			}
			if ($config['height'] > $config['width'] || $src_width > $config['width']) {
				$crop = ($src_width - $config['width']);
				$config_crop['x_axis'] = $crop / 2;
				$config_crop['y_axis'] = 0;
			}

			$config_crop['width'] = $config['width'];
			$config_crop['height'] = $config['height'];
			$config_crop['maintain_ratio'] = FALSE;


			$CI->image_lib->clear();

			$CI->image_lib->initialize($config_crop);

			if (!$CI->image_lib->crop())
				$result = false;

		}
		return $result;
	}

}
