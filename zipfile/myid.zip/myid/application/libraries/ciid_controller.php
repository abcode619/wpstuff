<?php

class CIID_Controller extends MY_Controller {

	var $table; // associated table
	var $primary_key;
	var $groups = array(); // collapseable panels
	var $overview;
	var $embedded;
	var $searchable = false; // cant be both searchable and sortable
	var $search_fields = array('name');
	var $search_config = array();
	var $sortable = false; // cant be both searchable and sortable
	var $singular;
	var $plural;
	var $record;
	var $title_key = 'name'; // name of field for title
	var $relationships = array();
	var $limit; // ADDED!. the number of records allowed - blank = unlimited
	var $allow_add = true;
	var $allow_edit = true;
	var $allow_delete = true;
	var $order_key = 'order_index';
	var $share_group;
	var $share_key;
	var $share_value;
	// jai added
	var $group_key = '';
	//jai added
	var $image_settings = array(
		'max' => 1000,
		'preview' => TRUE,
	);
	var $status = array (
				 array ( 'label'   => 'Online',
				        'value'   => '1',
				        'colour'  => '#3C3',
				        'default' => true ),
			  	array ( 'label'  => 'Offline',
				        'value'  => '0',
				        'colour' => '#D00' ),
			);




	function __construct() {
		parent::__construct();
		require_once(APPPATH . '/libraries/ciid_form.php');
		require_once(APPPATH . '/libraries/ciid_record.php');
		addScript('assets/js/ajax.js');
		$this->config->load('ciid');
		$this->form = new CIID_Form($this, $this->router->method);
		$this->overview = new CIID_Overview($this);
		$this->embedded = new CIID_Overview($this);
		$this->current_id = intval($this->uri->segment(4)) ? intval($this->uri->segment(4)) : false;
	}

	function init() {
		$this->dumpsql();
		// initialise model
		$this->model = new CIID_Model($this);
		$this->record = new CIID_Record($this);
		$this->form->create_field_index(); // must be invoked before we build the record class
		$this->record->build_record();
		$this->_callback('before_load');
		//if ($this->router->method == 'edit' or preg_match('!^ajax_edit!', $this->router->method))
		if (preg_match('!^(ajax_edit|edit|switchvalue)!', $this->router->method))
			$this->record->load_record($this->uri->segment(4));

		$this->_callback('after_load');
		if(@$this->primary_key == '')
			$this->primary_key = $this->table . '_id';

		if($this->searchable) {
			if( count($this->search_config) == 0) {
				$this->search_config = array(
					'id' 	=> $this->primary_key,
					'name' 	=> 'name',
					'label' => 'name',
				);
			}
		}
	}

	function dumpsql($execute=true) {

		if (ACTIVE_GROUP == "local") {

			$sql = array();
			$sql[] = "CREATE TABLE IF NOT EXISTS `{$this->table}` (`{$this->table}_id` INT(10) NULL AUTO_INCREMENT, PRIMARY KEY (`{$this->table}_id`)) COLLATE='latin1_swedish_ci' ENGINE=MyISAM";

			$this->db->query($sql[0]);
			$current_fields = $this->db->list_fields($this->table);

			if (!in_array('created_date', $current_fields))
				$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `created_date` DATETIME NULL DEFAULT NULL";

			if (!in_array('updated_date', $current_fields))
				$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `updated_date` DATETIME NULL DEFAULT NULL";

			if (!in_array('order_index', $current_fields)) {
				$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `order_index` INT(11) NOT NULL DEFAULT '0'";
				$sql[] = "SET @pos = 0";
				$sql[] = "UPDATE `{$this->table}` SET order_index = @pos:=@pos+1 ORDER BY `created_date`";
			}

			$fields = array();
			$captured = array(); // retains a list of field types that dumpsql is aware of.
			foreach($this->form->groups as $kk => $vv) {
				foreach($vv->fields as $k => $v) {
					if ($v->nofield == false) {
						$object = get_class($v);
						$fields[] = $object;
						if ($object == "CIID_select") {
							if (!$v->available_options) {
								if (!in_array($v->name, $current_fields)) {
									// if no options, assume an INT field
									$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` INT(11) NOT NULL";
									$sql[] = "ALTER TABLE `{$this->table}` ADD INDEX `{$v->name}` (`{$v->name}`)";
								}
							} else {
								$enum = array();
								foreach($v->available_options as $opt)
									$enum[] = $opt['value'];
								if (!in_array($v->name, $current_fields))
									$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` ENUM("."'".join("', '", $enum)."'".") NULL DEFAULT NULL";
							}
							$captured[] = $object;
						}
						if ($object == "CIID_textbox") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` VARCHAR(255) NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_textarea" || $object == "CIID_textarea_mce" || $object == "CIID_textarea_mce_light") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` TEXT NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_file") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` VARCHAR(255) NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_image") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` VARCHAR(255) NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_map") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` VARCHAR(255) NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_date") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` DATE NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_datetime") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` DATETIME NULL DEFAULT NULL";

							$captured[] = $object;
						}
						if ($object == "CIID_checkbox") {
							if ( ! in_array($v->name, $current_fields))
								$sql[] = "ALTER TABLE `{$this->table}` ADD COLUMN `{$v->name}` TINYINT(1) NULL DEFAULT NULL";

							$captured[] = $object;
						}
					}
				}
			}

			$missed = array();
			foreach($fields as $field) {
				if ( ! in_array($field, $captured)) {
					$missed[] = $field;
				}
			}

			if (sizeof($missed) > 0)
				$sql[] = "/*No SQL was generated for: ".join(", ", $missed)."*/";

			if ($execute) {

				foreach($sql as $q)
					$this->db->query($q);
				//$sql[] = "/* this query was executed! */";
			}
			//print join("\n", $sql);
			// die();
		}
	}

	function set_table($table, $singular, $plural) {
		$this->table = $table;
		$this->singular = $singular;
		$this->plural = $plural;
	}

	function define_relationship($table, $type = '') {

		/* to be implemented */

		switch($type) {

			case 'one_to_many' :
				$this->relationships[] = array('table' => $table, 'local_key' => $this->primary_key, 'foreign_key' => $this->primary_key);
			break;

			case 'one_to_one' :
				$this->relationships[] = array('table' => $table, 'local_key' => $this->primary_key, 'foreign_key' => $this->primary_key);
			break;

			case 'many_to_one' :
				$this->relationships[] = array('table' => $table, 'local_key' => $this->primary_key, 'foreign_key' => $this->primary_key);
			break;

			case 'many_to_many' :
				$this->relationships[] = array('table' => $table, 'local_key' => $this->primary_key, 'foreign_key' => $this->primary_key);
			break;
		}
	}

	function add() {
		if(!$this->allow_add) {
			redirect( $this->router->class);
		}

		// refactor this to handle the post and redirection
		$this->_callback('before_add');
		if( isset($_POST['submit']) ) {
			$this->form->repopulate();
			$this->_callback('before_validate' ,'before_add_validate');
			if($this->form->validate()) {
				$this->record->get_values_from_form();
				$this->_callback('before_save', 'before_add_save');
				if($this->record->save()) {
					// for add
					$this->session->set_userdata('success', array(message_replace(RECORD_ADD_SUCCESS, $this->singular, $this->record->title_item())) );
					$this->_callback('after_save', 'after_add_save');
					redirect('modules/' . $this->router->class . '/edit/' . $this->record->pk());
				}
			} else {
				$this->session->set_userdata('failed', message_replace(RECORD_EDIT_SUCCESS, $this->singular, @$this->record->title_item()) );
			}
		}

		$this->_render();
		$this->_callback('after_add', 'cud');
	}

	function edit() {
		if (!$this->allow_edit)
			redirect($this->router->class);

		$this->form->mode = 'edit';
		// refactor this to handle the post and redirection
		$this->_callback('before_edit');
		if (isset($_POST['submit']) ) {
			$files_to_remove = array();
			// if new files have been selected, build array of existing files to remove
			foreach($this->form->groups as $kk => $vv) {
				foreach($vv->fields as $k => $v) {
					$object = get_class($v);
					if ($object == 'CIID_image' || $object == 'CIID_file') {
						if ($_FILES[$v->name]['size'] > 0) {
							// a file was uploaded, remove old one
							$files_to_remove[] = $this->record->item($v->name)->value;
						}
					}
				}
			}

			$this->form->repopulate();
			$this->_callback('before_validate' ,'before_edit_validate');
			if($this->form->validate()) {
				$this->record->get_values_from_form();
				$this->_callback('before_save', 'before_edit_save');
				// if new files have been selected, remove the old ones
				foreach($files_to_remove as $file)
					if (file_exists('..' . $file) && !is_dir('..'.$file))
						unlink('..' . $file);

				// checkbox checked, remove file and empty field
				if (isset($_POST['delete_binary'])) {
					foreach($_POST['delete_binary'] as $field => $value) {
						if (file_exists('..' . $this->record->item($field)->value))
							unlink('..' . $this->record->item($field)->value);
						$this->record->set_item($field, "");
					}
				}

				if($this->record->save()) {
					// for edit
					$this->session->set_userdata('success', array(message_replace(RECORD_EDIT_SUCCESS, $this->singular, $this->record->title_item())) );
					$this->_callback('after_save', 'after_edit_save', 'cud');
					redirect('modules/' . $this->router->class . '/edit/' . $this->record->pk());
				}
			} else {
				$this->session->set_userdata('failed', message_replace(RECORD_EDIT_SUCCESS, $this->singular, @$this->record->title_item()) );
			}
		}

		$this->_render();
		$this->_callback('after_edit', 'cud');
	}

	public function switchvalue($id, $field) {
		foreach ($this->overview->fields as $f)
			if ($f['field'] == $field)
				break;
                $this->_callback('before_save', 'before_edit_save');
		$this->model->switchvalue($this->table, $id, $field, $f['wrap']);
                $this->_callback('after_save', 'after_edit_save');
		redirect(site_url("modules/{$this->router->class}"));
	}

	function _render() {
		$this->tpl->content =''; // jai added to remove error in php5
		$this->tpl->content .= $this->form->render();
		$this->tpl->content = $this->load->view('manage', array('tpl' => $this->tpl), true);
		$this->tpl->content = $this->load->view('module', array('tpl' => $this->tpl), true);
		$this->load->view('myid_template', array('tpl' => $this->tpl));
	}

	function delete($id = '') {
		if(!$this->allow_delete)
			redirect( $this->router->class);

		$this->record->load_record($id);
		$this->_callback('before_delete');

		if (!$this->session->userdata('failure')) {
			if ($this->model->delete($this->record)) {
				/* Delete any uploaded files */
				foreach($this->form->groups as $group)
					foreach($group->fields as $field)
						if( get_parent_class($field) == 'CIID_Field_Binary')
							if($field->value != '')
								if(file_exists('..' . $field->value))
									unlink('..' . $field->value);
				$this->_callback('after_delete', 'cud');
			}
		}
		redirect($this->router->class);
	}

	function cloner() {
	}

	function index() {
		addScript('assets/js/overview.js');
		addScript('assets/css/jquery.ui/jquery-ui-1.8.6.custom.css', 'css');
		addScript('assets/js/modal.js');

		if (!isset($this->tpl))
			$this->tpl = new stdClass();

		if (!isset($this->tpl->page))
			$this->tpl->page = new stdClass();

		if (!isset($this->tpl->header))
			$this->tpl->header = new stdClass();

		if (!isset($this->tpl->add_button))
			$this->tpl->add_button = new stdClass();

		if (!isset($this->tpl->modal))
			$this->tpl->modal = new stdClass();

		if($this->sortable) {
			addScript('assets/js/modules/reorder.js?controller=' . $this->router->class);
		} else {
			$this->paginate();
		}

		$this->tpl->page->title	= $this->plural;

		// set fields for <th>
		$fields = array();

		foreach($this->overview->fields as $field)
			if ($field['hidden'] != 'hidden')
				$fields[] = $field['label'];

		$this->tpl->header->fields = $fields;

		if ($this->input->post('search_term') != '') {
			$data_set = $this->model->load_all(array( 'search_term' => $this->input->post('search_term') ));
			$searched  = true;
		} else {
			$order_by = '';
			if ($this->sortable && $this->share_group == '') {
				$order_by = $this->table . '.' . $this->order_key . ' ASC';
			} elseif ($this->overview->order_by == 'name' ) {
				$order_by = $this->table . '.name ASC';
			} elseif ($this->overview->order_by != '') {
				$order_by = $this->overview->order_by;
			} else {
				$order_by = $this->table . '.updated_date DESC';
			}

			$limit = $this->limit ? $this->limit : false;

			if (@$this->paginate->limit)
				$limit = @$this->paginate->limit;

			$data_set = $this->model->load_all(array(
				'limit'  => $limit,
				'offset' => @$this->paginate->offset,
				'order'  => $order_by,
				'where' => $this->overview->where,
				'join' => $this->overview->join,
				'map' => $this->overview->map, // new one addded
			));
		}



		$rows = $data_set['rows'];
		$num_rows = $data_set['total_num_rows'];

		if (!isset($this->tpl->add_button->link))
			$this->tpl->add_button->link = "modules/{$this->router->class}/add";

		if (!isset($this->tpl->add_button->text))
			$this->tpl->add_button->text = 'ADD';

		$this->tpl->scripts = $this->script['javascript'];
		$this->tpl->css = $this->script['css'];

		$this->tpl->modal->title = 'Confirm ' . $this->singular . ' Deletion';

		$this->tpl->modal->buttons = '<a class="btn_sml meta_bold_hover modal_cancel" href=""><span>CANCEL</span></a>';
		$this->tpl->modal->buttons .= '<a class="btn_sml meta_bold_hover modal_delete" href=""><span>DELETE</span></a>';

		$content_table = array();

		$current_share_group = 0;
		if(@$rows) {
			foreach ($rows as $k => $row) {
				// overview here
				$row_clean = clone $row;
				if ($this->share_group != '') {
					if (isset($content_table[$current_share_group]) and empty($content_table[$current_share_group]['data']))
						unset($content_table[$current_share_group]);

					if ($current_share_group != $row->{$this->share_group_key}) {
						$current_share_group = $row->{$this->share_group_key};
						$current_share_group_title = $row->{$this->share_group_value};
					}
				} // jai added
				else if (!empty($this->group_key)) {
					if ($current_share_group !== $row->{$this->group_key}) {
						$current_share_group = $row->{$this->group_key};
						$current_share_group_title = ucfirst(str_replace('_', ' ', $row->{$this->group_key}));
					}
				}

				if (!isset($content_table[$current_share_group])) {
					$content_table[$current_share_group] = array(
						'header' => $this->tpl->header->fields,
						'data' => array(
							$row->{$this->primary_key} => array(),
						),
					);
					if (isset($current_share_group_title))
						$content_table[$current_share_group]['title'] = $current_share_group_title;
				}

				$out_field = array(
					'content' => array()
				);

				$content_table[$current_share_group]['data'][$row->{$this->primary_key}] = array();

				foreach($this->overview->fields as $field) {
					if ($field['hidden'] != 'hidden') {

						if($field['format'] != '') {
							$eval = str_replace('{value}', $row->$field['field'], $field['format']);
							eval('$row->$field["field"] = ' . $eval . ';');
						}

						if ($field['field'] == 'created_date' || $field['field'] == 'updated_date') {
							$diff = mktime() - strtotime($row->$field['field']);
							if ($diff > 60*60*24*28)
								$row->$field['field'] = date('d/m/Y', strtotime($row->$field['field']));
							else
								$row->$field['field'] = timeToAge($diff);
						}

						if (isset($field['width'])) {
							$out_field['width'] = $field['width'];
						}

						if($field['accessor'] == 'active') {
							/* wrapper array of values i.e enum */
							if(is_array($field['wrap'])) {
								foreach($field['wrap'] as $wrap) {
									if($wrap['value'] == $row->$field['field']) {
										$out_field['content'] = $wrap['label'];
									}
								}
							} elseif($field['wrap'] != '') {
								/* standard wrapper */
								$out_field['content'] = str_replace('{value}', $row->$field['field'], $field['wrap']);
							} else {
								/* no wrapper */
								 // jai added this wrapper function
							   if(strpos($field['field'],':')!== false){
								   $exp = explode(':',$field['field']);
								   $new_content = '';
								   foreach($exp as $v){
									   if ($v == 'created_date' || $v == 'updated_date')
									   {
										   $diff = mktime() - strtotime($row->$v);

											if ($diff > 60*60*24*28) { $row->$v = date('d/m/Y', strtotime($row->$v));
											}else{ $row->$v = ucfirst(substr($v, 0, strpos($v, '_'))).': '.timeToAge($diff); }
									   }
									   $new_content .=$row->$v.'<br/>';
								   }
								   $out_field['content'] = $new_content;  //  append the content  here

							   }else{

								   $out_field['content'] = $row->$field['field'];
							   }
							}
						} elseif (strpos($field['accessor'], 'count') !== false) {
							if (strpos($field['accessor'], 'list') !== false) {

								$out_field['content'] = '<a href="#" title="' . str_replace(chr(10),'<br />',str_replace('"', '\"', @$row->{$field['field'] . '_list'})) .'" class="tooltipped">'.$row->{$field['field'] . '_count'}.'</a>';
							} else {
								$out_field['content'] = @$row->{$field['field'] . '_count'};
							}
						} elseif(strpos($field['accessor'], 'sum') !== false) {
							$out_field['content'] = @$row->{$field['field'] . '_sum'} ? $row->{$field['field'] . '_sum'} : '0';
						} elseif(strpos($field['accessor'], 'relationship') !== false && strpos($field['accessor'], 'active') !== false) {
							$out_field['content'] = @$row->$field['field'] ? $row->$field['field'] : '';
						}

						if ($field['custom'] == 'switch' && is_array($field['wrap'])) {
							foreach ($field['wrap'] as $wrap) {

								if ($wrap['value'] == $row->$field['field']) {
									$out_field['content'] = "<a href='".site_url("modules/{$this->router->class}/switchvalue/{$row->{$this->primary_key}}/{$field['field']}")."' class='status' style='background-color: {$wrap['colour']}'>{$wrap['label']}</a>";
								}
							}
						} else if ($field['custom']) {
							 // products count added MYID hack
								if($field['custom_formula'] =='countProducts')
								{
									$out_field['content'] = @$row->$field['field'];
								}else
								{
									preg_match_all("/{(.*?)}/", $field['custom_formula'], $m);
									foreach($m[1] as $v)
									{
									//	$field['custom_formula'] = str_replace("{$v}", $row_clean->$v, $field['custom_formula']);
                                                                                
                                                                                $needle = '{'.$v.'}';    // @ jaykay added this 
                                                                                $field['custom_formula'] = str_replace($needle, $row_clean->$v, $field['custom_formula']); // jaykay added
									}
									$out_field['content'] = $field['custom_formula'];
								}
						}
						$content_table[$current_share_group]['data'][$row->{$this->primary_key}][] = $out_field;
					}
				}

				$buttons = '';

				if($this->allow_delete) {
					$buttons .= '<a href="'.site_url('modules/' . $this->router->class . '/delete/'.$row->{$this->primary_key}).'" class="delete icon" title="Delete">';
					$buttons .= '<img src="'.site_url('assets/images/delete_icon.png').'" alt="delete">';
					$buttons .= '</a>';
				}

				if($this->allow_edit) {
					$buttons .= '<a href="'.site_url('modules/' . $this->router->class . '/edit/'.$row->{$this->primary_key}).'" class="icon" title="Edit">';
					$buttons .= '<img src="'.site_url('assets/images/edit_icon.png').'" alt="edit">';
					$buttons .= '</a>';
				}

				if($this->sortable) {
					$buttons .= '<a href="javascript:void(0);" class="drag icon" title="Drag to re-order">';
					$buttons .= '<img src="'.site_url('assets/images/drag_icon.png').'" alt="re-order">';
					$buttons .= '</a>';
				}

				if (isset($this->overview->icon) && sizeof($this->overview->icon) > 0) {
					foreach($this->overview->icon as $icon) {
						preg_match_all("/{(.*?)}/", $icon['url'], $m);

						foreach($m[1] as $v) {
							$icon['url'] = str_replace("{".$v."}", $row->{$v}, $icon['url']);
						}

						$buttons .= '<a href="'.site_url('modules/' . $icon['url']).'" class="icon" title="'.$icon['title'].'">';
						$buttons .= '<img src="'.site_url('assets/images/' . $icon['filename']).'" alt="" />';
						$buttons .= '</a>';
					}
				}
				$out_field = array(
					'class' => 'icon_wrapper',
					'content' => $buttons,
				);

				$content_table[$current_share_group]['data'][$row->{$this->primary_key}][] = $out_field;
			}

			if (!@$searched && !$this->sortable) {
				$pagi = new stdClass();
				$pagi->size = $num_rows;
				$this->tpl->pagination  = $this->generate_pagination($pagi);
			}
		}

		$this->tpl->content = $this->load->view('content_table', array('table' => $content_table), true);

		$this->tpl->content = $this->load->view('overview', array('tpl' => $this->tpl), true);
		$this->tpl->content = $this->load->view('module', array('tpl' => $this->tpl), true);
		$this->load->view('myid_template', array('tpl' => $this->tpl));

	}

	public function ajax($foreign_key, $parent_id) {

		$tpl = array();

		$order_by = '';
		if($this->sortable) {
			$order_by = 'order_index';
		} elseif($this->overview->order_by != '') {
			$order_by = $this->overview->order_by;
		} else {
			$order_by = 'updated_date DESC';
		}

		$tpl['name'] = $this->table;
		$tpl['parent_id'] = $parent_id;
		$tpl['foreign_key'] = $foreign_key;

		$tpl['sortable'] = $this->sortable;
		$tpl['allow_edit'] = $this->allow_edit;
		$tpl['allow_add'] = $this->allow_add;
		$tpl['allow_delete'] = $this->allow_delete;

		$tpl['header'] = array();    // this only gets the viwign fields

		foreach($this->embedded->fields as $field) {
			$tpl['header'][$field['field']] = $field['label'];
		}

		$tpl['data'] = $this->model->load_embedded(array(
			'order_by'  => $order_by,
			'where' => array("$foreign_key = $parent_id"),
		));

		foreach ($tpl['data'] as $row) {
			foreach($this->embedded->fields as $field) {
				if($field['format'] != '') {
					$eval = str_replace('{value}', $row->$field["field"], $field['format']);
					eval('$row->$field["field"] = ' . $eval . ';');
				}
				if(is_array($field['wrap'])) {
					foreach($field['wrap'] as $wrap) {
						if($wrap['value'] == $row->$field['field']) {
							$row->$field['field'] = $wrap['label'];
						}
					}
				} else if($field['wrap'] != '') {
					$row->$field['field'] = str_replace('{value}', $row->$field['field'], $field['wrap']);
				}
			}
		}

		$result = array(
			'data' => $tpl['data'],
			'html' => $this->load->view('widgets/embedded', $tpl, true),
		);
		echo json_encode($result);
	}

	public function ajax_add_form($foreign_key, $parent) {
		if(!$this->allow_add)
			return;

		$this->_callback('before_add');

		$this->tpl->name = $this->table;
		$this->tpl->form = $this->form;
		$this->tpl->foreign_key = $foreign_key;
		$this->tpl->parent = $parent;
		$this->tpl->mode = 'add';

		$this->load->view('widgets/edit.php', $this->tpl);

		$this->_callback('after_add', 'cud');
	}

	public function ajax_edit_form($id, $foreign_key, $parent) {
		if(!$this->allow_edit)
			return;

		$this->_callback('before_edit');

		$this->tpl->name = $this->table;
		$this->tpl->form = $this->form;
		$this->tpl->foreign_key = $foreign_key;
		$this->tpl->parent = $parent;
		$this->tpl->id = $id;
		$this->tpl->mode = 'edit';

		$this->load->view('widgets/edit.php', $this->tpl);

		$this->_callback('after_edit', 'cud');
	}

	public function ajax_add_save() {
		if (!$this->allow_add)
			die("Permission denied");

		$this->_callback('before_add');
		if (count($_POST)) {
			$this->form->mode = 'add';
			$this->form->repopulate();
			$this->_callback('before_validate' ,'before_add_validate');

			if ($this->form->validate()) {
				$this->record->get_values_from_form();
				$this->_callback('before_save', 'before_add_save');
				if ($this->record->save()) {
					// for add
					$this->session->set_userdata('success', array(message_replace(RECORD_ADD_SUCCESS, $this->singular, $this->record->title_item())) );
					$this->_callback('after_save', 'after_add_save');
					echo json_encode(array(
							'status' => 'ok',
							'name' => $this->table
						)
					);
				}
			} else {
				$errors = '';
				foreach ($this->form->groups as $group)
					if (count($group->errors))
						foreach ($group->errors as $error)
							$errors .= "$error <br />";

				echo json_encode(array(
						'status' => 'error',
						'errors' => $errors
					));
			}
		}
	}

	public function ajax_edit_save($id) {
		if (!$this->allow_edit)
			die("Permission denied");

		// refactor this to handle the post and redirection
		$this->_callback('before_edit');

		if (count($_POST) > 0) {
			$files_to_remove = array();
			// if new files have been selected, build array of existing files to remove
			foreach ($this->form->groups as $kk => $vv) {
				foreach ($vv->fields as $k => $v) {
					$object = get_class($v);
					if ($object == 'CIID_image' || $object == 'CIID_file') {
						if (isset($_FILES[$v->name]['size']) && $_FILES[$v->name]['size'] > 0) {
							// a file was uploaded, remove old one
							$files_to_remove[] = $this->record->item($v->name)->value;
						}
					}
				}
			}

			$this->form->repopulate();
			$this->_callback('before_validate' ,'before_edit_validate');
			if($this->form->validate()) {
				$this->record->get_values_from_form();
				$this->_callback('before_save', 'before_edit_save');
				// if new files have been selected, remove the old ones
				foreach($files_to_remove as $file)
					if (file_exists('..' . $file) && !is_dir('..'.$file))
						unlink('..' . $file);

				// checkbox checked, remove file and empty field
				if (isset($_POST['delete_binary'])) {
					foreach($_POST['delete_binary'] as $field => $value) {
						if (file_exists('..' . $this->record->item($field)->value))
							unlink('..' . $this->record->item($field)->value);
						$this->record->set_item($field, "");
					}
				}

				if ($this->record->save()) {
					$this->_callback('after_save', 'after_edit_save', 'cud');
					echo json_encode(array(
							'status' => 'ok',
							'name' => $this->table
						)
					);
				 return;
				}
			} else {
				$errors = '';
				foreach ($this->form->groups as $group)
					if (count($group->errors))
						foreach ($group->errors as $error)
							$errors .= "$error <br />";

				echo json_encode(array(
						'status' => 'error',
						'errors' => $errors
					));
				return;
			}
		}
		$this->_callback('after_edit', 'cud');
	}

	public function page($number) {
		$this->session->set_userdata('current_page', $number);
		redirect(site_url('/modules/' . $this->router->class));
		exit;
	}

	public function search() {
		$search_term = $this->input->post('term');
		$results = $this->model->search($search_term, $this->search_config);
		JSON($results);
	}

	private function update_record($data, $id) {
		return $this->model->edit($data, $id) ? true : false;
	}

	function set_order() {
		$node_id		= $this->input->post('node_id');
		$index 			= $this->input->post('index');

		if ($node_id == '' || $index == '')
			return false;

		$index++;

		if ($this->model->update_order_index($node_id, $index)) {
			$response['status'] = 1;
		} else {
			$response['status'] = 0;
		}
		$this->_callback('order');
		echo json_encode($response);
	}

	// our callbacks
	function _callback() {
		foreach(func_get_args() as $callback) {
			if (method_exists($this, '_' . $callback . '_callback'))
				$this->{'_' . $callback . '_callback'}();
			else
				die('callback method does not exist : ' . $callback);
		}
	}

	function _before_load_callback() {}
	function _after_load_callback() {}
	function _before_add_callback() {}
	function _after_add_callback() {}
	function _before_edit_callback() {}
	function _after_edit_callback() {}
	function _before_save_callback() {}
	function _after_save_callback() {}
	function _before_add_save_callback() {}
	function _after_add_save_callback() {}
	function _before_edit_save_callback() {}
	function _after_edit_save_callback() {}
	function _before_delete_callback() {}
	function _after_delete_callback() {}
	function _before_validate_callback() {}
	function _before_add_validate_callback() {}
	function _before_edit_validate_callback() {}
	function _cud_callback() {}
	function _order_callback() {}
}

class CIID_Overview {

	var $controller;
	var $fields = array();
	var $order_by;
	var $htmls = array();
	var $icon = array();
	var $where = array();
	var $join = array();
	var $map = array();

	function __construct(&$c) {
		$this->controller = $c;
	}

	function add_item($label = '', $accessor = '', $field = '', $wrap = '', $hidden = '') {
		$this->fields[] = array(
			'label' => $label,
			'accessor' => $accessor,
			'field' => $field,
			'wrap' => $wrap,
			'hidden' => $hidden,
			'format' => '',
			'custom' => false,
			'custom_formula' => '',
		);
		return $this;
	}



	function add_custom($label='', $formula='') {
		// TODO: add custom values to overview using eval
		// ...added custom, but no eval.
		$this->fields[] = array(
			'label' => $label,
			'accessor' => '',
			'field' => '',
			'wrap' => '',
			'hidden' => '',
			'format' => '',
			'custom' => true,
			'custom_formula' => $formula,
		);
		return $this;
	}



	function add_switch($label, $field, $wrap) {
		$this->fields[] = array(
			'label' => $label,
			'accessor' => '',
			'field' => $field,
			'wrap' => $wrap,
			'hidden' => '',
			'format' => '',
			'custom' => 'switch',
			'custom_formula' => '',
		);
		return $this;
	}

	function add_icon($filename, $url, $title=false) {
		$this->icon[] = array(
			'filename' => $filename,
			'url' => $url,
			'title' => $title,
		);
		return $this;
	}

	function set_width($width) {
		if(count($this->fields) > 0)
			$this->fields[ count($this->fields) - 1]['width'] = $width;
		return $this;
	}

	function order_by($field) {
		$this->order_by = $field;
	}

	function html($html = '') {
		$this->htmls[] = $html;
		return $this;
	}

	function format($format) {
		if (count($this->fields) > 0)
			$this->fields[ count($this->fields) - 1]['format'] = $format;
		return $this;
	}

	function where($param, $val, $escape = true) {
		$this->where[] = array(
			'param' => $param,
			'val' => $val,
			'escape' => $escape,
		);
		return $this;
	}

	/**
	 * @param $param
	 * @param $val
	 * @param bool $option
	 * @return $this
	 */
	function join($param, $val, $option=false) {
		$this->join[] = array(
			'param' => $param,
			'val' => $val,
			'option' => $option,
		);
		return $this;
	}

	/**
	 * @param $param
	 * @param $val
	 * @param bool $option
	 * @return $this
	 */
	function map($param, $val, $option = false)
	{
		$this->map[] = array(
			'param'  => $param,
			'val'    => $val,
			'option' => $option,
		);

		return $this;
	}


	function hidden() {
		if (count($this->fields) > 0)
			$this->fields[ count($this->fields) - 1]['hidden'] = true;
		return $this;
	}
}
