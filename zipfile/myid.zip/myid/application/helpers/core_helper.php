<?php
function printVar($var, $description = '__NONE__', $seeInvisible = false) {
	if($seeInvisible) {
		$var = seeHidden($var);
	}

	$debugBacktrace = debug_backtrace();
	$debugBacktrace = $debugBacktrace[ 0 ];

	if($description == '__NONE__') {
		$description = "NO DESCRIPTION GIVEN";
	}

	$titleFilename = '/'. implode('/', array_diff(explode('/', $debugBacktrace['file']), explode('/', $_SERVER['DOCUMENT_ROOT'])));
	print('<pre style="border: 1px solid #ccc; border-bottom-width: 3px; margin-bottom: 5px; font-size: 12px; text-align: left;" title="File: '. $titleFilename .' ('. $debugBacktrace['line'] .') =&gt; '. htmlentities($description). '">');
	print("File: <strong>". $debugBacktrace['file'] ."</strong>\n");
	print("Line: <strong>". $debugBacktrace['line'] ."</strong>\n");

	if(is_readable($debugBacktrace['file'])) {
		$sourceFile = file($debugBacktrace['file']);
		$sourceIndex = $debugBacktrace['line'] - 1;
		for($x = ($sourceIndex - 3); $x <= $sourceIndex; $x++) {
			if(array_key_exists($x, $sourceFile) && trim($sourceFile[$x]) != '') {
				$sourceToOutput[] = '<strong>'. ($x + 1) .':</strong> '. $sourceFile[$x];
			} else {
				continue;
			}
		}
	}

	if(!empty($sourceToOutput)) {
		print("Source: <code style=\"font-size: 9px;\">\n". implode("", $sourceToOutput) ."</code>\n");
	}

	print($description ."\n-----------------------------------------\n");
	print_r($var);
	print('</pre>');
}


/*
 * access Public
 * @param $src (string) - path to script file
 * @param $type (string) - type of file
 * @param $inline (string) - inline or embed
 * @param $extra (string) - additional params
 * @return null
 *
 * @description create a script src tag for javacsript or css passed back to controller
 * as $srcipt['javascript'] or $srcipt['css']
*/

function addScript($src = false, $type = "javascript", $inline = "embed", $extra = false) {
	
	$CI = &get_instance();
	
	if(empty($CI->script[$type])){
		$CI->script[$type] = '';
	}
	
	if($src) {
		if($type == "javascript") {
			switch($inline) {
				case "embed":  $CI->script[$type].="\r\n<script type=\"text/javascript\" src=\"".base_url()."{$src}\"></script>"; break;
				case "inline": $CI->script[$type].="\r\n<script type=\"text/javascript\">{$src}</script>"; break;
				case "external": $CI->script[$type].="\r\n<script type=\"text/javascript\" src=\"{$src}\"></script>"; break;
			}
		}
		elseif($type == "css") {
			 switch($inline) {
				case "embed": $CI->script[$type].="\r\n<link href=\"".base_url()."{$src}\"  rel=\"stylesheet\"{$extra}/>"; break;
			}
		}
	}
		
	return;
}

function display_all_errors($form_errors, $custom_errors=''){
	$errors = array();
	$tmp = array();
	
	if(!empty($form_errors)){
		$tmp = explode('<li>', $form_errors);
	}
	
						
   if(is_array($custom_errors) && count($custom_errors) > 0){
	   //merge tmp
	   $tmp = array_merge($tmp, $custom_errors);
   } else {
	   if($custom_errors != ''){
			//is a string
			$tmp[] = $custom_errors;
	   }
   }
   
						
   foreach($tmp as $item){
	   if($item != ''){
		   $errors[] = str_replace('</li>', '', $item);
	   }
   }
   return $errors;
}

function extract_options($options, $label, $value) {
	
	$opts = array();
	
	foreach($options as $option) {
		
		if(is_array($option)) {
			$opts[] = array('value' => $option[$value], 'label' => $option[$label]);
		} elseif(is_object($option)) {
			$opts[] = array('value' => $option->$value, 'label' => $option->$label);
		}
	}
	
	return $opts;

}

function extract_select_options($options, $label, $value) {
	
	$opts = array();
	
	$opts[''] = '---Please Select---';
	
	foreach($options as $option) {
		
		$opts[$option[$value]] = $option[$label];

	}
	
	return $opts;

}

function message_replace($text, $singular, $record_name) {
	
	$find = array('{singular}', '{record_name}');
	$replace = array( $singular, $record_name);
	return str_replace($find, $replace, $text);

}

function elt($str) {

	return htmlspecialchars($str);

}

function get_extension($filename) {

	$pi = pathinfo($filename);
	return $pi['extension'];
						
}

function get_without_extension($filename) {
	
	$pi = pathinfo($filename);
	return $pi['filename'];

}

function timeToAge($t) {
	if ($t < 60)
		return $t.' seconds ago';
	if ($t <= 60*60)
		return floor($t/60).' minutes ago';
	if ($t <= 60*60*24)
		return floor($t/60/60).' hour ago';
	if ($t <= 60*60*24*7)
		return floor($t/60/60/24).' days ago';
	if ($t <= 60*60*24*30)
		return floor($t/60/60/24/7).' weeks ago';
	if ($t <= 60*60*24*365)
		return floor($t/60/60/24/30).' months ago';

	return floor($t/60/60/24/365).' years ago';
}
