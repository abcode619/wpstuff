<?php


if(! function_exists("clear_cache") )
{
	function clear_cache()
	{
		$cache = '../application/cache/categories.c';
		$cache2 = '../application/cache/home_categories.c';
		if( file_exists($cache) ) {

			unlink($cache);

		}

		if( file_exists($cache2) ) {

			unlink($cache2);

		}

	}
}

if( ! function_exists("JSON")) {

	function JSON($response) {

		$ci =& get_instance();
		$ci->output->set_output( $ci->output->get_output() . json_encode($response) );

	}

}

if( ! function_exists("tt")) {

	function tt($path, $width="", $height="", $extra="") {

		return site_url(sprintf("tt?src=%s&w=%s&h=%s%s", urlencode($path), $width, $height, $extra));

	}


	 /**
	 * Dump helper. Functions to dump variables to the screen, in a nicley formatted manner.
	 * @author Joost van Veen
	 * @version 1.0
	 */
	if (!function_exists('dump')) {
	    function dump ($var, $label = 'Dump', $echo = TRUE)
	    {
	        // Store dump in variable
	        ob_start();
	        var_dump($var);
	        $output = ob_get_clean();

	        // Add formatting
	        $output = preg_replace("/\]\=\>\n(\s+)/m", "] => ", $output);
	        $output = '<pre style="background: #FFFEEF; color: #000; border: 1px dotted #000; padding: 10px; margin: 10px 0; text-align: left;">' . $label . ' => ' . $output . '</pre>';

	        // Output
	        if ($echo == TRUE) {
	            echo $output;
	        }
	        else {
	            return $output;
	        }
	    }
	}


	if (!function_exists('dump_exit')) {
	    function dump_exit($var, $label = 'Dump', $echo = TRUE) {
	        dump ($var, $label, $echo);
	        exit;
	    }
	}
}


?>