<?php

class Site_model extends CI_Model {

	public function __construct() {
		parent::__construct();
		$this->load->database();
		$this->user_level = intval($this->session->userdata('user_level'));

		if (!$this->user_level)
			$this->user_level = 1;
	}

	public function fetch_modules($status) {
		return $this->db
			->where('user_level <= '.$this->user_level)
			->where('status', $status)
			->order_by('name')
			->get('modules')
			->result();
	}

	public function settings() {
		$res = $this->db->get('setting')->result();
		$data = new stdClass;
		foreach ($res as $row) {
			if (!isset($data->{$row->category}))
				$data->{$row->category} = new stdClass;
			$data->{$row->category}->{preg_replace('![^A-Za-z0-9]+!', '_', strtolower($row->name))} = $row->value;
		}
		return $data;
	}

	//jai nav bar

	public function navmenu()
	{
		return $this->db
					->where('user_level <= '.$this->user_level)
					->where('visibility','nav')
					->where('status', 'enabled')
					->get('modules')
					->result();
	}

	// public function fetch_modules($status) {
	// 	$sql = "SELECT
	// 				id,
	// 				name,
	// 				url,
	// 				visibility
	// 			FROM
	// 				modules
	// 			WHERE
	// 				status = ?
	// 			ORDER BY
	// 				name ASC";

	// 	$query = $this->db->query($sql,array($status));

	// 	if($query->num_rows() > 0) {
	// 		return $query->result();
	// 	}

	// 	return FALSE;
	// }


	public function fetch_quick_links($limit) {
		$sql = "SELECT
					page,
					url
				FROM
					quick_links
				ORDER BY
					clicks DESC
				LIMIT ?";

		$query = $this->db->query($sql,array($limit));

		if($query->num_rows() > 0) {
			return $query->result();
		}

		return FALSE;
	}


	public function add_quick_link($url, $page) {
		$sql = '
				INSERT
				INTO
					quick_links
						(
							url,
							page,
							clicks
						)
				VALUES
						(
							?,
							?,
							1
						)
				ON
					DUPLICATE KEY
				UPDATE
					clicks = clicks + 1
		';

		$query = $this->db->query($sql,array($url, $page));
	}
}

/* End of file Example.php */
/* Location: /application/models/Example.php */