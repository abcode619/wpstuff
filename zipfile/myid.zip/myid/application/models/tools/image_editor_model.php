<?php

class Image_editor_model extends CI_Model {

	
	function get_image($table, $field, $id) {
		
		$this->db->select($field);
		$this->db->where($table . '_id', $id);
		$query = $this->db->get($table);
		
		if($query->num_rows() == 1) {
			
			$row = $query->row();
			return $row->$field;
		
		} else {
			
			return false;
		
		}
		
	
	}
	
	function update_image($table, $field, $id, $source) {
		
		$this->db->set($field, $source);
		$this->db->where($table . '_id', $id);
		$this->db->update($table);
	
		return true;
	
	}

}