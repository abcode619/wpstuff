<?php

class Login_model extends CI_Model{

	function __construct() {
		parent::__construct();
		$this->load->database();
	}
	
	/*
	 *
	 */
	public function authenticate(&$form, $data) {
		$user = $data['username'];
		$pass = MD5($data['password']);
		
		$sql = 'SELECT
					id,
					user_level,
					full_name
				FROM
					users_myid
				WHERE
					username=? AND
					password=?
				LIMIT 1';
		
		$query = $this->db->query($sql,array($user,$pass));

		if($query->num_rows() > 0) {
			return $query->row();
		}
		
		return FALSE;
	}
	
	
	public function authenticate_retailer($data) {
		$user = $data['username'];
		$pass = MD5($data['password']);
		
		$sql = "SELECT
					id
				FROM
					registration
				WHERE
					username=?
				AND
					password=?
				AND
					status = 'Active'
				LIMIT 1";
		
		$query = $this->db->query($sql,array($user,$pass));

		if($query->num_rows() > 0) {
			return $query->row();
		}
		
		return FALSE;
	}
	
	
	public function fetch_registration($id) {
		
		$sql = '
			SELECT
				username
			FROM
				registration
			WHERE
				id = ?
			LIMIT
				1
			';
		
		$query = $this->db->query($sql, $id);

		if($query->num_rows() > 0) {
			return $query->row();
		}
		
		return FALSE;
	}
	
	
	public function change_password(&$form, $data) {
		$registration = $this->fetch_registration($data['id']);
		
		if($registration) {
			$details = array(   'username' => $registration->username,
								'password' => $data['old_password']);
			
			if($this->authenticate_retailer($details)) {
				$sql = '
					UPDATE
						registration
					SET
						password = ?,
						plain = ?
					WHERE
						id = ?
						';
				
				$query = $this->db->query($sql, array(  MD5($data['new_password']),
														'',
														$data['id']));
																
				if(!$query) {
					$form->add_error('old_password', 'There was an error changing your password. Please try again in a few minutes.');
				}
			} else {
				$form->add_error('old_password', 'The password you entered is invalid. Please re-enter your password.');
			}
		} else {
			$form->add_error('old_password', 'There was an error changing your password. Please try again in a few minutes.');
		}
	}
	
}
/* End of file categories_model.php */
/* Location: ./system/application/models/categories_model.php */