<?php

class Dashboard_model extends CI_Model{

	public function __construct() {
		parent::__construct();
		$this->load->database();

/*	Automatically upgrade db when upgrading old version */
		$fields = $this->db->list_fields('modules');
		if (!in_array('parent', $fields))
			$this->db->query('ALTER TABLE modules ADD COLUMN parent INT(11) DEFAULT 0 NOT NULL');
		if (!in_array('visibility', $fields))
			$this->db->query("ALTER TABLE modules ADD COLUMN `visibility` enum('visible','hidden') NOT NULL DEFAULT 'visible'");
		if (!in_array('order_index', $fields)) {
			$this->db->query('ALTER TABLE modules ADD COLUMN order_index INT(11) DEFAULT 0 NOT NULL');
			$this->db->query('SET @pos = 0;');
			$this->db->query('UPDATE modules SET order_index = @pos:=@pos+1 ORDER BY name;');

		}

		$this->user_level = intval($this->session->userdata('user_level'));
		if (!$this->user_level)
			$this->user_level = 1;
	}

	public function fetch_latest_updates() {
		$result = array();
		$q = $this->db
			->where('visibility', 'visible')
			->where('parent', '0')
			->or_where('parent', NULL)
			->order_by('order_index')
			->get('modules');

		foreach($q->result() as $r) {
			$result[$r->name] = $this->format_module($r);
		}
		return $result;
	}

	private function format_module($data) {
		$res = $this->db
			->where('visibility', 'visible')
			->where('parent', $data->id)
			->order_by('order_index')
			->get('modules')
			->result();

		if ($res) {
			$data->children = array();
			foreach ($res as $row) {
				$data->children[$row->name] = $this->format_module($row);
			}
		}
		return $data;
	}

	function get_modules() {
		$res = $this->db
			->order_by('order_index, name')
			->get('modules')
			->result();
		$modules = array(
			array(
				'label' => '',
				'value' => 0,
				'default' => true
			)
		);
		foreach ($res as $r) {
			$modules[] = array(
				'value' => $r->id,
				'label' => $r->name
			);
		}
		return $modules;
	}

	function get_nav_items() {
		$res = array(
			'Dashboard' => ''
		);
		$data = $this->db
			->where('user_level <= '.$this->user_level)
			->where('visibility', 'nav')
			->order_by('order_index')
			->get('modules')
			->result();
		foreach ($data as $row)
			$res[$row->name] = $row->url;
		return $res;
	}

}
/* End of file dashboard_model.php */
/* Location: ./system/application/models/dashboard_model.php */
