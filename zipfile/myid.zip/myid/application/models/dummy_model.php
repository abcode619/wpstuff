<?php

class Dummy_model extends MY_Model {

}

?>