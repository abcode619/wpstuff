<?php

class MY_Model extends CI_Model {
	function __construct() {
		parent::__construct();
	}
}

class CIID_Model extends MY_Model {
	var $controller;
	var $table;
	var $primary_key;
	var $order_key = '';
	var $share_key = '';
	var $share_value = '';
	var $query_append = '';
	var $share_group = '';
	var $share_group_key = '';

	function __construct(&$c) {

		parent::__construct();

		$this->controller = $c;
		$this->table = $this->controller->table;
		$this->primary_key = $this->controller->primary_key ? $this->controller->primary_key : $this->table . '_id';
		$this->order_key = @$this->controller->order_key ? $this->controller->order_key : 'order_index';
		$this->share_key = @$this->controller->share_key ? $this->controller->share_key : '';
		$this->share_value = @$this->controller->share_value  ? $this->controller->share_value : '';
		if($this->share_key)
			$this->query_append = $this->table . '.' . $this->share_key . ' = ' . $this->db->escape($this->share_value);
		$this->share_group = @$this->controller->share_group ? $this->controller->share_group : '';
		$this->share_group_key = @$this->controller->share_group_key ? $this->controller->share_group_key : '';
	}

	function load_embedded($params = array()) {
		$where = @$params['where'];

		$this->db->select($this->table.'_id');
		foreach($this->controller->embedded->fields as $field) {
			$this->db->select($field['field']);
		}

		if (is_array($where))
			foreach($where as $option)
				$this->db->where($option);
		if (isset($params['order_by']))
			$this->db->order_by($params['order_by']);
		return  $this->db->get($this->table)->result();
	//	var_dump( $this->db->last_query()); die();
	}

	function load_all($params=array()) {

		//$data[ 'rows' ] = $this->db->get ($this->table)->result ();

		if(!@$params['search_term']) {
			$limit = @$params['limit'];
			$offset = @$params['offset'];
			$order = @$params['order'];
		}

		$where = @$params['where'];
		$direct_join = @$params['join'];
		$map_join = @$params['map'];

		// new
		$this->db->select("SQL_CALC_FOUND_ROWS *", FALSE);

		$sql_joins = array();
		$sql_sub_relational_joins = array();
		$sub_relational_tables = array();
		$this->db->select($this->table.'.*');

		foreach($this->controller->overview->fields as $field) {
			if( strpos($field['accessor'], 'relationship') !== false) {

				$dot_pos = strpos($field['field'], '.');
				$table = substr($field['field'],0, $dot_pos);
				$field_name = '';
				if($dot_pos !== false) {
					$field_name = substr($field['field'], $dot_pos + 1);
				}

				// OneToMany
				if(strpos($field['accessor'], 'active') !== false) {
					// TODO
				}

				if(!in_array($table, $sub_relational_tables)) {
					$sub_relational_tables[] = $table;
				}

				$sql_sub_relational_joins[] = array('table' => $table, 'field_name' => $field_name, 'accessors' => explode('|', $field['accessor']));

			} elseif( strpos($field['accessor'], 'count') !== false) {

				$sql_joins[] = array('table' => $field['field'], 'accessors' => explode('|', $field['accessor']));

			}
		}

		// removed in ci 2.1...
		// $this->db->SQL_CALC_FOUND_ROWS();

		if(count($sql_joins) > 0) {
			foreach($sql_joins as $join) {
				$join_table = $join['table'];
				$join_table_pk = $join_table . '_id';
				$this->db->select("count( DISTINCT {$join_table}.{$join_table_pk} ) as {$join_table}_count");
				if( in_array('list', $join['accessors'])) {
					$this->db->select("group_concat( DISTINCT {$join_table}.name SEPARATOR '\n') as {$join_table}_list");
				}
			}
		}



		if(count($sql_sub_relational_joins) > 0) {
			foreach($sql_sub_relational_joins as $join) {
				$fields[$join['table']] = $this->db->list_fields($join['table']);
			}

			foreach($sql_sub_relational_joins as $join) {
				if(in_array('count', $join['accessors'])) {
					$this->db->select("COUNT(" . $join['table'] . "." . $join['field_name'] . ") as `" . $join['table'] . "." . $join['field_name'] . "_count`");
				} elseif(in_array('sum', $join['accessors'])) {
					$this->db->select("SUM(" . $join['table'] . "." . $join['field_name'] . ") as `" . $join['table'] . "." . $join['field_name'] . "_sum`");
				} elseif(in_array('active', $join['accessors'])) {
					// $this->db->select($join['table'] . '.' . $join['field_name'] . ' as `' . $join['table'] . '.' . $join['field_name'] . '`');
					foreach($fields[$join['table']] as $field) {
						$this->db->select($join['table'] . '.' . $field . ' as `' . $join['table'] . '.' . $field . '`');
					}
				}
			}
		}

		if(count($sql_joins) > 0) {
 			$this->db->join('map', "map.map_id_a = {$this->table}.{$this->primary_key} AND map.map_table_a = '{$this->table}'", 'LEFT', false);

			foreach($sql_joins as $join) {
				$join_table = $join['table'];
				$join_table_pk = $join_table . '_id';
				$this->db->join($join_table, "{$join_table}.{$join_table_pk} = map.map_id_b AND map.map_table_b = '{$join_table}'", 'LEFT', false);
			}


		}

		if(count($sub_relational_tables)  > 0) {
			foreach($sub_relational_tables as $table) {
				if(@$this->controller->joiner == 'parent' ) {
					$this->db->join($table, "{$table}.{$this->primary_key} = {$this->table}.{$this->primary_key}", "LEFT");
				} else {
					$this->db->join($table, "{$table}.{$table}_id = {$this->table}.{$table}_id", "LEFT");
				}
			}
		}

		// IF SEARCH
		if(@$params['search_term']) {

			// filtered result
			$filter = $params['search_term'];
			$sql_search_field_addons = array();

			foreach($this->controller->search_fields as $search_field) {
				if(strpos($search_field, '.') !== FALSE) {
					$this->db->or_like($search_field, $filter);
				} else {
					$this->db->or_like("{$this->table}.{$search_field}", $filter);
				}
			}
		}

		//IF Where option
		if(@$this->controller->search_config['where']) {
			foreach($this->controller->search_config['where'] as $key => $value){
				$this->db->where($key,$value);
			}
		}

		$this->db->group_by($this->table.'.'.$this->primary_key);

		if(!@$params['search_term']) {
			$this->db->order_by($order);

			if($offset !== '' && $limit !== false) {
				$this->db->limit($limit);
				$this->db->offset($offset);
			}
		}

		if($this->share_key != '') {
			$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
		}

		if (is_array($where)) {
			foreach($where as $option) {
				$this->db->where($option['param'], $option['val'], $option['escape']);
			}
		}

		if (is_array($direct_join)) {
			foreach($direct_join as $option) {
				$fields = $this->db->list_fields($option['param']);
				foreach($fields as $field) {
					$this->db->select($option['param'] . '.' . $field . ' as `' . $option['param'] . '.' . $field . '`');
				}
				$this->db->join($option['param'], $option['val'], $option['option']);
			}
		}

		//jai added //  I need this
		if(is_array($map_join))
		{

			foreach($map_join as $option)
			{
				$this->db->select('map.*,count(*) as productscount');
				$this->db->join('map', 'map.map_id_b = store_categories.store_categories_id');
				$this->db->where('map.map_table_b',$this->table);

			}
		}

		$data['rows'] = $this->db->get($this->table)->result();

		//print $this->db->last_query(); die();

		$total_rows = $this->db->query("SELECT FOUND_ROWS() as rows")->row();

		if(@$params['search_term']) {
			$data['total_num_rows'] = 0;
		} else {
			$data['total_num_rows'] = $total_rows->rows;
		}

		return $data;
	}

	function load_record($id) { // loading for editing

		$fields =& $this->get_fields();
		$row = array();
		$field_joins = array();
		foreach($fields as &$field) {
			if(get_parent_class($field) == 'CIID_Field_Multi_Selectable') {
				if(is_array($field->join)) {
					if($field->mapped) {
						$field_joins[] = $field;
					}
				}
			}
		}

		$this->db->where($this->primary_key, $id);
		if($this->share_key != '') {
			$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
		}

		$this->db->limit(1);
		$row['basics'] = $this->db->get($this->table)->row();

		if(!$row['basics']) {
			redirect(site_url('modules/' . $this->router->class));
		}

		$row['sets'] = array();

		if(count($field_joins) > 0) {
			// join tables through map table
			foreach($field_joins as &$field) {

				$table_join = $field->join['table'];

				$this->db->select($table_join. '.*');
				$this->db->join($table_join, $table_join . '.' . $table_join . '_id = map.map_id_b', 'inner');
				$this->db->where('map.map_table_a', $this->table);
				$this->db->where('map.map_table_b', $table_join);
				$this->db->where('map.map_id_a', $id);
				$result = $this->db->get('map')->result();

				// adding x_set to active record
				$set_name = $table_join . '_set';

				$row['sets'][$set_name] = $result;
				//$row->$set_name = $result;

				foreach($result as $selected_option) {
					$pk = $table_join . '_id';
					$field->chosen_options[] = $selected_option->$pk;
				}
			}
		}
		return $row;
	}

	function get_fields() {
		$fields = array();
		foreach($this->controller->form->groups as &$group) {
			if( count($group->fields) > 0 ) {
				foreach($group->fields as &$field) {
					$fields[] = $field;
				}
			}
		}
		return $fields;
	}

	function get_options($table_name, $args=array()) {
		// args = where array
		if(isset($args['order_by'])){// or order_index
			$this->db->order_by($args['order_by']);
			unset($args['order_by']);
		}else{
			$this->db->order_by('name');
		}

		$result = $this->db->get_where($table_name, $args)->result();
		if($result) {
			return $result;
		} else {
			return array();
		}
	}

	/* ajax */
	function search($search_term = '', $config = array()) {
		$tables_joined = array();
		$select_statement = $this->table . '.' . $config['id'] . ' as id, ' . $config['name'] . ' as name, ' . $config['label'] . ' as label';
		$this->db->select($select_statement);
		foreach($this->controller->search_fields as $search_field) {
			if(strpos($search_field, '.') !== FALSE) {
				$table = explode('.', $search_field);
				$table = $table[0];

				if(!in_array($table, $tables_joined)) {
					$tables_joined[] = $table;
					$this->db->join($table, "{$table}.{$table}_id = {$this->table}.{$table}_id", "LEFT");
				}
			}

			$this->db->or_like($search_field, $search_term);
		}

		if($this->share_key != '') {
			$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
		}

		$this->db->group_by($this->table . '.' . $config['id']);
		return $this->db->limit(10)->get($this->table)->result();
	}

	function save(&$record) {
		// basic saving
		$ignore_values = array(
			'created_date', 'updated_date', $this->order_key, $this->share_key,
		);

		$now = date('Y-m-d H:i:s');
		if($this->controller->form->mode == 'add') {
			/* If record is sortable then we need to insert the inital order value */
			if($this->controller->sortable) {
				$this->db->select ("max(" . $this->order_key . ") as max_order_index");
				if($this->share_key != '') {
					$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
				}

				if($this->share_group_key != '') {
					$this->db->where($this->share_group_key, $record->item($this->share_group_key)->value);
				}

				$order_index = $this->db->get($record->table)->row();
				if($order_index->max_order_index == '') {
					$this->db->set($this->order_key, 1);
				} else {
					$this->db->set($this->order_key, $order_index->max_order_index + 1);
				}
			}
			$this->db->set('created_date', $now);
		} elseif($this->controller->form->mode == 'edit') {
			$query = $this->db->get_where($record->table, array($this->primary_key => $record->pk()));

			if($query->num_rows() == 1) {
				$original_record = $query->row();
			} else {
				die('ERROR: Trying to edit record that doesnt exist');
			}

			if($this->controller->sortable) {

				/* Check if we share group has changed then shuffle order indexes accordingly */

				/* 2 types of shares
					- share , this is when you have different controllers using the same table
					- share group - this is when you have many groups for the one table
				*/

				if($this->share_group_key != '') {
					/* Share group has changed */
					if(@$original_record->{$this->share_group_key} != @$record->item($this->share_group_key)->value) {
						/* shuffle order from previous share group */
						$this->update_order_index($record->pk(), 9999999);
						$this->db->select ("max(" . $this->order_key . ") as max_order_index");

						if($this->share_key != '') {
							$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
						}

						$this->db->where($this->share_group_key, $record->item($this->share_group_key)->value);
						$order_index = $this->db->get($record->table)->row();
						if(@$order_index->max_order_index == '') {
							$this->db->set($this->order_key, 1);
						} else {
							$this->db->set($this->order_key, $order_index->max_order_index + 1);
						}
					}
				}
			}
		}

		$this->db->set('updated_date', $now);
		$url_overrides = array();

		// NEEDS SOME EPIC REFACTORING
		// WORKS IN SEQUENCE, so if the url field or thumbs fields are first in the table this will  not work

		foreach($record->get_items() as $key => $item) {

			if(!in_array($key, $ignore_values)) {
				// URLIFY
				if(in_array($key, $url_overrides)) {
					continue;
				}

				if(@$item->field->urlify) {
					$url_overrides[] = $item->field->url_field;
					$this->db->set($item->field->url_field, url_title(strtolower($item->value)));
				}

				// THUMBIFY
				if(@$item->field->thumbify) {

					foreach($item->field->thumb_params as $thumb_param) {
						if(@$thumb_param['new_name'] != '') {
							$this->db->set($thumb_param['field'], $thumb_param['new_name']);
							$url_overrides[] = $thumb_param['field'];
						}
					}
				}

				$this->db->set($key, $item->value);
			}
		}

		if($this->controller->form->mode == 'add') {
			if($this->share_key != '') {
				$this->db->set($this->share_key, $this->share_value);
			}

			$this->db->insert($record->table);
			// add
		} elseif($this->controller->form->mode == 'edit') {
			$this->db->where($this->primary_key, $record->pk());
			if($this->share_key != '') {
				$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
			}
			$this->db->update($record->table);
			// update
		} else {
			die('crud method not set');
		}
		//echo $this->db->last_query(); exit;
		if(!$record->pk()) {
			$record->set_pk($this->db->insert_id());
		}
		$this->remap($record);
		$this->update_module();
		return true;
	}

	function delete(&$record) {
		// update order_index if applicable
		if($this->controller->sortable) {
			$this->db->set($this->order_key, $this->order_key . ' -1', FALSE);
			$this->db->where($this->order_key . ' > ', $record->item($this->order_key)->value);
			if($this->share_key != '') {
				$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
			}
			if($this->share_group_key != '') {
				$this->db->where($this->share_group_key, $record->item($this->share_group_key)->value);
			}
			$this->db->update($this->table);
		}

		$this->unmap($record);

		$pk_id = $record->pk();

		$this->db->where($this->primary_key, $pk_id);
		$this->db->delete($this->table);

		$this->update_module();

		return true;
	}

	function remap(&$record) {

		if(!@$record->pk()) {
			return;
		}

		$sql = "SELECT map_table_b table_name, GROUP_CONCAT(map_id_b) as existing_options FROM map
				WHERE (map_table_a = ? AND map_id_a = ?)
				GROUP BY map_table_b";

				// GROUP BY AND GROUP CONCAT

		$map_params = array(
			$this->table,
			$record->pk(),
			$this->table,
			$record->pk(),

		);

		$inserts = array();
		$removals = array();
		$current_mappings = $this->db->query($sql, $map_params)->result();
		$all_sets = $record->get_sets();
		foreach($all_sets as $set) {
			$existing_options = array();
			$set_name = $set->field->name;
			$table_name = $set->field->join['table'];
			foreach($current_mappings as $mapping) {
				if($mapping->table_name == $table_name) {
					$existing_options = explode(',', $mapping->existing_options);
					foreach($existing_options as $exopt) {
						if(!in_array($exopt, $set->chosen_options)) {
							$removals[] = array('table' => $table_name, 'value' => $exopt);
						}
					}
				}
			}

			foreach($set->chosen_options as $copt) {
				if(!in_array($copt, $existing_options)) {
					$inserts[] = array('table' => $table_name, 'value' => $copt);
				}
			}
		}

		if(count($inserts) > 0) {
			$sql = "INSERT INTO map (map_table_a, map_id_a, map_table_b, map_id_b) VALUES ";
			$inserts_sql = array();
			foreach($inserts as $insert) {
				$inserts_sql[] = "(" . $this->db->escape($record->table) . "," . $this->db->escape($record->pk()) . "," . $this->db->escape($insert['table']) . "," . $this->db->escape($insert['value']) . ")";
			}
			$sql .= implode(",", $inserts_sql);
			$this->db->query($sql);
		}

		if(count($removals) > 0) {
			$sql = "DELETE FROM map WHERE ";
			$removals_sql = array();
			foreach($removals as $removal) {
				$removals_sql[] = "(map_table_a = " . $this->db->escape($record->table)
								. " AND map_id_a = " . $this->db->escape($record->pk())
								. " AND map_table_b = " . $this->db->escape($removal['table'])
								. " AND map_id_b = " . $this->db->escape($removal['value']) . ")";
			}

			$sql .= implode(" OR ", $removals_sql);
			$this->db->query($sql);
		}
	}

	function unmap(&$record) {

		$sql = "DELETE FROM map
				WHERE (map_table_a = ? AND map_id_a = ?)
				OR (map_table_b = ? AND map_id_b = ?)";

		$map_params = array(

			$this->table,
			$record->pk(),
			$this->table,
			$record->pk(),

		);

		return $this->db->query($sql, $map_params);

	}

	function is_unique($table, $field, $value, $primary_key='', $primary_key_value='') {

		$this->db->select('count(*) as cnt');
		$this->db->where($field, $value);
		$this->db->where($primary_key . ' <>', $primary_key_value);
		if($this->share_key != '') {
			$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
		}

		if($this->share_group != '') {
			$this->db->where($this->share_group_key, $this->record->item($this->share_group_key)->value);
		}

		$count = $this->db->get($table)->row();
		if($count->cnt > 0) {
			return false;
		} else {
			return true;
		}
	}

	function get_table_structure($table) {
		$sql = "SHOW COLUMNS FROM `{$table}`";
		$columns = $this->db->query($sql)->result();
		return $columns;
	}

	function switchvalue($table, $id, $field, $wrap) {
		$val = $this->db->where($this->primary_key, $id)->get($table)->row()->$field;
		$newval = $wrap[0]['value'];
		foreach ($wrap as $key => $w) {
			if ($w['value'] == $val) {
				$newval = $wrap[($key + 1) % count($wrap)]['value'];
			}
		}
		$this->db->where($this->primary_key, $id)->update($table, array($field => $newval));
	}

	function update_order_index( $node_id , $index ) {
		$node = $this->db->get_where( $this->table, array( $this->primary_key => $node_id ))->row();
		if($node) {
			$this->update_module();
			// update self
			$update = array($this->order_key => $index);
			$this->db->where($this->primary_key, $node_id);
			if($this->db->update($this->table, $update)) {
				// update others
				if($index > $node->{$this->order_key}) {
					// moved to a lower position
					$this->db->set($this->order_key, $this->order_key.'-1', FALSE);
					$this->db->where($this->order_key .' <=', $index);
					$this->db->where($this->order_key . ' >=', $node->{$this->order_key});
					$this->db->where($this->primary_key . ' <>', $node_id);
					if($this->share_key != '') {
						$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
					}
					if($this->share_group_key != '') {
						$this->db->where($this->share_group_key, $node->{$this->share_group_key});
					}
					$this->db->update($this->table);
				} elseif($index < $node->{$this->order_key}) {
					// moved to a higher position
					$this->db->set($this->order_key, $this->order_key.'+1', FALSE);
					$this->db->where($this->order_key .' >=', $index);
					$this->db->where($this->order_key .' <=', $node->{$this->order_key});
					$this->db->where($this->primary_key . ' <>', $node_id);
					if($this->share_key != '') {
						$this->db->where($this->table.'.'.$this->share_key, $this->share_value);
					}
					if($this->share_group_key != '') {
						$this->db->where($this->share_group_key, $node->{$this->share_group_key});
					}
					$this->db->update($this->table);
				} else {
					return TRUE;
				}

				if($this->db->affected_rows() == 0) {
					// update others failed. revert back to original
					$update = array($this->order_key => $node->{$this->order_key});
					$this->db->where($this->primary_key, $node_id)->update($this->table, $update);
					return FALSE; // update others failed
				}
				return TRUE; // all clear
			} else {
				return FALSE; // update failed
			}
		} else {
			return FALSE; // doesnt exist
		}
	}

	function update_module() {
		$this->db->set('updated_date', date('Y-m-d H:i:s'));
		$this->db->where('url', $this->router->class);
		$this->db->update('modules');
	}
}
