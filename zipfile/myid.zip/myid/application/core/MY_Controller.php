<?php

class MY_Controller extends CI_Controller {

	//var $navmenu_new;
	var $access_level = array();

	public function __construct() {

		parent::__construct();

		if (!isset($this->tpl))
			$this->tpl = new stdClass();

		if (!isset($this->tpl->page))
			$this->tpl->page = new stdClass();

		if(!$this->session->userdata('user') && $this->router->class != 'login' && $this->input->post('upload_key') != 'abc123') {
			//check logged in - if not send them to the login page
			redirect(site_url('login'));
			exit;
		}

		$this->load->library('user_agent');

		$this->fetch_site_details();
		//$this->fetch_browser_css();
		$this->fetch_quick_links();

		if($this->router->class != 'login' && $this->router->class != 'dashboard' && $this->router->class != 'logout') {

			if(!$this->module_enabled($this->router->class)) {
				show_404('');
			}
		}

		// jai new stuff
		// what this does ->allow user to give acces level below them
		$new_array= array();
		$val = 1;
		while ($this->site_model->user_level >= $val) {
			if($val ==1){
				array_push($this->access_level,array('label' => 'level '.$val, 'value' => $val, 'colour' => '#D00','default' => TRUE));
			}else{
				array_push($this->access_level,array('label' => 'level '.$val, 'value' => $val, 'colour' => '#D00'));
			}
			$val ++;
		}

		if($this->site_model->user_level >=10){

		array_push($this->access_level,array('label' => 'level 10', 'value' => '10', 'colour' => '#D00'));
		}
                

	}


	private function fetch_browser_css(){
		//add the required browser css file
		if($this->agent->browser() == 'MSIE') {
			$version = substr($this->agent->version(), 0, strpos($this->agent->version(), '.'));
			addScript('assets/css/'.strtolower($this->agent->browser()).'_'.$version.'_screen.css', 'css');
		} else {
			if(strpos(strtolower($this->agent->platform), 'mac') === FALSE) {
				addScript('assets/css/'.strtolower($this->agent->browser()).'_screen.css', 'css');
			} else {
				addScript('assets/css/'.strtolower('mac_'.$this->agent->browser()).'_screen.css', 'css');
			}
		}
		$this->tpl->css = $this->script['css'];
	}


	public function module_enabled($module) {
		return $this->fetch_module_id($module);
	}


	private function fetch_site_details() {
		$this->load->model('dashboard_model');
		$this->load->model('site_model');

   		$head_modules = $this->site_model->navmenu();

 		$navmenu = array();
 		foreach ($head_modules as $key => $value) {
 			$navmenu[$value->name] = $value->url;
 		}

 		 $this->navmenu_new = $navmenu;

		$this->tpl->modules = $this->site_model->fetch_modules('enabled');
		$this->tpl->dashboard	= $this->dashboard_model->fetch_latest_updates();
		$this->tpl->inactive_modules = $this->site_model->fetch_modules('disabled');
		$this->tpl->nav_items = $this->dashboard_model->get_nav_items();
		//var_dump($this->tpl->nav_items);
	}


	private function fetch_latest_news() {
		$this->load->model('news_model');

		$this->tpl->latest_news = $this->news_model->fetch_latest_news();
	}


	private function fetch_quick_links() {
		$this->load->model('site_model');

		$this->tpl->quick_links = $this->site_model->fetch_quick_links(5);
	}


	public function fetch_module_id($module) {
		foreach($this->tpl->modules as $item => $data) {
			if(strtolower($data->url) == strtolower($module)) {
				return $data->id;
				break;
			}
		}

		return 0;
	}


	public function log_link() {
		$url = preg_replace('/(\/[0-9]*)$/','', $this->uri->uri_string());
		$this->site_model->add_quick_link($url, $this->tpl->page->title);
	}


	public function paginate() {
		if (!isset($this->paginate))
			$this->paginate = new stdClass();
		$this->paginate->limit = PAGE_RESULT_LIMIT;
		$this->paginate->current_page = ($this->session->userdata('current_page')) ? $this->session->userdata('current_page') : 1;
		$this->paginate->offset = $this->paginate->limit * ($this->paginate->current_page - 1);
		$this->session->unset_userdata('current_page');
	}


	public function generate_pagination($data) {

		$num_pages = ceil($data->size / $this->paginate->limit);

		$links = array();
		$pages = array();

		if($num_pages > 1) {
			if ($num_pages <= 15) {
				for ($inc = 1; $inc <= $num_pages; $inc++)
					$pages[] = $inc;
			} else {
				/* Too many pages. Show only First 3, last 3, and current +- $sp */
				$sp = 2;

				/* How many pages do we skip? */
				if ($num_pages < 50)
					$step = 5;
				else if ($num_pages < 100)
					$step = 10;
				else if ($num_pages < 200)
					$step = 20;
				else if ($num_pages < 500)
					$step = 50;
				else
					$step = 100;

				/* First 3 */
				$last = 1;
				if ($this->paginate->current_page > $sp) {
					for ($inc = 1; $inc <= min($this->paginate->current_page-$sp, 3); $inc++)
						$pages[] = $inc;

					if ($inc < $this->paginate->current_page - $sp)
						$pages[] = false;

					$last = $inc;
				}

				/* Now go in steps of $step until current */
				if ($this->paginate->current_page - $sp > $step) {
					$begin = floor(($last+$step)/$step)*$step;
					$end = floor((max($this->paginate->current_page-$sp, $last)+$step)/$step)*$step;
					for ($inc = $begin; $inc < $end; $inc += $step) {
						$pages[] = $inc;
						if ($this->paginate->current_page - $sp > $inc + 1)
							$pages[] = false;
					}
				}

				/* Current +- $sp */
				for ($inc = max($this->paginate->current_page - $sp, $last); $inc <= min($this->paginate->current_page + $sp, $num_pages); $inc++) {
					$pages[] = $inc;
					$last = $inc;
				}

				/* Steps again */
				if (max($this->paginate->current_page + $sp, $num_pages - 3) - $last > $step) {
					$begin = floor(($last+$step)/$step)*$step;
					$end = ceil(($num_pages - $step)/$step)*$step;

					for ($inc = $begin; $inc < $end; $inc += $step) {
						$pages[] = false;
						$pages[] = $inc;
					}
					$last = $inc;
				}

				/* Last 3 */
				if ($last < $num_pages) {
					if ($last < $num_pages - 3)
						$pages[] = $inc;
					for ($inc = max($last + 1, $num_pages - 2); $inc <= $num_pages; $inc++)
						$pages[] = $inc;
				}
			}
		}
		$pager = array(
			'pages' => $pages,
			'current' => $this->paginate->current_page,
			'url' => site_url().$this->uri->uri_string(),
		);

		return $this->load->view('widgets/pagination.php', $pager, true);
	}


	public function fetch_country_code($country) {
		switch(strtolower($country)) {
			case 'australia':
				$code = 'AU';
				break;
			case 'new zealand':
				$code = 'NZ';
				break;
			default:
				$code = 'AU';
		}

		return $code;
	}

}

class Tools_Controller extends CI_Controller {

	function __construct() {
		parent::__construct();
		if(!$this->session->userdata('user')) {
			redirect(site_url('login'));
			exit;
		}
	}
}


require_once(APPPATH.'libraries/ciid_controller.php');
