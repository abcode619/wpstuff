<?php

class MY_loader extends CI_Loader {
	
	function __construct() {
		
		parent::__construct();
		
		//$this->_ci_model_paths = array('../' . APPPATH);
	
	}

}

?>