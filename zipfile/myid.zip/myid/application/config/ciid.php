<?php


$config['ciid_status_values'] = array(

	0	=> 'Offline',
	1	=> 'Live'


);
