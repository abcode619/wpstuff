<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

define('RESOURCE_PATH', '/resources/');

require_once('../application/config/constants.php');

define('BUSINESS_NAME', 'Orgone');
define('PAGE_RESULT_LIMIT', 25);

//errors
define('RECORD_EXISTS',           'The {singular} "{record_name}" already exists. Please choose a different name or edit the existing category');
define('RECORD_ADD_FAIL',         'Your attempt to add the {singular} "{record_name}" has been unsuccessful. Please try again in a few minutes.');
define('RECORD_EDIT_FAIL',        'Your attempt to edit the {singular} "{record_name}" has been unsuccessful. Please try again in a few minutes.');
define('RECORD_DELETE_FAIL',      'Your attempt to delete the {singular} "{record_name}" has been unsuccessful. Please try again in a few minutes.');
define('RECORD_ADD_SUCCESS',      'The {singular} "{record_name}" has been added successfully.');
define('RECORD_EDIT_SUCCESS',     'The {singular} "{record_name}" has been edited successfully.');
define('RECORD_DELETE_SUCCESS',   'The {singular} "{record_name}" has been deleted successfully.');
define('RECORD_INVALID',          'The {singular} you are attempting to edit does not exist.');
define('RECORD_DELETE_CONFIRM',   'You are about to delete the {singular} "{record_name}". Are you sure you wish to do so?');

/* End of file constants.php */
/* Location: ./application/config/constants.php */
