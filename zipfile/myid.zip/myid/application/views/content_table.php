<?php if (count($table)): ?>
	<table class="content_table" cellspacing="0" cellpadding="0">
	<?php foreach ($table as $key => $t): ?>
		<?php if (isset($t['title'])): ?>
		<thead class='subgroup'>
			<tr><td colspan='<?= count($t['header'])+1 ?>'><h4><?= $t['title'] ?></h4></td></tr>
		</thead>
		<?php endif; ?>
		<thead>
			<tr class='header_row'>
				<?php foreach ($t['header'] as $h): ?>
					<th><?= $h ?></th>
				<?php endforeach; ?>
				<th></th>
			</tr>
		</thead>
		<tbody>
		<?php foreach ($t['data'] as $pk => $row): ?>
			<tr data-id='<?= $pk ?>'>
				<?php foreach ($row as $f): ?>
					<td<?= isset($f['class']) ? " class='{$f['class']}'" : ''?><?= isset($f['class']) ? " class='{$f['class']}'" : '' ?>>
						<?= $f['content'] ?>
					</td>
				<?php endforeach; ?>
			</tr>
		<?php endforeach; ?>
		</tbody>
	<?php endforeach; ?>
	</table>
<?php else: ?>
	There are currently no entries in this module.
<?php endif; ?>

