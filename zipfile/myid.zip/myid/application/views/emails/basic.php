<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
	<title></title>
</head>
<body bgcolor="#ececeb">
	<table style="margin-left:auto;margin-right:auto;width:600px;background:#666666" cellspacing="1">
		<tr>
			<td valign="bottom" style="padding:0 0 10px 10px;background:#d6d6d6;height:100px;font:19px arial;color:#666">
				<?php print $title?>
			</td>
		</tr>
		<tr>
			<td style="background:#FFFFFF;padding:20px 0 50px 10px;">
				<table style="font:12px arial">
<?php
				foreach($content as $k => $v):
?>
					<tr>
						<td valign="top" style="width:110px"><?php print $k?>:</td>
						<td valign="top"><?php print $v?></td>
					</tr>
<?php
				endforeach;
?>
				</table>
			</td>
		</tr>
		<tr>
			<td valign="middle" style="background:#292929;height:50px;color:#CCCCCC;font:11px arial">
				<img style="float: right" src="<?php print base_url()?>assets/myid/images/email_cms_logo.jpg" alt="" />
				<span style="float:right;margin-top:10px">Delivered by</span>
			</td>
		</tr>
	</table>
</body>
</html>