<body style="width: 640px;margin: 0 auto;padding: 0;height: auto;font-family: verdana;">
    <div style="border: 15px solid #28BB7F;border-radius: 5px;">
        <div class="footer_details" style="background: none repeat scroll 0 0 #28bb7f;color: #fff;float: left;height: 35px;margin-bottom: 15px;text-align: center;width: 100%;">
            <div style="font-size: 14px;">
                <b>This is an auto-generated email. Please do not respond to it.</b>                
            </div>            
        </div>
        <div class="logo" style="width: 100%;text-align: center;height: 100px;padding: 20px 0px;">
            <img src="<?php echo str_replace('/myid', '', site_url('assets/images/logo.png')); ?>" alt="Orgone Energy" />
        </div>
        <div class="upper_info">
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Hi, <?php echo $data['billing_firstname']; ?>! </p>            
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Thank you for placing your order with Orgone Energy Australia.</p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;"><?php echo $heading; ?></p>
          <?php 
            if(isset($intro) && $intro == 'Shipped')
            {
          ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">We are happy to inform you that your order below has been shipped today. Please expect the delivery of your order within the time-frame noted on our Shipping FAQs page. <br><br> If you have any questions, please feel free to contact us.</p>
           <?php 
           }if(isset($intro) && $intro == 'Hold'){
           ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">We wanted to let you know as soon as possible that we are still waiting on suitable stock to fulfill your order. We anticipate this to be available very soon and will notify you when your order has been shipped. For reference, below is what you have ordered.</p>
           <?php
           }
           ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;"> Thank you.</p> 
        </div>
           
        <div class="order_details">
            <?php        
                if($data['payment_currency'] == "AUD") {
                    $currency = "AUD";                                                                
                } else {
                    $currency = "USD";                                                                
                }            
            ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 20px;"><u>Order details: </u></p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                Order ID : <b><?php echo '#'.$data['store_order_id']; ?></b> (Placed on <?php echo date("D j, F  Y g:i a");?>)<br>
                Payment Method : <b><?php echo $data['payment_method']; ?></b><br>
                Transaction ID : <b><?php echo $data['reference_no']; ?></b></p>
            <div style="margin:3px 10px;padding: 3px;font-size: 14px;">
                <table style="width: 97%;" border="1" cellpadding="0" cellspacing="0" bordercolor="#28BB7F">
                    <tr style="font-size: 14px;">
                        <th style="width: 30%;">Product</th>
                        <th style="width: 30%;">Product Type</th>
                        <th style="width: 5%;">Qty</th>
                        <th style="width: 15%;">Price (<?php echo $currency; ?>)</th>
                        <th style="width: 20%;text-align: right">Total (<?php echo $currency; ?>)</th>
                    </tr>
                    <?php foreach ($cart as $key => $item): ?>
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;"><?php echo $item['name']; ?></td>
                        <td style="width: 30%;padding: 3px;"><?php echo $item['store_price_name']; ?></td>
                        <td style="width: 5%;text-align: center;"><?php echo $item['quantity']; ?></td>
                        <td style="width: 15%;text-align: center;">$<?php echo sprintf('%.2f', $item['price']); ?></td>
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?php echo number_format(($item['price']*$item['quantity']), 2); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4">Cart Total : </td>                        
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?= sprintf('%.2f', $data['order_amount']) ?></td>
                    </tr>
                    <?php                                                             
                        $discount = $this->session->userdata['cart_contents']['discount']['COUPON'];
                        if(!empty($discount))
                        {
                    ?>
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4"><?php if(isset($discount->referrar_user_id)) { echo "Referrar Discount"; } else { echo "Coupon Discount"; } ?>:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo number_format($discount->amt, 2, '.', ''); ?></td>
                        </tr>

                    <?php } 
                              
                        if (isset($data['wholesaler_amount_used']) && $data['wholesaler_amount_used'] != "") {
                            ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Wholesaler Discount:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo $data['wholesaler_amount_used']; ?></td>
                        </tr>

                        <?php
                        }

                        if($this->session->userdata('current_credit') > 0)
                        {
                            ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Credit Discount:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo $this->session->userdata('current_credit'); ?></td>
                        </tr>

                        <?php
                        }

                        if (($this->session->userdata['bulk_total'] != 0 ) || ( $this->session->userdata['bulk_total_usd'] != 0 )) { ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Bulk Size Shipping:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $
                                <?php
                                if ($currency == "AUD") {
                                    echo number_format($this->session->userdata['bulk_total'], 2, '.', '');
                                } else {
                                    echo number_format($this->session->userdata['bulk_total_usd'], 2, '.', '');
                                }
                                ?>
                            </td>
                        </tr>

                        <?php
                        } 

                        $extra_charges_mini = $this->session->userdata('extra_charges');
                        if (!empty($extra_charges_mini)) {
                            foreach ($extra_charges_mini as $key => $value) {
                                echo "<tr style='font-size: 12px;font-weight: normal;'>";
                                ?>
                        
                                
                                <td style="width: 30%;padding: 3px;" colspan="4"><?php echo $value['name']; ?>:</td>                                    
                                
                                <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> + $
                                    <?php
                                    if ($currency == "AUD") {

                                        $multiply_by = (floor($mini_summary['cart_total'] / $value['min_amount']) + 1);
                                        echo number_format(($value['val_aud'] * $multiply_by), 2, '.', '');
                                    } else {
                                        $multiply_by_usd = (floor($mini_summary['cart_total_usd'] / $value['min_amount']) + 1);
                                        echo number_format(($value['val_usd'] * $multiply_by_usd), 2, '.', '');
                                    }
                                    ?>  
                                </td>
                                
                                </tr>    

                                <?php
                            }
                        }


                        ?>
                        <?php if($data["shipping_fee"]): ?>
                        
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Shipping:<?php echo $data["shipping_method"] ?></td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> + $<?= sprintf('%.2f', $data["shipping_fee"]) ?></td>
                        </tr>                                
                        
                        <?php else : ?>
                        
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Shipping:</td>
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">Pick up</td>
                        </tr>                         
                        
                        <?php 
                        endif; 
                        ?>                            
                        
<!--                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4">Shipping:India - Standard Post</td>                        
                        <td style="width: 15%;text-align: right;font-weight: bold;padding: 4px;">$1223.85</td>
                    </tr>-->
                    
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4"><b>Total</b></td>                        
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?php echo number_format(($data['paid'] - $cart_wholesaler_discount), 2) . " " .  $currency; ?></td>
                    </tr>
                </table>                
            </div>
        </div>
        
        <div class="shipping_details">
            <p style="margin-left: 10px;padding: 3px;font-size: 20px;"><u>Shipping details: </u></p>
        
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                <?= $data['[billing_firstname]'] ?> <?= $data['billing_lastname'] ?><br /><br />
                <?= $data['billing_address1'] ?><br />
                <?= $data['billing_address2'] ?><br />
                <?= $data['billing_suburb'] ?>, <?= $data['billing_state'] ?>, <?= $data['billing_postcode'] ?><br />
                <?= $data['billing_country'] ?><br /><br />
                <?= $data['billing_email'] ?><br />
                <?= $data['billing_phone'] ?><br />
            </p>
            
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                <b>User Comments</b> : <?= $data['comments'] ?>
            </p>
        </div>
        
        <div class="footer_detail" style="background: #28BB7F; color: #fff;">            
            <div style="margin-left: 10px;padding: 30px 3px;font-size: 14px;color: #fff;">
                <b>This email was sent from Orgone Energy Australia</b><br>
                Email: <a href="mailto:<?php echo SITE_SUPPORT_EMAIL; ?>" style="font-weight: bold;color: #fff"><?php echo SITE_SUPPORT_EMAIL; ?></a><br>
                Phone: <?php echo SITE_PHONE; ?><br>
                P O Box 250<br>
                Rushworth VIC 3612<br>
                Australia
            </div>            
        </div>
        
    </div>
</body>
