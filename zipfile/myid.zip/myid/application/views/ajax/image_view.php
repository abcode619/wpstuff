<?php foreach($photos as $photo) : ?> 
	 
<div class="photo_holder" data-id="<?php echo $photo->photo_id?>"> 
	
	<div class="photo_left">
	
		<div style="height:30px; font-size:13px;"><span>ID: <strong><?php echo $photo->photo_id?></strong></span></div>
	
		<div>
	
			<img src="/assets/photos/<?php echo $photo->photo_id?>_thumb.jpg" width="<?php echo THUMB_WIDTH ?>" height="<?php echo THUMB_HEIGHT?>" />
	
		</div>
	
	</div>
	
	<div class="photo_right">
   		
		 <div style="float:right;"><a href="javascript:void(0);" class="image_delete" title="delete photo" data-id="<?php echo $photo->photo_id?>">X</a></div>
		 
		
		<div style="height:30px; font-size:13px;">
			<span>Original Name: <strong><?php echo $photo->original_name?></strong></span>
		</div> 
	
		<div class="clearer"></div>
	   
		
		<?php if( ($photo->longitude == 0 || $photo->longitude == '') && ($photo->latitude == 0 || $photo->latitude == '')) : ?>
		<div class="geo_error">Unable to find geolocation. Please double check the address associated with this photo</div>
		<?php endif; ?>	
	
		<input type="hidden" name="photo_id[]" value="<?php echo $photo->photo_id?>" />
	 
		<div class="use_address_container" style="text-align:left;">
			<table>
				<tr>
					<td>
						<input type="checkbox" data-id="<?php echo $photo->photo_id?>" class="use_address" name="photo_use_address[]" value="<?php echo $photo->photo_id?>" <?php if($photo->use_address) echo 'checked="checked"';?> />
					</td>
					<td>
				   		<span>Use same address as above</span>
					</td>
				</tr>
			</table>   
	   	</div>
	
		<div class="address_container" data-id="<?php echo $photo->photo_id?>" <?php if($photo->use_address) echo 'style="display:none;"';?>>
	
			<table width="500">
	
				<tr>
					
					<td>No:</td>
	
					<td><input type="text" name="photo_street_number[]" class="photo_street_number" value="<?php echo $photo->street_number?>" /></td>
	
					<td>Street:</td>
	
					<td><input type="text" name="photo_street_name[]" class="photo_street_name" value="<?php echo $photo->street_name?>" /></td>
	
				</tr>
	
				<tr>
	
					<td>Suburb:</td>
					<td colspan="3"><input data-id="<?php echo $photo->photo_id?>" type="text" name="photo_suburb[]" value="<?php echo $photo->suburb?>" class="suburb_autocomplete photo_suburb" /></td>
	
				</tr>
	
				<tr>
	
					<td>State:</td>
					<td>
						
						<?php
							
							$states = array(
								'NSW',
								'VIC',
								'QLD',
								'WA',
								'SA',
								'TAS',
								'NT'
							);
						
						?>
						
						<select class="photo_state" data-id="<?php echo $photo->photo_id?>" name="photo_state[]">
							<option value="">Select State</option>
							<?php foreach($states as $state) : ?>
							<option value="<?php echo $state?>" <?php if($photo->state == $state) echo 'selected="selected"';?>><?php echo $state?></option>
						   	<?php endforeach; ?> 
						</select>
	
					</td>
					
					<td>Postcode:</td>
	
					<td><input class="photo_postcode" data-id="<?php echo $photo->photo_id?>" type="text" name="photo_postcode[]" value="<?php echo $photo->postcode?>" /></td>
	
				</tr>
	
			</table>
	
		</div>
	
	</div>
	
	<div class="clearer"></div>
	
	<a href="javascript:void(0);" style="float:right;" onclick="add_address('<?php echo $photo->photo_id?>');">Add Another Address</a>
	
	<div class="clearer"></div>
	
	<div class="additional_addresses_holder" data-id="<?php echo $photo->photo_id?>">
		<?php if(count(@$photo->additional_addresses)) {
			
			$data['photo'] = $photo;
			
			$this->load->view('ajax/image_sub_view', $data);
		
		} ?>
	</div>
	
	<div class="clearer"></div>
	
	
</div>	


<?php endforeach; ?>

