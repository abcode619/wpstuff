<div id="image_edit_modal" style="width:100%; height:100%; background-color:black; opacity:0.4; position:absolute; z-index:9999999999999"></div>
<div id="image_edit_container" class="ui-corner-all" style="background-color:#FFF; padding-top:25px; height:<?php echo $box_size + 200 ?>px; width:<?php echo $box_size + 200 ?>px; position:absolute; z-index:9999999999999; top:0;" align="center";>
	<div style="float:right; margin-top:-20px; margin-right:5px;"><button onclick="iedit.kill();" title="Close">x</button></div>
	<div id="step-holder" style="margin-left:auto; margin-right:auto; width:500px;">
		<div id="step_number_1" class="step-no">1</div>
		<div id="step_left_1" class="step-dark-left">Rotate Image</div>
		<div id="step_right_1" class="step-dark-right">&nbsp;</div>
		<div id="step_number_2" class="step-no-off">2</div>
		<div id="step_left_2" class="step-light-left">Crop/Resize Image</div>
		<div id="step_right_2" class="step-light-right">&nbsp;</div>
		<div id="step_number_3" class="step-no-off">3</div>
		<div id="step_left_3" class="step-light-left">Preview</div>
		<div id="step_right_3" class="step-light-round"></div>
		<div class="clear"></div>
	</div>
	<div id="step_container">
		<div id="image_loading_container">
			<img src="../../../assets/images/ajax-loader.gif" /><br /><br />
			Loading Image
		</div>
		<div id="image_edit_page1" style="display:none;" class="step_page">
			<div style="text-align:center; height:<?php echo $box_size ?>px; width:<?php echo $box_size ?>px; padding:10px; border:1px solid black;">		  
				<table width="100%" height="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td valign="middle" align="center" width="100%" height="100%" id="canvas_holder"></td>
					</tr>
				</table>
			</div>
			<div style="height:40px; padding-top:10px;">
				<div style="text-align:center"><strong>Rotate</strong></div>
				<div style="text-align:center"><button onclick="iedit.rotate(-90)" title="rotate -90&deg;">&lt;</button> <button onclick="iedit.rotate(90)" title="rotate 90&deg;">&gt;</button></div>
			</div>
			<div style="padding:0px 10px 0px 10px;">
				<button style="float:right;" onclick="image_editing_sequence(2);">Next</button>
			</div>
		
		</div>
		
		<div id="image_edit_page2" style="display:none;" class="step_page">
			<div style="height:<?php echo $box_size ?>px; padding:10px;">
				<table width="100%" height="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td valign="middle" align="center" width="100%" height="100%" id="croppable_container"></td>
					</tr>
				</table>
			</div>
			<div style="height:50px;"></div>
			<div style="padding:0px 10px 0px 10px;">
				<button style="float:left" onclick="image_editing_sequence(1);">Back</button><button style="float:right;" onclick="image_editing_sequence(3);">Next</button>
			</div>
		</div>
		
		<div id="image_edit_page3" style="display:none;" class="step_page">
			<div style="text-align:center; height:<?php echo $box_size ?>px; width:<?php echo $box_size ?>px; padding:10px; border:1px solid black;">
				<table width="100%" height="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td valign="middle" align="center" width="100%" height="100%" id="preview_holder"></td>
					</tr>
				</table>
			</div>
			<div style="height:50px;"></div>
			<div style="padding:0px 10px 0px 10px;">
				<button style="float:left" onclick="image_editing_sequence(2);">Back</button><button style="float:right;" onclick="image_editing_sequence(4);">Finish</button>
			</div>
		</div>
		
		<div id="image_edit_page4" style="display:none;" class="step_page">
			<img src="../../../assets/images/ajax-loader.gif" /><br /><br />
			Processing image...
		</div>
	</div>
</div>

<script type="text/javascript">

	var max_box = <?php echo $width > $height ? $width : $height ?>;
	$(document).ready( function() {
	
		settings = { 	
						'source' : '<?php echo $image?>',
						'maxWidth' : <?php echo $box_size?>,
						'maxHeight' : <?php echo $box_size?>,
						'targetWidth' : <?php echo $width?>,
						'targetHeight' : <?php echo $height?>,
						'table' : '<?php echo $table?>',
						'field' : '<?php echo $field?>',
						'id' : '<?php echo $id?>' };
	
		iedit = new ImageEditor(settings);

		$("#image_edit_container button").button();
		
	});

</script>
