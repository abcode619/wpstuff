<div id="image_revert_modal" style="width:100%; height:100%; background-color:black; opacity:0.4; position:absolute; z-index:2"></div>
<div id="image_revert_container" class="ui-corner-all" style="background-color:#FFF; padding-top:25px; height:500px; width:700px; position:absolute; z-index:999999; top:0; overflow:auto;" align="center">
	<div style="float:right; margin-top:-20px; margin-right:5px;"><button onclick="kill_revert();" title="Close">x</button></div>
	<div>
		<h3>Select version to revert to:</h3>
		<p>
			<strong style="color:red;">NOTE: </strong>Reverting to a previous image means you will lose all changes you have made since you made that change.
		</p>
	</div>
	<div style="height:400px; overflow:auto;">
		<table width="100%">
		<?php foreach($revisions as $revision) : ?>
			<tr>
				<td><img src="../../../<?php echo image_url($revision, 'thumb')?>" /></td>
				<td>Revision: <?php echo $revision->revision?></td>
				<td>Clean: <?php echo $revision->is_dirty ? 'No' : 'Yes'?></td>
				<td><a href="javascript:void(0)" onclick="do_revert(<?php echo $revision->id . ',' . $revision->revision?>);">REVERT</a></td>
			</tr>
		<?php endforeach; ?>
		</table>
	</div>
</div>

<script type="text/javascript">
	$(document).ready( function() {
		$("#image_revert_container button").button();
	});
</script>
