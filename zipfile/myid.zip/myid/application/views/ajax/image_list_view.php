<div id="images_container">
	<?php foreach($images as $image) : ?>
	<div style="padding:3px; border-bottom:1px dashed #ccc; height:180px; width:100%;" data-id="<?php echo $image->id?>" class="image_detail">
		<table width="100%">
			<tr>
				<td width="<?php echo IMAGE_THUMB_WIDTH?>"><img class="croppable_image" width="<?php echo IMAGE_THUMB_WIDTH?>" src="../../../<?php echo image_url($image, 'thumb')?>" style="border:1px solid #E5E5E5;" /></td>
				<td width="250">
					<table>
						<tr>
							<th align="left">Clean:</th><td><?php if($image->is_dirty) : ?><span style="color:red;">NO</span><?php else : ?><span style="color:#096">YES</span><?php endif; ?></td>
						</tr>
						<tr>
							<th align="left">Last Updated:</th><td><?php echo date('d/m/Y', strtotime($image->created_date))?></td>
						</tr>
						<tr>
							<th align="left">Created:</th><td><?php echo date('d/m/Y', strtotime($image->updated_date))?></td>
						</tr>
						<tr>
							<th align="left">Default:</th>
							<td>
								<?php if($image->default) : ?><span style="color:#6699CC;">YES</span>
								<?php else : ?><a href="javascript:void(0);" onclick="set_default_image(<?php echo $image->id?>);" style="color:#000000;" title="Click to set as default image for this product">NO</a>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<th align="left">Edit Image:</th><td><a href="javascript:void(0);" onclick="edit_image( <?php echo $image->id?> );">edit</a></td>
						</tr>
						<tr>
							<th align="left">Revert:</th><td><?php if($image->revision > 1) : ?><a href="javascript:void(0);" onclick="revert_image( <?php echo $image->id?> );">revert</a><?php endif;?></td>
						</tr>
						<tr>
							<th align="left">Delete:</th><td><a href="javascript:void(0);" onclick="delete_image(<?php echo $image->id?>, '../../../<?php echo image_url($image, 'thumb')?>');" style="cursor:pointer;">delete</a></td>
						</tr>
					</table>
				</td>
				<td width="200">
					<?php if($image->is_dirty) : ?>
					<strong style="color:red;">NOTE: </strong>This image is dirty and is ignored until it is marked as clean. <a href="javascript:void(0);" onclick="edit_image( <?php echo $image->id?> );">clean</a>
					<?php endif;?>
				</td>
			</tr>
		</table>		  
	</div>
	<?php endforeach; ?>
</div>
