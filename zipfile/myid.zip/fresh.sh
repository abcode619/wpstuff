Hello() {
   read -p "Enter your new Repo Name : " name
   git remote set-url origin ssh://root@repo:2222/var/git/$name.git
   echo " git remote origin url updates!"
   git remote -v
}

echo "Do you wish to change git remote url ?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) Hello; break;;
        No ) echo "Thank you Make up your mind first"; exit;;
    esac
done


