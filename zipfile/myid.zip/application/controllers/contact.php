<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Contact extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}

	function index() {

		if (isset($_POST['submit'])) {
			$this->data['post'] = $_POST;
			$this->data['success'] = $this->post($_POST);
		}

		$this->template->add_page('contact');
		$this->template->render($this->data);

	}

	private function post($data) {

		/* Add required form fields here */
		$mandatory = array('name', 'email', 'comments');

		$this->data['missing'] = array();

		foreach ($mandatory as $m)
			if (!isset($data[$m]) or empty($data[$m]))
				$this->data['missing'][] = $m;

		if (empty($this->data['missing'])) {
			$this->send_email($data);
			return true;
		}
		return false;
	}

	private function send_email($data) {

		$config = array(
			'protocol' => 'smtp',
			'mailtype' =>  'html',
			'smtp_host' => 'ssl://host.idnetwork6.com.au',
			'smtp_user' => 'mailserver@intensedesign.com.au',
			'smtp_pass' => 'Ma1l-s3rv3r',
			'smtp_port' => 465
		);
		$this->load->library('email',$config);

		$this->email->initialize(array('mailtype'=>'html','useragent'=>'[id] digital'));
		$this->email->from('noreply@intensedesign.com.au', SITE_NAME);
		$this->email->to(SITE_EMAIL);
		$this->email->subject('New Website enquiry');
		$this->email->message($this->load->view('email_templates/enquiry', array('data' => $data), true));
		$this->email->send();
	}
}
