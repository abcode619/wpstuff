<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Page_not_found extends MY_Controller {

	public function index()
	{
		$this->template->add_page('page_not_found');
		$this->template->render();
	}

}