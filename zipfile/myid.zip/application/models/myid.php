<?php

    class Myid extends MY_Model
    {

        function __construct()
        {
            parent::__construct();
        }

        /**
         * @return stdClass
         */
        function settings()
        {
            $res = $this->db->get('setting')->result();
            $data = new stdClass;
            foreach ($res as $row) {
                if (!isset($data->{$row->category})) {
                    $data->{$row->category} = new stdClass;
                }
                $data->{$row->category}->{preg_replace('![^A-Za-z0-9]+!', '_', strtolower($row->name))} = $row->value;
            }

            return $data;
        }
    }
