<?php

class Model extends CI_Model {
	
	function __construct()
	{
		parent::__construct();
	}

	function page($page)
	{
		return $this->db->get_where('page', array('title' => $page))->row()->content;
	}
        
      
}