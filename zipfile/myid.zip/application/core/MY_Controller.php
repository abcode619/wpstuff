<?php

	class MY_Controller extends MX_Controller
	{
		 
		   
		   
		public $post_data;
		public $settings;

		public function __construct()
		{
			parent::__construct();

			$this->load->library('pagination');// Loading the pagination
			$this->data = array();
			$this->load->library('session');
			$this->load->helper('form');
			$this->load->library('template');
			$this->template->set_template('template');
			$this->template->google_tracker_on(GOOGLE_TRACKER_ON);
			$this->template->set_google_key(GOOGLE_TRACKER_KEY);

			$this->template->meta['keywords']    = "";
			$this->template->meta['description'] = "";

			// Getting the config from Myid
			$this->load->model('myid');
			//$this->data['settings'] = $this->settings = $this->myid->settings();


			// Get the Post data
			$this->post_data = $this->input->post();

			if(!preg_match('!^m\.!', $_SERVER['HTTP_HOST']))
			{
				$mobile = $this->is_mobile();
				/* Necessary, because CodeIgniter swallows $_GET */
				parse_str(substr($_SERVER['REQUEST_URI'], strpos($_SERVER['REQUEST_URI'], '?') + 1,
								 strlen($_SERVER['REQUEST_URI']) - strpos($_SERVER['REQUEST_URI'], '?')), $_GET);
				if(isset($_GET['nomobile']))
				{
					/* User has a mobile, but does not want to use the mobile site. */
					$cookie = array('name'   => 'nomobile',
									'value'  => 1,
									'expire' => '865000',);
					set_cookie($cookie);
					$mobile = false;
				}

				if($mobile && !$this->input->cookie('nomobile'))
				{
					$host       = $_SERVER['HTTP_HOST'];
					$mobilehost = 'http://m.' . preg_replace('!^www\.!', '', $host);
					/* enable to activate auto-redirection */
					//              redirect($mobilehost);
				}
			}
                        
                        
                /* Top Right Menu Links */
		$this->data['site_nav_top_upper_menu'] = array(
			array (
				'title' => 'Home',
				'uri' => '/home',
				'class' => '',
				'active' => ''
			),
			array (
				'title' => 'Our Story',
				'uri' => '/our-story',				
				'class' => '',
				'active' => ''
			),
			array (
				'title' => 'Blog',
				'uri' => '/blog',				
				'class' => '',
				'active' => ''
			),
			array (
				'title' => 'FAQ',
				'uri' => '/faq',				
				'class' => '',
				'active' => ''
			),
			array (
				'title' => 'Contact Us',
				'uri' => '/contact-us',				
				'class' => '',
				'active' => ''
			)			
		);
                
                
                /* Top Right Menu Links */
		$this->data['site_nav_top_social_cart'] = array(
			array (
				'title' => '<i class="fa fa-facebook"></i> Like Us',
				'uri' => 'https://www.facebook.com/OrgoniumOrgone',
				'class' => 'facebook_link',                                
				'active' => '',
                                'target' => '_blank'
			),
			array (
				'title' => '<i class="fa fa-twitter"></i> Follow Us',
				'uri' => 'https://twitter.com/OrgoniumOrgone',				
				'class' => 'twitter_link',
				'active' => '',
                                'target' => '_blank'
			),
			array (
				'title' => '<i class="fa fa-shopping-cart"></i> My Cart (2 items)',
				'uri' => '/shop/cart',				
				'class' => 'cart_link',
				'active' => '/shop/cart',
                                'target' => ''
			)						
		);
                
                /* Primary Site Navigation Pages */
		$this->data['site_nav_primary_menu'] = array(
			array (
				'title' => 'Hot Deals',
				'uri' => '/hot-deals',
				'class' => '',
                                'li_class' => '',
				'active' => 'hot_deals'
			),
			array (
				'title' => 'Categories',
				'uri' => 'javascript:void(0);',
				'class' => '<i class="fa fa-chevron-down"></i>',
                                'li_class' => "class = 'parent'",
				'active' => 'categories'
			),
			array (
				'title' => 'Uses',
				'uri' => 'javascript:void(0);',
				'class' => '<i class="fa fa-chevron-down"></i>',
                                'li_class' => "class = 'parent'",
				'active' => 'uses'
			),
			array (
				'title' => 'How To Join',
				'uri' => 'how-to-join',
				'class' => '',
                                'li_class' => '',
				'active' => 'how_to_join'
			)
			
		);
                
                # Helper
                $this->load->helper('shop/jai'); // module helper costomer moudle
                # Model
                $this->load->model('shop/cart');
            
                // Load cart  items
                $this->data['view_cart'] = $this->cart->cart_check();
                if ($this->cart->cart_check()) 
                    {
                        $this->data['view_cart_count'] = $this->cart->cart_count();
                        $this->data['view_cart_total'] = $this->cart->get_cart_total_after_discount();
                    } 
                    
                // Fetching current credit of looged in user
                  
                    $user_id = $this->session->userdata('user_id');

                    if(!empty($user_id))
                    {                        
                        $this->load->model('my_account');                                
                        $this->data['current_credit'] = $this->my_account->getMyCurrentCredit($user_id);
                        
                        $this->session->set_userdata("current_credit", $this->data['current_credit']);
                        
                    }    
                        
		}

		//Function to  reinset the data  and set it up as flash data
		// so that when we use redirection to a from on bottom of page we can display form fields
		// Very specific usage
		function reinsert_data()
		{
			foreach($_POST as $key => $row)
			{
				$this->session->set_flashdata($key, $row);
			}
			foreach($_GET as $key => $row)
			{
				$this->session->set_flashdata($key, $row);
			}
		}

		/**
		 * @param $url
		 * @param $total_rows
		 * @param $items_per_pg
		 * @param $uri_segment
		 * @return int
		 */
		public function set_pagination_config($url, $total_rows, $items_per_pg, $uri_segment)
		{
			$this->load->library("pagination");

			$config['base_url']    = $url;
			$config['total_rows']  = $total_rows;
			$config['per_page']    = $items_per_pg;
			$config["uri_segment"] = $uri_segment;

			$config['full_tag_open']    = "<ul class='pagination'>";
			$config['full_tag_close']   = "</ul>";
			$config['num_tag_open']     = '<li>';
			$config['num_tag_close']    = '</li>';
			$config['cur_tag_open']     = "<li ><a  class='is-active' href='#'>";
			$config['cur_tag_close']    = "</a></li>";
			$config['next_tag_open']    = "<li>";
			$config['next_tagl_close']  = "</li>";
			$config['prev_tag_open']    = "<li>";
			$config['prev_tagl_close']  = "</li>";
			$config['first_tag_open']   = "<li>";
			$config['first_tagl_close'] = "</li>";
			$config['last_tag_open']    = "<li>";
			$config['last_tagl_close']  = "</li>";
			$this->pagination->initialize($config);

			$page = ($this->uri->segment($config["uri_segment"])) ? $this->uri->segment($config["uri_segment"]) : 0;

			Return $page;
		}

		/**
		 * This is used in almost all the forms
		 * @param $data
		 * @param $to_email
		 * @param $subject
		 * @return mixed - retrun false if data not givn
		 * Refere to debugging comments  for more information
		 */
		public function sendEmail($data, $to_email, $subject)
		{
			if(!empty($data) && !empty($to_email) && !empty($subject))
			{

				$this->load->library('email');
				$this->email->initialize(array('mailtype'  => 'html',
											   'useragent' => 'my[id]'));
				$this->email->from('noreply@intensedesign.com.au', $this->settings->website->name);
				$this->email->to($to_email);
				$this->email->subject($subject);
				$this->email->message($this->load->view('email_templates/new_enq', array('data'     => $data,
																						 'settings' => $this->settings),
														true));
				//$this->email->message($this->load->view('email_templates/enquiry', array('data' => $data, 'settings' => $this->settings), true));
				$r = $this->email->send();

				//dd($this->email->print_debugger()); /// uncomment this if debugging
				return $r;
			} else
			{
				// drequired data is not set
				dd($data, $to_email, $subject); // only for debugging
				return false;
			}
		}

		/**
		 * Decorative Patter
		 *  function :          - takes the data
		 *                      - associates data with table keys
		 *                      - converts honey port zmail to email
		 *                      - if newsletter signup exists - they call that funcion
		 *                      - pushes the data to respective table name
		 * @param $data
		 * @param $table_name
		 * @return array
		 */
		public function SaveFormData($data, $table_name, $table_keys)
		{
			// check if required data to insert is there in the data variable with table keys

			$error         = array(); //  for storing errors
			$filtered_data = array(); // for storing required data

			foreach($table_keys as $value)
			{
				if(!array_key_exists($value, $data))
				{
					$error[] = $value; // if not exist then an error is updated
				} else
				{
					$filtered_data[$value] = $data[$value];
				}
			}

			// only if errors are not there
			if(count($error) == 0)
			{
				//zmail to email
				if(array_key_exists('zmail', $filtered_data))
				{
					$filtered_data['email'] = $filtered_data['zmail'];
					unset($filtered_data['zmail']);
				}

				//sanatazize data only if exists
				if(array_key_exists('newsletter_signup', $data))
				{
					// IF form is being ticked   need newsleter sign up
					// TODO:  talk to mailchimp  here - get email from either zmail or email
					$filtered_data['newsletter_signup'] = 1;
				} else
				{
					$filtered_data['newsletter_signup'] = 0;
				}

				//Another Intresting way to call a model
				$model = new model();
				$r     = $model->save($filtered_data, $table_name);

				return $r; // return  True or false

			} else
			{
				return $error; // array

			}
		}

                
                
                
                
		///////////////////////// end New funcions ////////////////////////////////////////////////////////////////////////

		public function ssl()
		{
			if(ACTIVE_GROUP == 'live')
			{
				if(!@$_SERVER['HTTPS'])
				{
					header(sprintf('Location: https://%s/%s', $_SERVER['HTTP_HOST'], uri_string()));
				}
			}
		}

		public function non_ssl()
		{
			if(ACTIVE_GROUP == 'live')
			{
				if(@$_SERVER['HTTPS'])
				{
					$host = explode(':', $_SERVER['HTTP_HOST']);
					$host = $host[0];
					header(sprintf('Location: http://%s/%s', $host, uri_string()));
				}
			}
		}

		public function mailchimp_signup($email = false, $report = true)
		{

			if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$/i", $email))
			{
				echo ($report) ? '<p class="error">Invalid email address</p>' : '';
				exit;
			}
			$this->load->library('MCAPI', array('apikey' => APIKEY));

			if($this->mcapi->listSubscribe(LISTID, $email, '') === true)
			{
				echo $report ? "<p class='success'>Success! Check your email to confirm sign up.</p>" : '';
			} else
			{
				echo $report ? "<p class='error'>{$this->mcapi->errorMessage}</p>" : '';
			}
		}

		private function is_mobile()
		{
			/*
				From http://detectmobilebrowsers.com/
				Licence: Public Domain
				Version: 18 October 2012
			*/
			$useragent = $_SERVER['HTTP_USER_AGENT'];

			return (preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',
							   $useragent) || preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',
														 substr($useragent, 0, 4)));
		}
	}

	class Mobile_Controller extends MX_Controller
	{

		function __construct()
		{
			parent::__construct();

			$this->load->library('template');

			if(!isset($this->template))
			{
				$this->template = new Template();
			}
			$this->template->set_template('mobile/template');
			$this->template->google_tracker_on(GOOGLE_TRACKER_ON);
			$this->template->set_google_key(GOOGLE_TRACKER_KEY);

			$this->template->meta['keywords']    = '';
			$this->template->meta['description'] = '';
		}
	}


