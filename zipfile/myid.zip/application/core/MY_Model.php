<?php
/**
 *
 * User: jai id digital
 * Date: 6/30/2014
 * Time: 12:49 PM
 */
class MY_Model extends CI_Model {

	/**
	 * @var string
	 */
	public $_table_name = "";
	/**
	 * @var string
	 */
	public $_primary_key = "";
	/**
	 * @var string
	 */
	public $_order_by = "";
	/**
	 * @var array
	 */
	public $rules = array();

	public  $_active_col='';

	protected $debug= true;

    /**
     *
     */
    function __construct ()
    {
        parent::__construct();
        $this->load->library('session');
    }

    /**
     * @param $fields
     *
     * @return array
     */
    public function get_post_values($fields)
    {  $data = array();
        foreach($fields as $field) :
            $data[$field] = $this->input->post($field);
        endforeach;
        return $data;
    }


	public function apply_ordeby($key=NULL,$params ="ASC"){
		// can overwite the default order key
		if(empty($key))$key = $this->_order_by;

		if(!empty($key)){
			// applying order by
			$this->db->order_by($key,$params );

		}else{
			if($this->debug){
				throw new Exception(" order by was called by key value is empty",0);
			}
			return false;
		}

	}

	/**
	 * @param null $id
	 * @param bool $single
	 * @param bool $onlyactive
	 * @return bool
	 * @throws Exception
	 */
	public function get($id = null, $single = false,$onlyactive = false)
	{
		// for only active elements in the table
		// check if this is working
		if($onlyactive)
		{
			if(empty($this->_active_col))
			   {
			     if($this->debug){
			     throw new Exception(" Undefine active col name please make sure you define _active_col variable",0);
			     }
				   return false;
			   }else{
				$this->db->where($this->_active_col, 'Y');
			}
		}

		if (!is_null($id))
		{
			$this->db->where($this->_primary_key, $id);
			$method = 'row';
		} else if ($single)
		{
			$method = 'row';
		} else
		{
			$method = 'result';
		}

		$results =$this->db->get($this->_table_name)->$method();

		if($results){
			return $results;
		} else {

			$msg = $this->db->_error_message();
			$num = $this->db->_error_number();
			 //echo $msg;
			 //echo $num;
			// Do something with msg and num
			return NULL;
		}

	}

    /**
     * @param $where
     * @param bool $single
     *
     * @return mixed
     */
	public function get_by($where, $single = FALSE,$onlyactive = false)
    {
        $this->db->where($where);
        return $this->get(NULL, $single,$onlyactive);
    }

	/**
	 * @param $limit
	 * @param $start
	 * @param null $where
	 * @return mixed
	 */
	public function get_by_pagination($limit, $start, $where = null,$onlyactive = false)
	{
		$this->db->limit($limit, $start);
		if (!empty($where))
		{
			$this->db->where($where);
		}

		return $this->get(null, false,$onlyactive);
	}

	public function count ($active_only = false,$where=NULL)
	{

		if(empty($where) == false) $this->db->where($where);
		if($active_only) $this->db->where(array($this->_active_col=>'Y'));

		  $r =  $this->db->get ($this->_table_name)->result();
		return count($r);
		//dd($this->db->last_query());
	}

	/**
	 * @param null $where
	 * @param null $table_name
	 * @return mixed
	 */
	public function get_id_by_slug($where = NULL, $table_name = NULL){
        if(!empty($where)){
            $this->db->where($where);
            $t_name = (empty($table_name)? $this->_table_name : $table_name);
            return $this->db->get($t_name)->row();
        }
    }

    /// protected debug functions
	protected function check_fields_intilized()
	{
		// checking the values  if they are define or not
			if(empty($this->_table_name)){
				throw new ErrorException(' table  name is not intilized',0,10);
			}
	}

	// Saving the data array()
	public function save($data,$table_name = NULL,$id = NULL,$primary_key=false)
	{
			if(is_null($table_name)){ // if  null use default table name
				$table_name = $this->_table_name;
			}

		if(is_null($id)){
			// Inserting
			if($primary_key){
				if(isset($data[$primary_key]) )$data[$primary_key]=NULL;
			}else{
				if(isset($data[$this->_primary_key]) )$data[$this->_primary_key]=NULL;
			}
			$result = $this->db->insert($table_name,$data);
			 return  $result;
		}
		else {
			// Update
			$this->db->set($data);
			$this->db->where($this->_primary_key,$id);
			$this->db->update($table_name);

		}
	}
}