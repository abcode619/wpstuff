<?php
	/**
	 * Created by [id].
	 * User: JayKay
	 * Date: 3/11/2014
	 * Time: 10:24 AM
	 * FileName : MY_Composer.php
	 */
	require_once __DIR__ . '/../../vendor/imagine/imagine/lib' . '/imagine_autoload.php';

	use Imagine\Image\Box;
	use Imagine\Image\Point;
	use Imagine\Gd\Imagine;

	class Imagine_lib
	{
		var $ci;

		function __construct()
		{
			$this->ci =& get_instance();

			$this->ci->imagine = new Imagine();


		}

		public function testing($image_path,$image_save_path)
		{
			$image = $this->ci->imagine->open($image_path);
			$thumbnail = $image->thumbnail(new \Box(100, 100));
			$thumbnail->save($image_save_path);
		}

	}