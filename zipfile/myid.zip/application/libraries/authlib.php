<?php
/**
 * basic auth library
 *
 * to make use of this set the session variable: logged_in = true
 */
class Authlib {

	var $ci;

	public function __construct()
	{
		$this->ci =& get_instance();
	}
	
	/**
	 * create password hash
	 * @param  [type] $password [description]
	 * @return [type]           [description]
	 */
	public function hash($password)
	{
		return sha1($password.config_item('encryption_key'));
	}

	/**
	 * placed at the construct of a controller that requires
	 * a logged in user
	 * @param  boolean $location=false [description]
	 * @return [type]                  [description]
	 */
	public function authorized($location=false)
	{
		// if no session
		if (!$this->ci->session->userdata('logged_in')) {
			redirect('/?page=' . $location);
		}
	}

	/**
	 * used throughout to determine if the user is logged in
	 * @return [type] [description]
	 */
	public function logged_in()
	{
		return $this->ci->session->userdata('logged_in');
	}

	/**
	 * shortcut to session userdata
	 * @param  [type] $value [description]
	 * @return [type]        [description]
	 */
	public function session($value)
	{
		return $this->ci->session->userdata($value);
	}

	/**
	 * placed at the beginning of any ajax controller method
	 * @return [type] [description]
	 */
	public function authorized_ajax()
	{
		if (!$this->ci->session->userdata('logged_in'))
			return false;

		return true;
	}

	/**
	 * generate a random password, thanks tek
	 * @return [type] [description]
	 */
	public function generate_password()
	{		
		$action_word = array(
			'slim',
			'mega',
			'clean',
			'crazy',
			'angry',
			'silly',
			'funny',
			'big',
			'dizzy',
			'spicy',
			'small',
			'shiny',
		
		);
		
		$object_word = array(
			'chicken',
			'robot',
			'voice',
			'card',
			'bucket',
			'bird',
			'rocket',
			'chance',
			'fish',
			'car',
			'dish',
			'style',
		);
		
		$password = $action_word[mt_rand(0, count($action_word) - 1)];
		$password .= $object_word[mt_rand(0, count($object_word) - 1)];
		$password .= mt_rand(10,99);
		
		return $password;		
	}

}