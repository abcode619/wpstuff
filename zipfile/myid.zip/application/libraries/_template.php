<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/******************************************
				MezTek
******************************************/

class Template {

	var $ci;
	
	var $template_path = '';
	
	var $inner_template = '';
	
	var $pages = array();
	
	var $first_page = '';
	
	var $last_page = '';
	
	var $scripts = array();
	
	var $css = array();
	
	var $custom_css = array();
	
	var $custom_scripts = array();
	
	var $google_tracker = false;
	
	var $google_key = '';

	var $cache_dir = '/cache';
	
	private $cache_scripts = false;
	
	private $recorded_js = array();
	
	private $recorded_css = array();
	
	private $title_append = array();
	
	var $ignore_all = false; // for clean json output
	
	var $TITLE = '';
	
	function __construct() {
		$this->ci =& get_instance();
	}



	/* set path of template - not required if you dont wish to use a template */

	function set_template($path) {
		$this->template_path = $path;    
	}



	/* template within template */

	function set_inner($path) {
		$this->inner_template = $path;   
	}



	/* These views will get loaded in the order that this method is called */
	
	function add_page($path = '', $cache = false, $cache_length = 60) {

		if(is_array($path)) {             

			 foreach($path as $page) {

				$this->pages[] = array('path' => $page, 'cache' => $cache, 'cache_length' => $cache_length); 

			 }

		} else {

			 $this->pages[] = array('path' => $path, 'cache' => $cache, 'cache_length' => $cache_length);

		}

	}



	/* This view will get loaded before other views have been loaded */
	
	function add_first_page($path) {
		$this->first_page = $path;            
	}

	/* This view will get loaded after all other views have been loaded */

	function add_last_page($path) {
		$this->last_page = $path;             
	}

	/* add a javascript file into html head */

	function add_script($path = '') {

		if(is_array($path)) {

			foreach($path as $js) {

				if(!in_array($js, $this->scripts)) {

					$this->scripts[] = $js;
					
					if($this->cache_scripts) {
					
						$this->recorded_js[] = $js;
						
					}
					
				}

			}

		} else {

			if(!in_array($path, $this->scripts)) {

				$this->scripts[] = $path; 
				
				if($this->cache_scripts) {
				
					$this->recorded_js[] = $path;
					
				}

			}

		}
		
	}



	/* add a css file into html head */

	function add_css($path) {

		if(is_array($path)) {

			foreach($path as $css) {

				if(!in_array($css, $this->css)) {

					$this->css[] = $css;
					
					if($this->cache_scripts) {
					
						$this->recorded_css[] = $css;
						
					}
					
				}

			}

		} else {

			if(!in_array($path, $this->css)) {

				$this->css[] = $path;       
				
				if($this->cache_scripts) {
				
					$this->recorded_css[] = $css;
					
				}
				
			}

		}

	}



	/* returns html to include javascript files */

	function get_scripts() {
	
		$html = '';

		foreach($this->scripts as $script) {

			$html .= '<script type="text/javascript" src="' . $script . '"></script>' . "\n";

		}

		foreach($this->custom_scripts as $script) {

			$html .= $script . "\n";    

		}

		return $html;

	}



	/* returns html to include css */

	function get_css() {

		$html = '';

		foreach($this->css as $css) {

			$html .= '<link rel="stylesheet" type="text/css" href="' . $css . '" />' . "\n"; 

		}
		
		foreach($this->custom_css as $css) {
		
			$html .= $css . "\n";
		
		}

		return $html;

	}
	
	function output($str) {
		
		if(!$this->ignore_all) {
		
			$this->ci->output->set_output( $this->ci->output->get_output() . $str);
		
		} 
	
	}


	function render($data = array()) {


		if($this->ignore_all) {
			
			/* for clean json output */
			return false;
		
		}
		
		/* send $this into views so we can use the template functions in them $template instead of $this->template */

		$data['template'] = $this;

		$content = '';

		/* if first page is set then we load this view first */

		if($this->first_page != '') {

			$content .= $this->ci->load->view($this->first_page, $data, true);

		}

		/* load all views */

		foreach($this->pages as $page) {
			
			if($page['cache']) {
				
				$cached_file = $this->cache_dir . md5($page['path']) . '.txt';
				if( file_exists( $cached_file ) ) {
					
					if( filemtime($cached_file) + ($page['cache_length'] * 60) <  time()) {
											
						// start caching js and css
						$this->_start_record_scripts();
							
						$page_content = $this->ci->load->view($page['path'], $data, true);    
						
						// stop caching js and css
						$this->_stop_record_scripts();
						
						$scripts = $this->recorded_scripts();
						
						$content .= $page_content;
						
						file_put_contents($cached_file, $page_content);
						
					
					} else {
						
						$content .= file_get_contents($cached_file);
					
					}
						
				} else {
				
					// start caching js and css
					$this->_start_record_scripts();
					
					$page_content = $this->ci->load->view($page['path'], $data, true);    
					
					// stop caching js and css
					$this->_stop_record_scripts();
						
					$content .= $page_content;
						
					file_put_contents($cached_file, $page_content);
					
					
				
				}
				
			} else {
			
				$content.= $this->ci->load->view($page['path'], $data, true);    
			
			}
			
			  

		}

		/* if last page is set then we load this view last */

		if($this->last_page != '') {

			$content .= $this->ci->load->view($this->last_page, $data, true); 

		}

		$data['content'] = $content;

		/* template within template */

		if($this->inner_template != '') {
			
			$data['content'] = $this->ci->load->view($this->inner_template, $data, true);

		}

		if($this->template_path != '') {

			/* load the template view and pass the html of all the other views */
			
			$find = array('-', '_');
			
			$this->TITLE = SITE_TITLE;
			
			if(count($this->title_append) > 0) {
				
				foreach($this->title_append as $title) {
					
					$this->TITLE .= ' :: ' . $title;
					
				}
			
			} else {
			
				$this->TITLE .= ' :: ' . ucwords(strtolower(str_replace($find, ' ', $this->ci->router->class)));
				
			}
			
			$this->ci->load->view($this->template_path, $data);

		} else {

			$this->ci->output->set_output( $this->ci->output->get_output() . $data['content']);

		}

	}

	private function _start_record_scripts() {
		
		$this->recorded_js = array();
		$this->recorded_css = array();
		$this->cache_scripts = true;
		
	}
	
	private function _stop_record_scripts() {
		
		$this->cache_scripts = false;
	
	}


	/* starts buffer to insert custom scripts into head of html - scripts must have opening <script> tag */
	
	function start_script()  {
		
		 ob_start();     
		      
	}
	
	/* reads buffer to insert custom scripts into head of html - scripts must have closing </script> tag */
	
	function stop_script() {
	
		$this->custom_scripts[] = ob_get_clean();
	
	}
	
	function start_css() {
	
		ob_start();
		
	}	
	
	function stop_css() {
		
		$this->custom_css[] = ob_get_clean();
	
	}
	
	function JSON($response) {
		
		$this->ci->output->set_output( json_encode($response) );
		
		$this->ignore_all = true;
		
	}
	
	function google_tracker_on( $bool ) {
	
		$this->google_tracker = $bool;	
		
	}
	
	function set_google_key($google_key) {
	
		$this->google_key = $google_key;
	
	}
	
	function append_title($str) {
		
		$this->title_append[] = $str;
	
	}
	
	function google_tracker() {
		
		if($this->google_tracker) {
			if($this->google_key != '') {
				return "<script type=\"text/javascript\">
						  var _gaq = _gaq || [];
						  _gaq.push(['_setAccount', '" . $this->google_key . "']);
						  _gaq.push(['_trackPageview']);
						 
						  (function() {
							var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
							ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
							var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
						  })();
						</script>";
			} else {
				return "<h1>Google Key Not Provided</h1>\n";
			}
		}
	}
	
}
