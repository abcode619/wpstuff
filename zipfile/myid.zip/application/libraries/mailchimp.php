<?php
/**
 * Requires constants MAILCHIMP_APIKEY and MAILCHIMP_LISTID
 */
class Mailchimp {

	public function __construct()
	{
		$this->ci =& get_instance();
		$this->ci->load->helper('email');
	}
	
	public function signup($email=false, $report=true)
	{
		if ( ! valid_email($email)) {
		// if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*$/i", $email)) {
			return ($report)?'<p class="error">Invalid email address</p>':'';
		}

		$this->ci->load->library('MCAPI', array('apikey' => MAILCHIMP_APIKEY));
		// print_r($this->ci->mcapi->listMergeVars(MAILCHIMP_LISTID));//check required arguments

		if($this->ci->mcapi->listSubscribe(MAILCHIMP_LISTID, $email, '') === true) {
			return ($report)?'<p class="success">Success! Check your email to confirm sign up.</p>':'';
		} else {
			return ($report)?'<p class="error">'.$this->ci->mcapi->errorMessage.'</p>':'';
		}
	}

}