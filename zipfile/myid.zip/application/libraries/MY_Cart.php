<?php
class MY_Cart extends CI_Cart {
    function __construct() {
        parent::__construct();
        // Adding commas, quotes and parenthesis to product names
        $this->product_name_rules = '\,\(\)\"\'\.\:\-_ a-z0-9\/&';
    }

    function update_all($items = array()){
		
		if ( ! is_array($items) OR count($items) == 0)// Was any cart data passed?
		{
			return false;
		}
		
		// You can either update a single product using a one-dimensional array, 
		// or multiple products using a multi-dimensional one.  
		// The way we determine the array type is by looking for a required array key named "rowid".
		// If it's not found we assume it's a multi-dimensional array	
		if (isset($items['rowid'])){	
			$this->_update_item($items);
		}else{
			foreach($items as $item){
				$this->_update_item($item);
			}
		}
		$this->_save_cart();
	}
	
	/*
	 * Function: _update_item
	 * Param: Array with a rowid and information about the item to be updated
	 * 			such as qty, name, price, custom fields. 
	 */
	function _update_item($item){

		foreach($item as $key => $value){
			
			if($key == 'rowid'){//don't allow them to change the rowid
				continue;
			}
			
			//do some processing if qty is updated since it has strict requirements
			if($key == "qty"){					
				$item['qty'] = preg_replace('/([^0-9])/i', '', $item['qty']);
				if (!is_numeric($item['qty'])){
					continue;
				}
				// Is the new quantity different than what is already saved in the cart?
				if ($this->_cart_contents[$item['rowid']]['qty'] == $item['qty']){
					continue;
				}
				// Is the quantity zero?  If so we will remove the item from the cart.
				if ($item['qty'] == 0){
					unset($this->_cart_contents[$item['rowid']]);
					continue;
				}
			}
			$this->_cart_contents[$item['rowid']][$key] = $value;
		}
	}

	//is this product in the cart?
	public function in_cart($product_id = null) {
	    if ($this->total_items() > 0){
	        $in_cart = array();
	        // Fetch data for all products in cart
	        foreach ($this->contents() AS $item){
	            $in_cart[$item['id']] = $item['qty'];
	        }
	        if ($product_id){
	            if (array_key_exists($product_id, $in_cart)){
	                return $in_cart[$product_id];
	            }
	            return null;
	        }else{
	            return $in_cart;
	        }
	    }
	    return null;    
	}

	//count all items including multiples of each product
	public function all_item_count(){
	    $total = 0;
	    if ($this->total_items() > 0){
	        foreach ($this->contents() AS $item){
	            $total = $item['qty'] + $total;
	        }
	    }
	    return $total;
	}
} 