<?php
	/**
	 * Created by [id].
	 * User: JayKay
	 * Date: 3/11/2014
	 * Time: 10:24 AM
	 * FileName : MY_Composer.php
	 */

	class MY_Composer
	{
		function __construct()
		{
			include("vendor/autoload.php");
		}

	}