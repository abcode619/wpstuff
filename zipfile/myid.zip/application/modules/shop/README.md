CONTENTS OF THIS FILE
---------------------
 * Introduction
 * Requirements
 * Installation
 * Configuration
 * TODO list
 * Troubleshooting - need to do this
 * FAQ  - need  to do this
 * Maintainers  - need to do this


INTRODUCTION
------------
The self contained ajax cart is developed to give out the basic features fo the car t strictly on CI HMVC format .
 * This CART HMVC runs with minimum ci dependencies.
 *


REQUIREMENTS
------------
This module requires the following :
 *  coupled with base CI of ID digital.




INSTALLATION
------------
 * You have to install sql database dump  from  shop/core/sqldb/ folder
 * Make sure in application/config/constants.php   constant PAYMENT_MODE is define to testing or live
 * Model in shop extend  core/MY_Model.php  by default ( you can use MY_CONTROLLER if you want )  just following the best practice
 * create a folder called modules in application folder ; application/modules/
 * Copy  folder shop in to modules dir ; application/modules/shop
 * edit htaccess to allow urs to access shop assests folder  .htaccess (root level)

 		#####CODE########

	 		Options +FollowSymlinks
	 		RewriteEngine on

			RewriteCond $1 !^(index\.php|assets|uploads|tt|application/modules/.*/assets|resources|robots\.txt|favicon\.ico)
			RewriteRule ^(.*)$ /index.php/$1 [L]

		#####CODE########
		 * important  giving access to application /modules/{whatever folder name}/assests }

* edit htaccess in application level (appliction/.htaccess) by default it contains deny all

		#####CODE ########

			#Deny from all

			Options +FollowSymlinks
			RewriteEngine on

			RewriteCond $1 !^(modules/.*/assets)
			RewriteRule ^(.*)$ /index.php/$1 [L]

		###CODE#####


 * As the ci cart libiary is updated at code level  you have to copy cart into root/system/lilraries/cart.php  NOTE: if you already have a cart.php file in the folder rename it to cart_bk.php  and copy cart.php from shop/root/lib/cart.php

 * EDIT application/config/autoload.php   end of the file add following :

		###CODE####

			$autoload['model'] = array('model');

			$config['modules_locations'] = array(APPPATH . 'modules/' => '../modules/',);


		###CODE####



CONFIGURATION
-------------
The module has no menu or modifiable settings.  There is
configuration in shop/config/shop_config.php - make sure you have necessay chnages.

TODO LIST
-------------
*  if you are using phpstrome editor :  search for "TODO :"
