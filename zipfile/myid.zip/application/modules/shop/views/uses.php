<div class="mid_content">      
    <div class="col-md-9 mid_right">
        <h1 class="withborder">Uses: <span class="green_text"><?php echo $use->name; ?></span></h1>      
        <div class="right_sorting" style="display: none;">
            <label>Sort by</label> 
            <select name="sort" class="selectpicker" id="sort_by">
                <option value="lowest" <?php echo ($_POST['sort_by'] == 'lowest') ? 'selected="selected"': ''; ?>>Price: Lowest to Highest</option>
                <option value="highest" <?php echo ($_POST['sort_by'] == 'highest') ? 'selected="selected"': ''; ?>>Price: Highest to Lowest</option>
            </select>
        </div>  

        <div class="col-md-8 padil0">
            <h6 class="paditop0"><?php echo $use->description; ?></h6> 
            <!--<p>These highly protective Orgone Pendants resonate both Orgone Energy and Schumann Frequencies, making it the ultimate in energy jewellery.</p>-->
        </div>
        <div class="col-md-4 padir0">
            <img src="<?php echo tt($use->image, 270, 180); ?>" alt="" class="img-responsive2" />
        </div>

        <br class="clear">

       <?php $this->load->view('/components/products/products'); ?>

    </div>
    <!--mid_right end--> 
    <div class="col-md-3 sidebar">
        <?php $this->load->view('widgets/home_top_left_content.php',array('banners'=>"")); ?>
        
        <?php $this->load->view('widgets/left_categories.php',array('categories'=>$product_categories)); ?>
        
        <?php $this->load->view('widgets/left_uses.php',array('uses'=>$product_uses)); ?>
        
        <?php $this->load->view('widgets/home_worldwide.php',array('banners'=>"")); ?>
    </div>
    <!--sidebar end-->
</div>
<!--mid content end-->
<script type="text/javascript">  
$(document).ready(function(){
     $('#sort_by').change(function(){
         $('<form action="/shop/uses/<?php echo $use->slug; ?>" method="post"><input type="hidden" name="sort_by" value="' + $(this).val() + '" /></form>').appendTo('body').submit();
     }); 
 }); 
        // $( ".mid_content .col-md-9 .paditopbto15:nth-child(3n+2)" ).css( "clear", "right" );
        // $( ".mid_content .col-md-9 .paditopbto15:nth-child(3n+3)" ).css( "clear", "left" );
</script>