<div class="">
	<!-- area -->
	<div class="">
		<ul class="">
		   <?php $this->load->view('/components/products/products'); ?>
		</ul>
		<?php $this->load->view ('/components/pagination/pagination') ?>
	</div>

	<!-- area -->
	<div class="template-duo__aside">
		<ul class="list-of-items">
			<!--<li>-->
				<!-- News Categories -->
				<?php // $this->load->view ('./widgets/sidebar/sidebar--link-list', array ('sidebar_links__title' => $category__title, 'sidebar_links'        => $category__nav_list,)) ?>
			<!--<li>-->
				<!-- Menue -->
				<?php // $this->load->view ('./widgets/sidebar/sidebar--link-list', array ('sidebar_links__title' => $brands__title, 'sidebar_links'        => $brands__nav_list,)) ?>
			<li>
				<!-- viewcart  Moved to cart HM-->
				<?php if($view_cart) : ?>
				<?php $this->load->view ('/components/shoutbox/shoutbox--viewcart'); ?>
				<?php endif; ?>
			<!--<li>-->
				<!-- shoutbox -->
				<?php // $this->load->view ('./widgets/shoutbox/shoutbox--swimschool'); ?>
			<!--<li>-->
				<!-- shoutbox -->
				<?php // $this->load->view ('./widgets/shoutbox/shoutbox--membership'); ?>
			<!--<li>-->
				<!-- shoutbox -->
				<?php // $this->load->view ('./widgets/shoutbox/shoutbox--newsletter-sign-up'); ?>
		</ul>
	</div>
</div>