<br />
<h1>Added to cart</h1>
<br />

Next steps: <br />
[<a href='/<?= $base_name ?>/'>Store overview</a>]
[<a href='/<?= $base_name ?>/cart/'>My Cart</a>]
[<a href='/<?= $base_name ?>/checkout/'>Go to Checkout</a>]

