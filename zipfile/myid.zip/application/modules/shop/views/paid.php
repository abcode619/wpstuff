
<h1>Thank you for your order.</h1>

<p>
	Your payment has been processed. You will receive a confirmation email shortly.
</p>
