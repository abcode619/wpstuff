<script>
$(document).ready(function() {
	$("li.same_as_billing input").click(function(){
		$('#shipping_details').toggle('slow');//hide/show shipping details
	});
});
</script>
<?php if (isset($errors) and !empty($errors)):?>
	<div class='error'>
		<?php foreach ($errors as $error): ?>
			<?= $error ?>
		<?php endforeach; ?>
	</div>
	<br />
<?php endif; ?>

<div class="checkout--section">
	<div class="columns small-12">
		<h1>Checkout</h1>
	</div>
</div>

<?php if($cart):?>
<div class="checkout--section">
	<div class="columns small-12">
		<h2>1. Products</h2>
		<table class="cart-products-list">
			<!-- Cart header -->
			<thead class="cart-head">
				<tr>
					<td>
						Details
					</td>
					<td>
						Qty
					</td>
					<td>
						Price
					</td>
					<td>
						Total
					</td>
				</tr>
			</thead>
			<!-- Item list -->
			<tbody class="cart-body">
				<?php foreach ($cart as $id => $item):?>
				<!-- Item -->
				<tr class="cart-item">
					<!-- Item details -->
					<td class="cart-item--td-details">
						<a class="cart-item--title" href='/<?= $base_name ?>/product/<?=$item['product_id'] ?>'><?= $item['name']?></a>
						<p><?=$item['short_description'] ?></p>
						<table>
							<tr>
								<td>
									<span class="cart-item--desc">
									</span>
								</td>
								<td>
									<span class="cart-item--desc">
										<?= $item['size_name'] ?>
									</span>
								</td>
							</tr>
						</table>
					</td>
					<!-- Item Quantity -->
					<td class="cart-item--td-qty">
						<?= $item['qty'] ?>
					</td>
					<!-- Item Price -->
					<td>
						<span class="cart-item--price">
							<?=sprintf('%.2f', $item['price'])?>
						</span>
					</td>
					<!-- Item Total -->
					<td>
						<span class="cart-item--total"></span>
							<?=sprintf('%.2f', $item['qty']*$item['price'])?>
						</span>
					</td>
				</tr>
				<!-- Use this to create spacing between items -->
				<tr class="cart-item--separator">
					<td colspan="1"></td>
				</tr>
				<?php endforeach;?>
			</tbody>
		</table>
	</div>
</div>

<?= form_open($base_name.'/pay/') ?>
<input type='hidden' name='total' value='<?= $total ?>' />
<input type='hidden' name='shipping' value='<?= $shipping ?>' />

<div class="checkout--section">
	<div class="columns small-12">
		<h2>2. Billing &amp; Shipping Address</h2>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2">
		<!-- Information -->
		<div class="checkout--information">
			<h2>Please enter your billing address below</h2>
			<ul class="billing-and-shipping">
				<?php foreach ($fields->billing as $field): ?>
				<!-- Element row -->
				<li class="<?=$field['container']['class']?>">
					<?php if (isset($field['title'])): ?>
						<?= form_label($field['title'],$field['html']['name'],$field['label_html'])?>
					<?php endif; ?>
					<?php if ($field['type'] == 'select'): ?>
						<?= form_dropdown($field['html']['name'], $field['values']) ?>
					<?php elseif ($field['type'] == 'checkbox'): ?>
						<?= form_checkbox($field['html']['name'], $field['value']) ?>
					<?php elseif ($field['type'] == 'textarea'): ?>
						<?= form_textarea($field['html']) ?>
					<?php else: ?>
						<?= form_input($field['html']) ?>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
				<li class="same_as_billing">
					<label><input type="checkbox" name="same_as_billing" />My Shipping address is the same as my Billing Address</label>
				</li>
			</ul>
		</div>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2" id="shipping_details">
		<!-- Information -->
		<div class="checkout--information">
			<h2>Please enter your shipping address below</h2>
			<ul class="billing-and-shipping">
				<?php foreach ($fields->contact as $field): ?>
				<!-- Element row -->
				<li class="<?=$field['container']['class']?>">
					<?php if (isset($field['title'])): ?>
						<?= form_label($field['title'],$field['html']['name'],$field['label_html'])?>
					<?php endif; ?>
					<?php if ($field['type'] == 'select'): ?>
						<?= form_dropdown($field['html']['name'], $field['values']) ?>
					<?php elseif ($field['type'] == 'checkbox'): ?>
						<?= form_checkbox($field['html']['name'], $field['value']) ?>
					<?php elseif ($field['type'] == 'textarea'): ?>
						<?= form_textarea($field['html']) ?>
					<?php else: ?>
						<?= form_input($field['html']) ?>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</div>

<div class="checkout--section">
	<div class="columns small-12">
		<h2>3. Shipping Options</h2>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2">
		<div class="checkout--information">
			<h2>Optional Information area</h2>
			<p class="cart-item--desc"><?=lorem()?></p>
		</div>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2">
		<!-- Shipping Options -->
		<div class="checkout--module">
			<h2>Shipping Options</h2>

			<h4>Select your shipping method:</h4>
			<div class="row">
				<div class="columns small-12">
					<label><input type="radio" name="shipping" value="10" checked="checked">$10.00 - Shipping Method one</label>
					<label><input type="radio" name="shipping" value="15">$15.00 - Shipping Method two</label>
				</div>
		 	</div>
		</div>
	</div>
</div>


<div class="checkout--section">
	<div class="columns small-12">
		<h2>5. Payment Details</h2>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2">
		<div class="checkout--information">
			<h2>Optional Information area</h2>
			<p class="cart-item--desc"><?=lorem()?></p>
		</div>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-2">
		<!-- Shipping Options -->
		<div class="checkout--module">
			<h2>Payment</h2>
			<ul class="payment">
				<?php foreach ($fields->credit_card as $field): ?>
				<!-- Element row -->
				<li class="<?=$field['container']['class']?>">
					<?php if (isset($field['title'])): ?>
						<?= form_label($field['title'],$field['html']['name'],$field['label_html'])?>
					<?php endif; ?>
					<?php if ($field['type'] == 'select'): ?>
						<?= form_dropdown($field['html']['name'], $field['values']) ?>
					<?php elseif ($field['type'] == 'checkbox'): ?>
						<?= form_checkbox($field['html']['name'], $field['value']) ?>
					<?php elseif ($field['type'] == 'textarea'): ?>
						<?= form_textarea($field['html']) ?>
					<?php else: ?>
						<?= form_input($field['html']) ?>
					<?php endif; ?>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</div>
</div>

<div class="checkout--section">
	<div class="columns small-12">
		<h2>Order Summary</h2>
	</div>
	<!-- column -->
	<div class="columns sm-1-2 md-1-3">
		<div class="checkout--information">
			<h2>Billing Information</h2>
			<p class="cart-item--desc"><?=lorem()?></p>
		</div>
	</div>
	<!-- column -->
	<div class="columns sm-1-2 md-1-3">
		<div class="checkout--information">
			<h2>Shipping Address</h2>
			<p class="cart-item--desc"><?=lorem()?></p>
		</div>
	</div>
	<!-- column -->
	<div class="columns sm-1-1 md-1-3">
		<div class="checkout--summary">
			<h2>Order Details</h2>
			<table>
				<!-- Subtotal amount -->
				<tr>
					<td>
						<p class="cart-item--misc">Subtotal:</p>
					</td>
					<td>
						<p class="cart-item--misc">
							$<?=sprintf('%.2f', $total) ?>
						</p>
					</td>
				</tr>
				<!-- Coupons -->
				<?php if($coupon_value): ?>
				<tr>
					<td>
						<p class="cart-item--misc">
							Coupon:
						</p>
					</td>
					<td>
						<p class="cart-item--misc">
							$<?= sprintf('%.2f', $coupon_value)?>
						</p>
					</td>
				</tr>
				<?php endif;?>
				<!-- Total cost -->
				<tr>
					<td>
						<p class="cart-item--misc">
							<strong>Total:</strong>
						</p>
					</td>
					<td>
						<p class="cart-item--misc">
							<strong>$<?= sprintf('%.2f', $total - $coupon_value) ?></strong>
						</p>
					</td>
				</tr>
			</table>
			<div class="row">
				<div class="columns sm-1-3">
					<a class="btn btn-default btn-block input-sm"  href='/<?=$base_name ?>/cart/'>Back to Cart</a>
				</div>
				<div class="columns sm-2-3">
					<input type='submit' value='Process Transation' class="btn btn-primary btn-block input-sm"/>
				</div>
			</div>
		</div>
	</div>
</div>

<?= form_close(); ?>

<?php else: ?>

<div class="checkout--section">
	<div class="columns small-12">
		<br />
		<h2>Your Cart is empty</h2>
		<p><a href="<?= site_url('/'.$base_name)?>">> Continue Shopping</a></p>
	</div>
</div>

<?php endif; ?>