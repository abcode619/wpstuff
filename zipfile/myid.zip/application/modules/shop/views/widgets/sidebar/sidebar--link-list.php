<?php if(isset($sidebar_links)) : ?>
        <h4><?php echo $sidebar_links__title; ?></h4>
	<ul class="safe_list">		
		<?php foreach ($sidebar_links as $i) : ?>
		<li>
                        <a class="w-sidebar--link-list__link" target="_blank" href="<?php echo $i['uri']; ?>">
				<?php if (isset($i['title'])) : ?>
				<?php echo $i['title']; ?>
				<?php endif ?>
				<?php if (isset($i['extra'])) : ?>
				<?php echo $i['extra']; ?>
				<?php endif ?>
			</a>
		<?php endforeach ?>
	</ul>

<?php endif ?>