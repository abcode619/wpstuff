<?php
$prices = $product->prices;
?>
<div id="" class=""> 
    <h2 id="">Add Product to cart</h2>
    <div class="">
        <img src="<?php echo tt($product->image, 150, 150); ?>" alt="" class="">
    </div>

    <div class="">
        <h3><?php echo $product->name; ?></h3>
        <p>Categories: 
            <?php
            if (!empty($related_categories)) {
                $comma_count_cat = count($related_categories);
                foreach ($related_categories as $key => $value) {
                    ?>
                    <a href="/shop/category/<?php echo $value['slug']; ?>" class="text_undeline"><?php echo $value['name']; ?></a>
                    <?php if ($comma_count_cat != "1") echo ", "; ?> 
                    <?php
                    $comma_count_cat--;
                }
            } else {
                echo "No related categories found!";
            }
            ?>
        </p>
        <p>Uses: 
            <?php
            if (!empty($related_uses)) {
                $comma_count_uses = count($related_uses);
                foreach ($related_uses as $key => $value) {
                    ?>
                    <a href="/shop/uses/<?php echo $value['slug']; ?>" class="text_undeline"><?php echo $value['name']; ?></a> 
                    <?php if ($comma_count_uses != "1") echo ", "; ?> 
                    <?php
                    $comma_count_uses--;
                }
            } else {
                echo "No related Uses found!";
            }
            ?>  
        </p>
        <span class="" style="display: none;">

            <?php
            $date11 = strtotime($product->sale_end);
            $date22 = time();
            $subTime = $date11 - $date22;
            $y = ($subTime / (60 * 60 * 24 * 365));
            $d = ($subTime / (60 * 60 * 24)) % 365;
            $h = ($subTime / (60 * 60)) % 24;
            $m = ($subTime / 60) % 60;
            ?>

            <?php
            foreach ($product->prices as $key => $value) {
                if ($value->store_price_id == $product_price_id) {
                    if ($this->session->userdata("site_currency") == "aud") {
                        if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $value->sale_price > 0) {
                            echo "$" . $value->sale_price . " AUD";
                        } else {
                            echo "$" . $value->price . " AUD";
                        }
                    } else {
                        if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $value->sale_price_usd > 0) {
                            echo "$" . $value->sale_price_usd . " USD";
                        } else {
                            echo "$" . $value->price_usd . " USD";
                        }
                    }
                } else {
                    continue;
                }
            }
            ?>
        </span>

        <select name='size' id="change_quantity" class="">
            <?php
            $price_id = "";
            foreach ($prices as $price) :
                ?>
                <option value="<?php echo $price->store_price_id; ?>" 
                <?php
                if ($product_price_id == $price->store_price_id) {
                    echo "selected";
                    $price_id = $price->store_price_id;
                }
                ?> 
                        >                                
                <?php
                if ($this->session->userdata("site_currency") == "aud") {
                    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product->min_sale_price > 0) {
                        echo $price->price_name;
                        ?> - <?php
            echo '$' . $price->sale_price . " AUD";
        } else {
            echo $price->price_name;
                        ?> - <?php
                            echo '$' . $price->price . " AUD";
                        }
                    } else {
                        if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product->min_sale_price_usd > 0) {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->sale_price_usd . " USD";
                        } else {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->price_usd . " USD";
                        }
                    }
                    ?>
                </option>
<?php endforeach; ?>
        </select>

        <select name='size' id="select_quantity" class="quntity_select">
            <?php
            for ($i = 1; $i <= 10; $i++) {
                if ($product_qty == $i) {
                    $select = "selected";
                } else {
                    $select = "";
                }
                echo '<option value="' . $i . '" ' . $select . '>' . $i . '</option>';
            }
            ?>                        
        </select>  

        <span class="" style="display: none;"> Qty: 1</span> 

        <?php
        if (empty($price_id)) {
            $price_id = $prices[0]->store_price_id;
        }
        ?>

        <input type="button" id="add_to_cart_btn" class="AddtoCart_btn popAddtoCart_btn" value="Add to Cart" onclick="addToCartItem(<?php echo $product->store_product_id; ?>,<?php echo $price_id; ?>)" />
        <br class="clear"><br class="clear">
        <a href="javascript:void(0);" class="AddtoCart_btn" id="keep_shopping_btn" onClick="window.location.reload();
                return false;" style="display: none;" >Keep Shopping</a>                     
        <input type="button" class="ViewCart_btn" value="View Cart" id="view_cart_btn" onclick="location.href = '/shop/cart';" style="display: none;">
    </div>
</div>

<!--addtocart_popup end-->

<script type="text/javascript">
    jQuery(document).on("change", "#change_quantity", function() {
        var prd_id = <?php echo $product->store_product_id; ?>;
        var price_id = $(".quntity_select").val();
        $("#add_to_cart_btn").attr("onclick", "addToCartItem(" + prd_id + "," + price_id + ")");
    });
</script>