
<? if (isset($inc_membership)) : ?>
	<? if (!empty($inc_membership->image)): ?>
		<a class="shoutbox shoutbox--membership" href="<?= $inc_membership->url ?>" style="background-image: url('<?= SITE_URL (($inc_membership->image)) ?>')" >
	<? else: ?>
		<a class="shoutbox shoutbox--membership" href="<?= $inc_membership->url ?>" >
	<? endif; ?>
	<div class="shoutbox__wrap">
		<span class="shoutbox__title"><?= ucfirst ($inc_membership->name) ?></span>
		<span class="shoutbox__text"><?= $inc_membership->extract ?></span>
	</div>
	</a>
<? endif; ?>