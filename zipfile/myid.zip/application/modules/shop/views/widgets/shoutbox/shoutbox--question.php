<div class="shoutbox shoutbox--secondary eq-blocks" >
	<div class="shoutbox__wrap">
		<i class="icon-pencil"></i>
		<span class="shoutbox__title">If you have a question, drop us a line</span>
		<a href="/contact-us" class="btn"><span>Click here</span></a>
	</div>
</div>
</li>
<li>
<div class="shoutbox shoutbox--secondary eq-blocks" >
	<div class="shoutbox__wrap">
		<i class="icon-pencil"></i>
		<span class="shoutbox__title">Provide your feedback so we can improve!</span>
		<a href="/feedback" class="btn"><span>Click here</span></a>
	</div>
</div>