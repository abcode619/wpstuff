<? if(isset($value)) :?>
<? if(!empty($value->image)):?>
<a class="shoutbox shoutbox--swimschool" href="<?= $value->url ?>" style="background-image: url('<?=SITE_URL(($value->image))?>')" >
<? else: ?>
<a class="shoutbox shoutbox--swimschool" href="<?= $value->url ?>" >
<? endif; ?>
	<div class="shoutbox__wrap">
		<span class="shoutbox__title"><?= ucfirst($value->name) ?></span>
		<span class="shoutbox__text"><?=$value->extract?></span>
	</div>
</a>
<? endif; ?>