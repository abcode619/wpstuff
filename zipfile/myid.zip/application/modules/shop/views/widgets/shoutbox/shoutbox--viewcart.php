<a class="shoutbox shoutbox--viewcart eq-blocks" href="/my_cart">
	<div class="shoutbox__wrap">		
		<span class="shoutbox__title">View Cart </span><i class="icon-cart"></i>
		<span class="shoutbox__text">2 Items $49.95</span>
	</div>
</a>