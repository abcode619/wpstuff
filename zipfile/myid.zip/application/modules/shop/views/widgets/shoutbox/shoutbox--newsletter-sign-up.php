<div class="shoutbox shoutbox--primary eq-blocks" href="#">
	<div class="shoutbox__wrap">
		<i class="icon-envelope"></i>
		<span class="shoutbox__title">FREE PARC Newsletter</span>
		<!-- Email Form -->
		<form class="pure-form pure-form-stacked" action="http://broadcast.iddigital.com.au/t/y/s/qodyk/" method="post">
			<div class="pure-g">
				<!-- group -->
				<div class="pure-u pure-u-1  ui-pr0 ui-mb1">
					<input id="fieldName" placeholder="Your Name" name="cm-name" type="text" required />
				</div>
				<!-- group -->
				<div class="pure-u pure-u-1  ui-pr0 ui-mb1">
					<input id="fieldEmail" placeholder="Your Email Address" name="cm-qodyk-qodyk" type="email" required />
				</div>
				<!-- group -->
				<div class="pure-u ui-pr0">
					<button type="submit" class="btn"><span>Sign up</span></button>
				</div>
			</div>
		</form>
	</div>
</div>
</li>
<li>
	<?php $i=0; if($i==1) : ?>
<div class="shoutbox shoutbox--primary eq-blocks" href="#">
	<div class="shoutbox__wrap">
		<i class="icon-envelope"></i>
		<span class="shoutbox__title">Free PARC Swim School Newsletter</span>
		<!-- Email Form -->
		<form class="pure-form pure-form-stacked" action="http://broadcast.iddigital.com.au/t/y/s/qduol/" method="post">
			<div class="pure-g">
				<!-- group -->
				<div class="pure-u pure-u-1  ui-pr0 ui-mb1">
					<input id="fieldName" placeholder="Your Name" name="cm-name" type="text" required />
				</div>
				<!-- group -->
				<div class="pure-u pure-u-1  ui-pr0 ui-mb1">
					<input id="fieldEmail" placeholder="Your Email Address" name="cm-qduol-qduol" type="email" required />
				</div>
				<!-- group -->
				<div class="pure-u ui-pr0">
					<button type="submit" class="btn"><span>Sign up</span></button>
				</div>
			</div>
		</form>
	</div>
</div>
<?php endif; ?>
