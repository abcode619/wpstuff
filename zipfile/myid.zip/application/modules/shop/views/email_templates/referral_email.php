<body style="width: 640px;margin: 0 auto;padding: 0;height: auto;font-family: verdana;">
    <div style="border: 15px solid #28BB7F;border-radius: 5px;">
        
        <div class="footer_details" style="background: none repeat scroll 0 0 #28bb7f;color: #fff;float: left;height: 35px;margin-bottom: 15px;text-align: center;width: 100%;">
            <div style="font-size: 14px;">
                <b>This is an auto-generated email. Please do not respond to it.</b>                
            </div>            
        </div>
        
        <div class="logo" style="width: 100%;text-align: center;height: 100px;padding: 20px 0px ;">
            <img src="<?php echo site_url('assets/images/logo.png'); ?>" />
        </div>
        <div class="upper_info">            
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Greetings for you <b><?php echo $data['to_user_mail']; ?></b></p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">A user with email id <b><?php echo $data['from_user_mail']; ?></b> has made an order at <b>Orgone Energy Australia</b> and used your email id as referral code in the purchase.</p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Your Account has been credit by <b>$<?php echo $data['amount']; ?></b> and your current credit is <b>$<?php echo $data['total_credit']; ?></b>.</p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">You can use this amount in your next purchase at             
                <a href="<?php echo site_url(); ?>" style="font-weight: bold;color: #40B0E5">Orgone Energy Australia</a>
            </p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Thank you!</p>
        </div>
        
        <div class="footer_details" style="background: #28BB7F; color: #fff;">
            <div style="margin-left: 10px;padding: 30px 3px;font-size: 14px;">
                <b>This email was sent from Orgone Energy Australia</b><br>
                Email: <a href="mailto:<?php echo SITE_SUPPORT_EMAIL; ?>" style="font-weight: bold;color: #fff"><?php echo SITE_SUPPORT_EMAIL; ?></a><br>
                Phone: 61 3 5826 2751<br>
                P O Box 250<br>
                Rushworth VIC 3612<br>
                AUSTRALIA
            </div>            
        </div>
        
    </div>
</body>