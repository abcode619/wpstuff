<body style="width: 640px;margin: 0 auto;padding: 0;height: auto;font-family: verdana;">
    <div style="border: 15px solid #28BB7F;border-radius: 5px;">
        <div class="footer_details" style="background: none repeat scroll 0 0 #28bb7f;color: #fff;float: left;height: 35px;margin-bottom: 15px;text-align: center;width: 100%;">
            <div style="font-size: 14px;">
                <b>This is an auto-generated email. Please do not respond to it.</b>                
            </div>            
        </div>
        <div class="logo" style="width: 100%;text-align: center;height: 100px;padding: 20px 0px;">
            <img src="<?php echo site_url('assets/images/logo.png'); ?>" alt="Orgone Energy" />
        </div>
        <div class="upper_info">
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Hi, <?= $data['shipping']['s_firstname'] ?>! </p>            
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">Thank you for placing your order with Orgone Energy Australia.</p>
            <?php
            if(!empty($user['email']))
            {
            ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">If you are new, we have automatically created a free account for you where you can refer friends and be rewarded! Simply provide your email address to your friends and make sure they enter it into the referral field during checkout. They will get <?php echo REFERRAL_PERCENTAGES; ?>% off and you will get <?php echo REFERRAL_PERCENTAGES; ?>% credit on your account for the product total!</p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;"> More details on our website here : 
                <a href="<?php echo site_url('account'); ?>" style="font-weight: bold;color: #40B0E5">Orgone Energy Australia</a>
            </p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">If you login next time before placing your order, your last order delivery address will be added - saving you time. If you have any questions, please email or call us.</p>
            <?php
            }
            ?>
        </div>
            <?php
            if(!empty($user['email']))
            {
            ?>
                <div class="login_details">
                    <p style="margin-left: 10px;padding: 3px;font-size: 20px;"><u>Your login details : </u></p>
                    <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                        <span style="width: 125px;float: left;">Email Address : </span><span><?php echo $user['email']; ?></span><br/>
                        <span style="width: 125px;float: left;">Password : </span><span><?php echo $user['password']; ?></span>
                    </p>
                </div>
            <?php
            }
            ?>
        
        <div class="order_details">
            <?php        
                if($this->session->userdata("site_currency") == "aud") {
                    $currency = "AUD";                                                                
                } else {
                    $currency = "USD";                                                                
                }            
            ?>
            <p style="margin-left: 10px;padding: 3px;font-size: 20px;"><u>Order details: </u></p>
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                Order ID : <b><?php echo '#'.$user['order_id']; ?></b> (Placed on <?php echo date("D j, F  Y g:i a");?>)<br>
                Payment Method : <b><?php echo $user['payment_method']; ?></b><br>
                Transaction ID : <b><?php echo $user['transaction_id']; ?></b></p>
            <div style="margin:3px 10px;padding: 3px;font-size: 14px;">
                <table style="width: 97%;" border="1" cellpadding="0" cellspacing="0" bordercolor="#28BB7F">
                    <tr style="font-size: 14px;">
                        <th style="width: 30%;">Product</th>
                        <th style="width: 30%;">Product Type</th>
                        <th style="width: 5%;">Qty</th>
                        <th style="width: 15%;">Price (<?php echo $currency; ?>)</th>
                        <th style="width: 20%;text-align: right">Total (<?php echo $currency; ?>)</th>
                    </tr>
                    <?php foreach ($cart as $key => $item): ?>
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;"><?php echo $item['name']; ?></td>
                        <?php foreach($productType as $k => $val):
                                if($key == $k):
                        ?>
                        <td style="width: 30%;padding: 3px;"><?php echo $val->price_name; ?></td>
                        <?php endif; endforeach; ?>
                        <td style="width: 5%;text-align: center;"><?php echo $item['qty']; ?></td>
                        <td style="width: 15%;text-align: center;">$<?php echo sprintf('%.2f', $item['price']); ?></td>
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?php echo sprintf('%.2f', $item['subtotal']); ?></td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4">Cart Total : </td>                        
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?= sprintf('%.2f', $data['cart_total']) ?></td>
                    </tr>
                    <?php                                                             
                        $discount = $this->session->userdata['cart_contents']['discount']['COUPON'];
                        if(!empty($discount))
                        {
                    ?>
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4"><?php if(isset($discount->referrar_user_id)) { echo "Referrar Discount"; } else { echo "Coupon Discount"; } ?>:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo number_format($discount->amt, 2, '.', ''); ?></td>
                        </tr>

                    <?php } 
                                                            
                        if ($this->session->userdata('is_wholesaler') == "1") {
                            $discount = WHOLESALER_DISCOUNT;
                            $cart_wholesaler_discount = number_format(((number_format($this->session->userdata['grand_total_cart'], 2, '.', '') * $discount) / 100), 2, '.', '');
                            if ($currency == "AUD") {
                                $cart_wholesaler_discount = number_format(((number_format($this->session->userdata['cart_contents']['cart_total'], 2, '.', '') * $discount) / 100), 2, '.', '');
                            } else {
                                $cart_wholesaler_discount = number_format(((number_format($this->session->userdata['cart_contents']['cart_total_usd'], 2, '.', '') * $discount) / 100), 2, '.', '');
                            }
                            ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Wholesaler Discount:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo $cart_wholesaler_discount; ?></td>
                        </tr>

                        <?php
                        }

                        if($this->session->userdata('current_credit') > 0)
                        {
                            ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Credit Discount:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $<?php echo $this->session->userdata('current_credit'); ?></td>
                        </tr>

                        <?php
                        }

                        if (($this->session->userdata['bulk_total'] != 0 ) || ( $this->session->userdata['bulk_total_usd'] != 0 )) { ?>

                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Bulk Size Shipping:</td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> - $
                                <?php
                                if ($currency == "AUD") {
                                    echo number_format($this->session->userdata['bulk_total'], 2, '.', '');
                                } else {
                                    echo number_format($this->session->userdata['bulk_total_usd'], 2, '.', '');
                                }
                                ?>
                            </td>
                        </tr>

                        <?php
                        } 

                        $extra_charges_mini = $this->session->userdata('extra_charges');
                        
                        if (!empty($extra_charges_mini)) {
                            foreach ($extra_charges_mini as $key => $value) {
                                echo "<tr style='font-size: 12px;font-weight: normal;'>";
                                ?>
                                <td style="width: 30%;padding: 3px;" colspan="4"><?php echo $value['name']; ?>:</td>                                    
                                
                                <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> + $
                                    <?php
                                    if ($currency == "AUD") {
                                        $multiply_by = (floor($data['cart_total'] / $value['min_amount']) + 1);
                                        echo number_format(($value['val_aud'] * $multiply_by), 2, '.', '');
                                    } else {
                                        $multiply_by_usd = (floor($data['cart_total_usd'] / $value['min_amount']) + 1);
                                        echo number_format(($value['val_usd'] * $multiply_by_usd), 2, '.', '');
                                    }
                                    ?>  
                                </td>
                                
                                </tr>    

                                <?php
                            }
                        }


                        ?>                                

                        <?php if($data["shipping_cost"]): ?>
                        <?php if($data["shipping_cost"]['pickup'] ==false) : ?>
                                
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Shipping:<?= $data["shipping_cost"]['name'] ?></td>                        
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;"> + $
                                
                                <?php
                                if ($currency == "AUD") {
                                    echo $data["shipping_cost"]['cost'];
                                } else {
                                    echo $data["shipping_cost"]['cost_usd'];
                                }
                                ?>  
                                
                                
                            </td>
                        </tr>                                
                        
                        <?php else : ?>
                        
                        <tr style="font-size: 12px;font-weight: normal;">
                            <td style="width: 30%;padding: 3px;" colspan="4">Shipping:</td>
                            <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">Pick up</td>
                        </tr>                         
                        
                        <?php 
                            endif; 
                        endif; 
                        ?>                            
                        
<!--                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4">Shipping:India - Standard Post</td>                        
                        <td style="width: 15%;text-align: right;font-weight: bold;padding: 4px;">$1223.85</td>
                    </tr>-->
                    
                    <tr style="font-size: 12px;font-weight: normal;">
                        <td style="width: 30%;padding: 3px;" colspan="4"><b>Total</b></td>                        
                        <td style="width: 20%;text-align: right;font-weight: bold;padding: 4px;">$<?php echo number_format(($data['grand_total'] - $cart_wholesaler_discount - $this->session->userdata('current_credit')), 2, '.', '') . " " .  $currency; ?></td>
                    </tr>
                </table>                
            </div>
        </div>
        
        <div class="shipping_details">
            <p style="margin-left: 10px;padding: 3px;font-size: 20px;"><u>Shipping details: </u></p>
        
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                <?= $data['shipping']['s_firstname'] ?> <?= $data['shipping']['s_lastname'] ?><br /><br />
                <?= $data['shipping']['s_address_1'] ?><br />
                <?= $data['shipping']['s_address_2'] ?><br />
                <?= $data['shipping']['s_suburb'] ?>, <?= $data['shipping']['s_state'] ?>, <?= $data['shipping']['s_postcode'] ?><br />
                <?= $data['shipping']['s_country'] ?><br /><br />
                <?= $data['shipping']['s_zmail'] ?><br />
                <?= $data['shipping']['s_phone'] ?><br />
            </p>
            
            <p style="margin-left: 10px;padding: 3px;font-size: 14px;">
                <b>User Comments</b> : <?= $data['shipping']['s_comments'] ?>
            </p>
        </div>
        
        <div class="footer_detail" style="background: #28BB7F; color: #fff;">            
            <div style="margin-left: 10px;padding: 30px 3px;font-size: 14px;color: #fff;">
                <b>This email was sent from Orgone Energy Australia</b><br>
                Email: <a href="mailto:<?php echo SITE_SUPPORT_EMAIL; ?>" style="font-weight: bold;color: #fff"><?php echo SITE_SUPPORT_EMAIL; ?></a><br>
                Phone: <?php echo SITE_PHONE; ?><br>
                P O Box 250<br>
                Rushworth VIC 3612<br>
                Australia
            </div>            
        </div>
        
    </div>
</body>