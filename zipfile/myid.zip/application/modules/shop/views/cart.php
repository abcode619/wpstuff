<?php if ($cart):?>
<div class="checkout--section">
    <div class="columns small-12">
        <table class="cart-products-list">
            <!-- Cart header -->
            <thead class="cart-head">
                <tr>
                    <td colspan="2" class="">Details</td>
                    <td>Qty</td>
                    <td class="cart-item--td-price">Price</td>
                    <td>Total</td>
                </tr>
            </thead>
            <!-- Item list -->
            <tbody class="cart-body">
                <?php foreach ($cart as $id => $item): ?>
                <!-- Item -->
                <tr class="cart-item">
                    <!-- Item thumbnail image -->
                    <td class="cart-item--td-thumbnail">
                        <a class="cart-item--thumbnail" href='/<?= $base_name ?>/product/<?= $item['product_id'] ?>'>
                            <?php if (!empty($item['image'])): ?>
                                <img src='<?= tt($item['image'], 200, 120) ?>'>
                                <?php else: ?>
                                no image
                            <?php endif; ?>
                        </a>
                    </td>
                    <!-- Item details -->
                    <td class="cart-item--td-details">
                        <a class="cart-item--title" href='/<?= $base_name ?>/product/<?= $item['product_id'] ?>'><?= $item['name'] ?></a>
                        <p><?= $item['short_description'] ?></p>
                        <table>
                            <tr>
                                <td><span class="cart-item--desc"></span></td>
                                <td><span class="cart-item--desc"><?= $item['size_name'] ?></span></td>
                            </tr>
                        </table>
                    </td>
                    <!-- Item Quantity -->
                    <td class="cart-item--td-qty">
                        <!--
                        <a href='/store/cart_set_qty/<?= $id ?>/<?= $item['qty'] - 1 ?>/1'>[-]</a>
                        <span class="cart-item--qty"><?= $item['qty'] ?></span>
                        <a href='/store/cart_set_qty/<?= $id ?>/<?= $item['qty'] + 1 ?>/1'>[+]</a>
                        -->
                        <select class="cart-item--qty" name="qty" id="qty-<?= $id ?>" onchange='window.location = "<?= $base_name ?>/cart_set_qty/<?= $id ?>/" + $("#qty-<?= $id ?>").val() + "/1"'>
                            <?php foreach (range(1, 100) as $number): ?>
                                <option value="<?= $number ?>" <?= $number == $item['qty'] ? 'selected' : '' ?>><?= $number ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <!-- Item Price -->
                    <td>
                        <span class="cart-item--price">
                            <?= sprintf('%.2f', $item['price']) ?> ea.
                        </span>
                    </td>
                    <!-- Item Total -->
                    <td>
                        <span class="cart-item--total"></span>
                        <?= sprintf('%.2f', $item['qty'] * $item['price']) ?>
                        </span>
                    </td>
                    <!-- Item Actions -->
                    <td class="cart-item">
                        <a class="cart-item--remove" href='/<?= $base_name ?>/cart_remove/<?= $id ?>/1'>remove</a>
                    </td>
                </tr>
                <!-- Use this to create spacing between items -->
                <tr class="cart-item--separator">
                    <td colspan="1"></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Section -->
<div class="checkout--section">
    <!-- column -->
    <div class="columns sm-1-1 md-1-2">
        <!-- Coupons -->
        <div class="checkout--module">
            <!-- Coupon Details Cost -->
            <?php if (isset($coupon)): ?>
                <table>
                    <tr>
                        <td>
                            <p class="cart-item--misc">
                                Coupon <?= $coupon->code ?>:
                            </p>
                        </td>
                        <td>
                            <p class="cart-item--misc">
                                <?= $coupon->value ?><?= $coupon->unit ?>
                                <a href='?resetcoupon'>[reset]</a>
                            </p>
                        </td>
                    </tr>
                </table>
            <?php else: ?>
                <h2>Coupon Codes</h2>
                <h4>
                    Enter your coupon code to save on your order
                </h4>
                <form action='/<?= $base_name ?>/cart/' method='POST'>
                    <div class="row ">
                        <div class="columns sm1-1">
                            <input class="text-input columns sm-5-8 input-sm" type='text' name='coupon' />
                            <input class="btn btn-default columns sm-2-8 input-sm" type='submit' value='apply >' style="margin-bottom: 0;position: absolute;right: 0;background: none;color:grey;width: 20%"/>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
            <?php if (isset($coupon_error)): ?>
                <p class='error'>
                    <?= $coupon_error ?>
                </p>
            <?php endif; ?>
        </div>
    </div>
    <!-- column -->
    <div class="columns sm-1-1 md-1-2">
        <!-- Order Summary -->
        <div class="checkout--summary">
            <h2>Order Summary</h2>
            <table>
                <!-- Subtotal amount -->
                <tr>
                    <td><p class="cart-item--misc">Subtotal:</p></td>
                    <td><p class="cart-item--misc">$<?= sprintf('%.2f', $total) ?></p></td>
                </tr>
                <!-- Coupons -->
                <?php if ($coupon_value): ?>
                    <tr>
                        <td><p class="cart-item--misc">Coupon:</p></td>
                        <td><p class="cart-item--misc">$<?= sprintf('%.2f', $coupon_value) ?></p></td>
                    </tr>
                <?php endif; ?>
                <!-- Total cost -->
                <tr>
                    <td><p class="cart-item--misc">Total:</p></td>
                    <td><p class="cart-item--misc">$<?= sprintf('%.2f', $total - $coupon_value) ?></p></td>
                </tr>
            </table>
            <div class="row">
                <div class="columns sm-1-2">
                    <a class="btn btn-default btn-block input-sm"  href='/<?= $base_name ?>/'>Continue shopping</a>
                </div>
                <div class="columns sm-1-2">
                    <a class="btn btn-primary btn-block input-sm" href='/<?= $base_name ?>checkout/'>Checkout</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (isset($errors) and !empty($errors)): ?>
    <div class='error'>
        <?php foreach ($errors as $error): ?>
            <?= $error ?>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php else: ?>
    <p>Your shopping cart is empty.</p>
<?php endif; ?>