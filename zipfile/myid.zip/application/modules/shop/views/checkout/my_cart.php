<div class="mid_content topspace">
    <!-- Page Header -->
    
    <?php $this->load->view($base_name . '/checkout/components/checkoutnav'); ?>
    
    <?php if ($cart) : ?>
        
        <!-- template -->
        <div class="template-checkout" id="maincart">
            <!--  All Cart products first step cartItem.php    -->
            <div class="template-checkout__main col-md-8 padil0">

            </div>
        </div>

        <!-- Order Summary & Coupon Code order_summary.php    -->
        <div class="template-checkout__aside col-md-4 padir0 OrderSummary_right">

        </div>


    <?php else : ?>
        <div>
            <h3 style="padding: 100px 0px 20px 0px;"> Your cart is empty.</h3>
            <a class="btn" href="<?php echo site_url(); ?>"><button class="btn">Back to SHOP</button></a>
        </div>
    <?php endif; ?>

</div>