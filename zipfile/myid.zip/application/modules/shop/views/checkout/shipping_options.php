    <!-- Page Header -->
    <?php $this->load->view($base_name . '/checkout/components/checkoutnav'); ?>

    <!-- template -->
    <div class="template-checkout" id="shippping-details">

        <!-- area -->
        <div class="template-checkout__main">
            <!--	Loadding the shipping selectiin list -->
            <div id="shipping-options">

            </div>
            <!--<div class="page-body page-body--inner  wysiwyg">-->
                <?php echo validation_errors('<div class="error">', '</div>'); ?>
                <!--<div class="pure-form pure-form-stacked" method="post">-->

                    <!-- Group -->
                    <!--<div id="form-contents">-->
                    <!-- Group -->
                    
                    <?php
                    if ($this->config->item('extraa_charges')) { // Start extraa charges code
                        if (!empty($extra_charges)) {
                            ?>

                            <h4>Things you may wish to add to your order</h4>
                            <?php
                            foreach ($extra_charges as $key => $value) {
                                $charge_id = $value['store_order_extra_id'];
                                ?>                                
                                    <input type="checkbox" 
                                           value="1" 
                                           name="extra_charge_<?php echo $charge_id; ?>" 
                                           id="extra_charge_<?php echo $charge_id; ?>" 
                                           class="checkbox_left" 
                                           onchange="calculateExtraCost('<?php echo $charge_id; ?>')"
                                           <?php
                                           if (!empty($this->session->userdata['extra_charges']['charge_' . $charge_id])) {
                                               echo "checked";
                                           }
                                           ?>
                                           >
                                    <label for="extra_charge_<?php echo $charge_id; ?>"><?php echo $value['name']; ?></label>
                                    <div>$<?php echo $value['val_aud']; ?> ($<?php echo $value['val_usd']; ?> USD) per each $<?php echo $value['min_amount']; ?> <?php echo $value['description']; ?></div>
                                
                                <?php
                            }
                        }
                    }
                    ?>
                
                    <a href="/shop/checkout/payment_and_summary">
                        <button class="">PAYMENT DETAILS</button>    
                    </a>

            <!--</div>-->
            <br>
        </div>

        <div class="template-checkout__aside">
            <div class="billing_rbox" id="mini-template-order-summary">
            </div>
            <?php $this->load->view('./widgets/sidebar/sidebar--link-list', array('sidebar_links__title' => $helpfulLinks__title, 'sidebar_links' => $helpfulLinks__nav_list,)); ?>
        </div>
    </div>
<!--</div>-->