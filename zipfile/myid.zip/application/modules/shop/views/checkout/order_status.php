<div class="mid_content topspace">
    <!-- Page Header --> 

    <?php $this->load->view($base_name . '/checkout/components/checkoutnav'); ?>            

    <?php 
    
    #need to put condition here to show link to account details page
    echo "<pre>";
    print_r($this->session->userdata);
    echo "</pre>";
    
    ?>
    
    <?php
    if ($this->uri->segment(4) == "success") { 
        $purchased_pdfs = $this->session->userdata("purchased_pdfs");        
        ?>   
        <div class="col-md-8 padil0 mgtop20 mgbot20 leftside_text">
            <h3>Thank you for your order!</h3>         
            <p>We have received your order and have sent a copy of your order details to the email address provided</p>
            
            <?php
            if(!empty($purchased_pdfs))
            {
                $name_pdfs = array();
                foreach ($purchased_pdfs as $key => $value){
                    if(!empty($value))
                    {
                        $name_pdfs[] = substr($value, 11);
                    }
                }

                echo "<h6>Download your purchased files here...</h6>";
                echo "<ul>";
                foreach ($name_pdfs as $key => $value)
                {
                    echo '<li ><a href="/resources/'.$value.'" download>File # '.($key+1).'</a></li>';
                }
                echo "</ul>";
                
            }
            
            ?>
            
            <hr class="clear">
            <p>If you have any questions about your order, please view our <a href="/faq">FAQ section</a> or <a href="/contact-us">contact us</a>.</p>
            <p>if you do not receive our email, please note your order number is #<?php echo str_pad($this->session->userdata('saved_order_id'), 6, '0', STR_PAD_LEFT); ?>.</p>
            <p>Thank you again for shopping online with Orgone Energy Australia.</p>
        </div>
        <?php
    } else {
        ?>
        <div class="col-md-8 padil0 mgtop20 mgbot20 leftside_text">
            <p>Sorry!!!</p>
            <p>Your order couldn't be completed, please try again later!</p>   
        </div>
    <?php } ?>

</div>