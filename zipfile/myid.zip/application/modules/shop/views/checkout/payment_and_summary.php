<!--<div class="mid_content topspace">-->

    <!-- Page Header -->
    <?php $this->load->view($base_name . '/checkout/components/checkoutnav'); ?>

    <!-- area -->
    <div class="template-checkout__main">


        <?php
        if ($this->session->userdata("site_currency") == "aud") {
            $currency_value = "AUD";
        } else {
            $currency_value = "USD";
        }

        $total_payment = number_format(($this->session->userdata['grand_total_cart'] - $this->session->userdata('current_credit')), 2, '.', ',') . " " . $currency_value;
        ?>

        <!-- Payment Details -->

        <?php
        if (isset($validation_errors)) {
            echo '<div>';
            echo '<div>' . $validation_errors . '</div>';
            echo '</div>';
        }
        ?>

        <h4>Please choose a payment method</h4> 
        <div> 
            <select name="pmethod_selector" class="pmethod_selector">
                <option value="paypal">PayPal</option>
                <?php if ($currency_value == "AUD") { ?><option value="creditcard">Credit Card</option><?php } ?>
                <option value="directdeposit">Direct Deposit</option>
            </select>      
        </div> 


        <div class="paypal_payment">
            <h4>Payment Method: PayPal</h4>
            <p class="process_transaction1">
                By processing this transaction, you agree to the <a href="/page/terms-and-conditions" target="_blank"><u>terms and conditions</u></a> of this website and agree that your PayPal account will be charged $<?php echo $total_payment; ?> inc GST.
            </p>

            <a href="/shop/checkout/paypal">
                    <button name="eway_submit" class="" type="submit">PROCESS ORDER NOW-Paypal</button>
            </a>
        </div>

        <div class="eway_payment" style="display: none;">
            <h4>Payment Method: Credit Card</h4>
            <?php
            if ($this->session->userdata("site_currency") == "aud") {
                ?>

                <form action="#" class=""  method="post">

                    <!-- Group -->
                    <div>
                        <label for="">Name on Card</label>
                        <input id="" name='card_name' type="text" value="<?= set_value('card_name') ?>" required>
                    </div>
                    <!-- Group -->

                    <div>
                        <label for="">Card Number</label>
                        <input id="card_number" name="cc_number" type="text" value="<?= set_value('cc_number') ?>" placeholder="1234 5678 9012 3456" required>
                    </div>
                    <!-- Group -->
                    
                    <div>
                        <div class="">
                            <label for="">Expiry Month</label>
                            <select name="month" class="">
                                <option value="" >Select Month</option>
                                <option value="January" <?php echo set_select('month', 'January'); ?>>January</option>
                                <option value="February" <?php echo set_select('month', 'February'); ?>>February</option>
                                <option value="March" <?php echo set_select('month', 'March'); ?>>March</option>
                                <option value="April" <?php echo set_select('month', 'April'); ?>>April</option>
                                <option value="May" <?php echo set_select('month', 'May'); ?>>May</option>
                                <option value="June" <?php echo set_select('month', 'June'); ?>>June</option>
                                <option value="July" <?php echo set_select('month', 'July'); ?>>July</option>
                                <option value="August"  <?php echo set_select('month', 'August'); ?>>August</option>
                                <option value="September" <?php echo set_select('month', 'September'); ?>>September</option>
                                <option value="October" <?php echo set_select('month', 'October'); ?>>October</option>
                                <option value="November" <?php echo set_select('month', 'November'); ?>>November</option>
                                <option value="December" <?php echo set_select('month', 'December'); ?>>December</option>
                            </select>
                        </div>
                        <!-- Group -->
                        
                        <div class="">
                            <label for="">Expiry Year</label>
                            <select name="year" class="">
                                <option value=""> Select Year</option>
                                <?php for ($i = date("Y"); $i <= date("Y") + 10; $i++) {
                                    ?>
                                    <option value='<?= $i ?>' <?= set_select('year', $i); ?> ><?= $i ?></option>";
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <!-- only for mastro card-->
                    <div class="vertical maestro">
                        <div class="">
                            <span class=>or</span>
                            <label for="issue_date">Issue date
                                <small>mm/yy</small>
                            </label>
                            <input type="text" name="issue_date" id="issue_date" maxlength="5">
                        </div>
                        <!-- Group -->
                        <div class="">
                            <label for="issue_number"> <span class="">or</span>  Issue number</label>
                            <input type="text" name="issue_number" id="issue_number" maxlength="2">
                        </div>
                    </div>
                    <!-- Group -->
                    <div class="" >
                        <label for="">CVV (<a target='_blank' href="https://vault.safepay.com.au/whatisCVV.html">What is this?</a>)</label>
                        <input name="cvv" type="text" pattern="[0-9]{3}" maxlength="4" value="<?= set_value('cvv') ?>" required>
                    </div>

                    <br class="clear">

                    <p class="process_transaction2"> 
                        By processing this transaction, you agree to the <a href="/page/terms-and-conditions" target="_blank"><u>terms and conditions</u></a> of this website and 
                        agree that your creditcard will be 
                        charged $<?php echo $total_payment; ?> inc GST.
                    </p> 


                    <?php
                    if ($this->session->userdata("site_currency") == "aud") {
                        ?>
                        <!-- Group -->
                        <div class="">
                            <button type="submit" class="" name="eway_submit">PROCESS ORDER NOW-eWay</button>                                
                        </div>

                        <?php
                    } else {
                        
                    }
                    ?>


                    <?php
                } else {
                    
                }
                ?>


            </form>
        </div> 

        <div class="direct_payment" style="display: none;">
            <h4 class="">Payment Method: Direct Deposit</h4>
            <p class="process_transaction3">
                Use of direct deposit is only for those who do not have Credit Card or PayPal payment options. 
                Please note orders can take longer to process while we wait for payment through this method. 
                You will be notified of bank details once the order has been placed.
                You will be charged $<?php echo $total_payment; ?> inc GST.
            </p>
            <p></p>

            <a href="/shop/checkout/direct_order">
                    <button type="submit" class="" name="eway_submit">PROCESS ORDER NOW-Direct</button>
            </a>
            
        </div>

        <h4 class="">Cart Summary</h4>
        <?php if (count($cart) > 0) : ?>                                                 
            <?php foreach ($cart as $i) : ?>
                <?php $this->load->view('/checkout/components/payment_summary_cartItem', array('product' => $i)); ?>
            <?php endforeach ?>                       
        <?php endif; ?>   

        <br class="clear">        

        <?php
        if ($this->session->userdata("site_currency") == "aud") {
            
        } else {
            
        }
        ?>

    </div> 

    <!-- area -->
    <div class="template-checkout__aside">
        <!-- Order Summary -->
        <div class="billing_rbox" id="mini-template-order-summary-payment-summary">

        </div>

        <!-- Billing & Shipping Summary -->
        <div class="billing_rbox" id ='billing_and_shipping_info'>

        </div>
        <!-- Feel Good links -->
<?php $this->load->view('./widgets/sidebar/sidebar--link-list', array('sidebar_links__title' => $helpfulLinks__title, 'sidebar_links' => $helpfulLinks__nav_list,)) ?>
    </div>

<!--</div>-->

<script>
    $(".pmethod_selector").on("change", function() {
        var selected = $(".pmethod_selector").val();
        if (selected === "paypal") {
            $(".paypal_payment").css("display", "block");
            $(".eway_payment").css("display", "none");
            $(".direct_payment").css("display", "none");
        } 
        else if (selected === "creditcard") {
            $(".paypal_payment").css("display", "none");
            $(".eway_payment").css("display", "block");
            $(".direct_payment").css("display", "none");
        } 
        else {
            $(".paypal_payment").css("display", "none");
            $(".eway_payment").css("display", "none");
            $(".direct_payment").css("display", "block");
        }
    });    
</script>