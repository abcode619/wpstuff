<h4>Billing & Shipping</h4> 
<a href="/shop/checkout/shipping_details" class="edit_link">Edit</a>

<!--	billing details -->
<?php if (isset($billing)) : ?>
    <p>        
        <strong>Invoiced to : <?= $billing['b_firstname'] . ' ' . $billing['b_lastname'] ?></strong><br>
        <p><?php echo $billing['b_address_1']."<br>".$billing['b_address_2']."<br>"; ?>
        <?php echo $billing['b_suburb'].", ".$billing['b_state'].", ".$billing['b_postcode']."<br>".$billing['b_country']; ?></p>        
        <p><?php echo $billing['b_zmail']."<br>".$billing['b_phone']; ?></p>
    </p>
<?php endif; ?>
<!-- shipping-->
<?php if (isset($shipping) && $pickup == false) : ?>
    <p>        
        <strong>Shipping to : <?= $shipping['s_firstname'] . ' ' . $shipping['s_lastname'] ?></strong><br>
        <p><?php echo $shipping['s_address_1']."<br>".$shipping['s_address_2']."<br>"; ?>
        <?php echo $shipping['s_suburb'].", ".$shipping['s_state'].", ".$shipping['s_postcode']."<br>".$shipping['s_country']; ?></p>
        <p><?php echo $shipping['s_zmail']."<br>".$shipping['s_phone']; ?></p>        
    </p>
<?php endif; ?>
<?php if ($pickup) : ?>
    <p>
        <strong>Shipping : </strong> Pickup<br>
    </p>
<?php endif; ?>