<h4>Order Summary</h4>

<?php
//echo "<pre>";
//print_r($mini_summary);
//echo "</pre>";
//echo "<pre>";
//print_r($this->session->userdata['cart_contents']);
//echo "</pre>";
?>

    Cart Total:     
        <?php
        if ($this->session->userdata("site_currency") == "aud") {
            $currency = "AUD";
            echo "$" . number_format($mini_summary['cart_total'], 2, '.', ',') . " AUD";
        } else {
            $currency = "USD";
            echo "$" . number_format($mini_summary['cart_total_usd'], 2, '.', ',') . " USD";
        }
        ?><br>

<?php
    $mini_summary_discount = $this->session->userdata['cart_contents'];
?>

<?php if (isset($mini_summary_discount['discount']) && !empty($mini_summary_discount['discount'])) { 
    $mini_summary_discount_this = $mini_summary_discount['discount']['COUPON'];
    ?> 
        Coupon applied(<?php echo $mini_summary_discount_this->value." ".$mini_summary_discount_this->unit." of Cart Total"; ?>): <?php echo "- $" . number_format($mini_summary_discount_this->amt, 2, '.', ',') . " " . $currency; ?><br>        
<?php
        }
?>
        
<?php // foreach ($discounts as $key => $value) { ?>
        <?php // echo ucfirst(str_replace('_', ' ', $key)); ?>
        <?php // echo "-".$value . " " . $currency; ?>
<?php // } ?>

<?php
# Here we are putting a measure to cut down the actual prices by 30% if a user
# is a wholesaler type, only printing here...actual implimentation is in checkout controller

if ($this->session->userdata('is_wholesaler') == "1") {
    $discount = WHOLESALER_DISCOUNT;
    $cart_wholesaler_discount = number_format(((number_format($mini_summary['grand_total'], 2, '.', '') * $discount) / 100), 2, '.', '');
    if ($currency == "AUD") {
        $cart_wholesaler_discount = number_format(((number_format($mini_summary['cart_total'], 2, '.', '') * $discount) / 100), 2, '.', '');
    } else {
        $cart_wholesaler_discount = number_format(((number_format($mini_summary['cart_total_usd'], 2, '.', '') * $discount) / 100), 2, '.', '');
    }
    ?>

    Wholesaler Discount:         
    <?php
    if ($currency == "AUD") {
        echo "- $" . number_format($cart_wholesaler_discount, 2) . " " . $currency;
    } else {
        echo "- $" . number_format($cart_wholesaler_discount, 2) . " " . $currency;
    }
    ?>
    <br>
<?php }
else {    
} ?>

<?php if ($this->session->userdata('current_credit') != "0.00" && $this->session->userdata('current_credit') != "") { ?>
        Credit Discount: 
        <?php echo "- $" . number_format($this->session->userdata('current_credit'), 2, '.', '') . " " . $currency; ?><br>
<?php } ?>

<?php if (isset($mini_summary['shipping_message'])) { ?>
        Shipping (<?php echo $mini_summary['shipping_message']; ?>): 
        <?php
        if ($currency == "AUD") {
            ?>
            + $<?php echo number_format($mini_summary['shipping_cost'], 2, '.', ',') . " " . $currency; ?>
            <?php
        } else {
            ?>
            + $<?php echo number_format($mini_summary['shipping_cost_usd'], 2, '.', ',') . " " . $currency; ?>
            <?php
        }
        ?><br>
<?php } ?>

<?php if (( isset($mini_summary['bulk_total']) && $mini_summary['bulk_total'] != 0 ) || ( isset($mini_summary['bulk_total_usd']) && $mini_summary['bulk_total_usd'] != 0 )) { ?>
        Bulk Size Shipping: 
        + $
            <?php
            if ($currency == "AUD") {
                echo number_format($mini_summary['bulk_total'], 2, '.', ',') . " " . $currency;
            } else {
                echo number_format($mini_summary['bulk_total_usd'], 2, '.', ',') . " " . $currency;
            }
            ?><br>
<?php } ?>



<?php
$extra_charges_mini = $this->session->userdata('extra_charges');
if (!empty($extra_charges_mini)) {
    foreach ($extra_charges_mini as $key => $value) {
        ?>        
            <?php echo $value['name']; ?>: 
            + $
        <?php
        if ($currency == "AUD") {
            $multiply_by = (floor($mini_summary['cart_total'] / $value['min_amount']) + 1);
            echo number_format(($value['val_aud'] * $multiply_by), 2, '.', '') . " " . $currency;
        } else {
            $multiply_by_usd = (floor($mini_summary['cart_total_usd'] / $value['min_amount']) + 1);
            echo number_format(($value['val_usd'] * $multiply_by_usd), 2, '.', '') . " " . $currency;
        }
        ?><br>
        <?php
    }
}
?>


<hr class="clear" style="margin-bottom: 0px !important;margin-top: 10px !important">

    Total: <span class="grand_amount">$<?php echo number_format(($mini_summary['grand_total'] - $cart_wholesaler_discount - $this->session->userdata('current_credit')), 2, '.', ',') . " " .  $currency; ?></span>