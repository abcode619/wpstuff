<?php
if (end($this->uri->segment_array()) == "cart") {
    $cartActive = "active";$address_detailsActive = "";$shipping_optionsActive = "";
    $payment_and_summaryActive = "";$order_completedActive = "";
    echo '<h1>My Cart</h1>';
} elseif (end($this->uri->segment_array()) == "address_details") {
    $cartActive = "complete";$address_detailsActive = "active";$shipping_optionsActive = "";
    $payment_and_summaryActive = "";$order_completedActive = "";
    echo '<h1>My Cart : <span>Address Details</span></h1>';
} elseif (end($this->uri->segment_array()) == "shipping_options") {
    $cartActive = "complete";$address_detailsActive = "complete";$shipping_optionsActive = "active";
    $payment_and_summaryActive = "";$order_completedActive = "";
    echo '<h1>My Cart : <span>Shipping Options</span></h1>';
} elseif (end($this->uri->segment_array()) == "payment_and_summary") {
    $cartActive = "complete";$address_detailsActive = "complete";$shipping_optionsActive = "complete";
    $payment_and_summaryActive = "active";$order_completedActive = "";
    echo '<h1>My Cart : <span>Payment & Summary</span></h1>';
} elseif (end($this->uri->segment_array()) == "success") {
    $cartActive = "complete";$address_detailsActive = "complete";$shipping_optionsActive = "complete";
    $payment_and_summaryActive = "complete";$order_completedActive = "active";
    echo '<h1>My Cart : <span>Order Completed</span></h1>';
} elseif (end($this->uri->segment_array()) == "failure") {
    $cartActive = "complete";$address_detailsActive = "complete";$shipping_optionsActive = "complete";
    $payment_and_summaryActive = "complete";$order_completedActive = "active";
    echo '<h1>My Cart : <span>Payment Failure</span></h1>';
} else {
    
}
?>

<ul>
    <li class="<?php echo $cartActive; ?>">
        <a  class="<?= displayClass('cart', end($this->uri->segment_array())); ?>" 
            href="<?= site_url($base_name . '/cart') ?>">CART</a>
    <li class="<?php echo $address_detailsActive; ?>">
        <a class="<?= displayClass('address_details', end($this->uri->segment_array())); ?>" 
           href="<?= site_url($base_name . '/checkout/address_details') ?>">ADDRESS DETAILS</a>
    <li class="<?php echo $shipping_optionsActive; ?>">
        <a class="<?= displayClass('shipping_options', end($this->uri->segment_array())); ?>" 
           href="<?= site_url($base_name . '/checkout/shipping_options') ?>">SHIPPING OPTIONS</a>
    <li class="<?php echo $payment_and_summaryActive; ?>">
        <a class="<?= displayClass('payment_and_summary', end($this->uri->segment_array())); ?>" 
           href="<?= site_url($base_name . '/checkout/payment_and_summary') ?>">PAYMENT & SUMMARY</a> 
    <li class="<?php echo $order_completedActive; ?>">
        <a class="<?= displayClass('order_completed', end($this->uri->segment_array())); ?>"
           href="<?= site_url($base_name . '/checkout/order_completed') ?>">ORDER STATUS</a>
</ul>