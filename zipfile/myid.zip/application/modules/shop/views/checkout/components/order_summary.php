<h4>Order Summary</h4>

<?php
// Don't remove this
$coupan_data = $this->session->userdata('cart_contents');
$discount_data = $coupan_data['discount']['COUPON'];

//echo "<pre>";
//print_r($summary);
//echo "</pre>";

?>

<?php
# If a user is a wholesaler user, we can not allow him/her to add any coupon code to get added
# advantage as far as coupon/referral discount is concerned.
?>

<?php if ($this->session->userdata('is_wholesaler') == "0") { ?>
    <?php if ($this->config->item('coupon_code')) { // start coupon code  ?>

        <?php if (isset($summary['coupon_applied']) && $summary['coupon_applied'] != false) { ?>
            <p>
                <strong><?php echo $summary['coupon_applied']; ?> - </strong> 
                <?php
                if (isset($discount_data->referrar_user_id)) {
                    echo "Referral Applied";
                } else {
                    echo "Coupon Applied";
                }
                ?>                
            </p>
        <?php } else { ?>            

            <p>Do you have a coupon<?php if ($this->config->item('coupon_code_referrar')) { ?> / referral code<?php } ?>?</p>
            <input type="text" id="shop-coupon-code" name="shop_coupon_code" value="" placeholder="Enter coupon code here">
            <input type="submit" value="APPLY" id="couponsub" class="update_btn">
            <br class="clear">
            <p id="referral_loading" style="display: none;"><img src="<?php echo assets_url("/images/ajax-loader.gif"); ?>" /></p>            
            <p id="referral_failure" class="red_text"></p>

        <?php } ?>

    <?php } // end coupon code  ?>

<?php } ?>

<?php
if ($this->session->userdata("site_currency") == "aud") {
    $currency = "AUD";
} else {
    $currency = "USD";
}
?>

Cart Total: $<?php
if ($currency == "AUD") {
    echo number_format($summary['cart_total'], 2, '.', ',') . " " . $currency;
} else {
    echo number_format($summary['cart_total_usd'], 2, '.', ',') . " " . $currency;
}
?><br>

<?php if (isset($summary['discount']) && $summary['discount'] != "0") {     
        ?>
        Coupon applied(<?php echo $discount_data->value." ".$discount_data->unit." of Cart Total"; ?>): <?php echo "- $" . number_format($summary['discount'], 2, '.', ',') . " " . $currency; ?><br>
    <?php    
}
?>

<?php
# Here we are putting a measure to cut down the actual prices by 30% if a user
# is a wholesaler type, only printing here...actual implimentation is in checkout controller

if ($this->session->userdata('is_wholesaler') == "1") {
    $discount = WHOLESALER_DISCOUNT;
    if ($currency == "AUD") {
        $cart_wholesaler_discount = number_format(((number_format($summary['cart_total'], 2, '.', '') * $discount) / 100), 2, '.', '');
    } else {
        $cart_wholesaler_discount = number_format(((number_format($summary['cart_total_usd'], 2, '.', '') * $discount) / 100), 2, '.', '');
    }
    ?>
    Wholesaler Discount: <?php
    if ($currency == "AUD") {
        echo "- $" . number_format($cart_wholesaler_discount, 2) . " " . $currency;
    } else {
        echo "- $" . number_format($cart_wholesaler_discount, 2) . " " . $currency;
    }
    ?><br>
<?php } else {
    
}
?>

<?php if ($this->session->userdata('current_credit') != "0.00" && $this->session->userdata('current_credit') != "") { ?>
    Credit Discount:
    <?php echo "- $" . number_format($this->session->userdata('current_credit'), 2, '.', ',') . " " . $currency; ?><br>
<?php } ?>

<?php if (isset($summary['shipping_cost'])) { ?>
    Shipping (<?php echo $summary['shipping_message']; ?>): 
    <?php if ($currency == "AUD") { ?> + $<?php echo number_format($summary['shipping_cost'], 2, '.', ',') . " " . $currency; ?><br>
    <?php } else { ?>
        + $<?php echo number_format($summary['shipping_cost_usd'], 2, '.', ',') . " " . $currency; ?><br>
        <?php
    }
    ?>
<?php } ?>


<?php if (( isset($summary['bulk_total']) && $summary['bulk_total'] != 0 ) || ( isset($summary['bulk_total_usd']) && $summary['bulk_total_usd'] != 0 )) { ?>
    Bulk Size Shipping: + $
    <?php
    if ($currency == "AUD") {
        echo number_format($summary['bulk_total'], 2, '.', ',') . " " . $currency;
    } else {
        echo number_format($summary['bulk_total_usd'], 2, '.', ',') . " " . $currency;
    }
    ?><br>    
<?php } ?>

<?php
$extra_charges_mini = $this->session->userdata('extra_charges');
if (!empty($extra_charges_mini)) {
    foreach ($extra_charges_mini as $key => $value) {
        echo $value['name'];
        ?>: 
        + $
        <?php
        if ($currency == "AUD") {
            $multiply_by = (floor($summary['cart_total'] / $value['min_amount']) + 1);
            echo number_format(($value['val_aud'] * $multiply_by), 2, '.', '') . " " . $currency;
        } else {
            $multiply_by_usd = (floor($summary['cart_total_usd'] / $value['min_amount']) + 1);
            echo number_format(($value['val_usd'] * $multiply_by_usd), 2, '.', '') . " " . $currency;
        }
        ?><br>

        <?php
    }
}
?>

<hr>

Total: $<?php echo number_format(($summary['total'] - $cart_wholesaler_discount - $this->session->userdata('current_credit')), 2, '.', ',') . " " . $currency; ?>


<!--<button class="sucurecheckout_btn"></button>-->

<a href="<?= site_url($this->config->item('base_name') . '/checkout/address_details') ?>"> 
    <button  class="sucurecheckout_btn">SECURE CHECKOUT</button>
</a>