<!--<div class="checkoutSection wysiwyg">-->
    <h4>Shipping Options</h4>

    <?php
//    echo "<pre>";
//    print_r($this->session->userdata('cart_contents')); 

    if ($this->config->item('countrywide_shipping')) {
        if ($shipping_options) {
            ?>
            <p>Please select the shipping option here</p>
        <!--</div>-->    

        <!--<div class="checkoutSection wysiwyg" id="shipping-details-div">-->

            <?php
            $whole_cart = $this->session->userdata('cart_contents');
            $selected_shipping = $whole_cart['shipping_cost']['shipping_id'];

            foreach ($shipping_options as $key => $value) {
                ?>
                <label class="pure-checkbox">
                    <input type="radio" shipping_id ="<?php echo $value->store_shippings_id; ?>" class="shipping_methods" name="shipping_methods" 
                           onclick="change_shipping_method(<?php echo $value->store_shippings_id; ?>)"
            <?php
            if ($selected_shipping == $value->store_shippings_id) {
                echo "checked";
            }
            ?>
                           > <?php echo $value->name; ?>
                           <?php if (!empty($value->description)) { ?>
                        <p style="margin: 0px 0px 0px 15px;padding: 0;font-style: italic">
                               <?php echo $value->description; ?>
                        </p>
                        <?php } ?>
                </label> <br>
                <?php } ?>
        <!--</div>-->

        <?php
    } else {
        echo "<p>No special shipping methods available for this country.</p>";
    }
}
echo "<br>";
?>
<!--  Shipping pick up option -->
<?php if ($this->config->item('pick_up_option')) : ?>
        <label class="pure-checkbox">
    <?php if ($shipping['pickup'] == true): ?>
                <input type="checkbox" id="pickup-order" checked> <?= $this->config->item('pick_up_option_display_message') ?>
            <?php else: ?>
                <input type="checkbox" id="pickup-order" > <?= $this->config->item('pick_up_option_display_message') ?>
            <?php endif; ?>
        </label>
        <?php endif; ?>

<?php if ($shipping['pickup'] == true): ?>
        <p>Pickup Location : <?= 'store address' ?> </p>
<?php

else:
    $cart_session = $this->session->userdata('cart_contents');

    if ($cart_session['total_products'] == $cart_session['total_products_noshipping']) {
        ?>
            <p>Either one or all of the products in your cart are shipping free.</p>
        <?php
    } else {
        ?>
            <p>Shipping to : <?= $shipping['country']; ?> </p>
        <span id="shipping_dynamic_message">
            <p><?= $shipping['display_mess']; ?> </p>

            <p>Cost : <strong>
        <?php
        if ($this->session->userdata("site_currency") == "aud") {
            echo "$" . number_format($shipping['cost'], 2, '.', '') . " AUD";
        } else {
            echo "$" . number_format($shipping['cost_usd'], 2, '.', '') . " USD";
        }
        ?>
                </strong>
            </p>
        </span>
                <?php } ?>
<?php endif; ?>