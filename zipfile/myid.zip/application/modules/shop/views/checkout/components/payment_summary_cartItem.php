<!--<div class="cart_items">-->

<?php if (!empty($product['image'])) { ?>
    <a href="<?= site_url($this->config->item('base_name') . '/product/' . $product['slug']) ?>">
        <img src="<?= tt(site_url($product['image']), 200, 200, '&zc=2&q=100') ?>" alt="" class="">
    </a>
<?php } ?>

<h4><?php echo ucfirst($product['name']); ?></h4>
Quantity : <?php echo $product['qty']; ?><br>

Product Type: <?php echo $product['price_name']; ?><br>

Each Product Price:               

<?php
// process to add sale price in cart total if condition meets.
$date1 = strtotime($product['sale_end']);
$date2 = time();
$subTime = $date1 - $date2;
$y = ($subTime / (60 * 60 * 24 * 365));
$d = ($subTime / (60 * 60 * 24)) % 365;
$h = ($subTime / (60 * 60)) % 24;
$m = ($subTime / 60) % 60;
?>

<?php
if ($this->session->userdata("site_currency") == "aud") {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price'] > 0) {
        echo "$" . number_format(($product['sale_price']), 2, '.', ',') . " AUD";
    } else {
        echo "$" . number_format(($product['price']), 2, '.', ',') . " AUD";
    }
} else {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price_usd'] > 0) {
        echo "$" . number_format(($product['sale_price_usd']), 2, '.', ',') . " USD";
    } else {
        echo "$" . number_format(($product['price_usd']), 2, '.', ',') . " USD";
    }
}
?><br>

<?php
if (( isset($product['bulk_price']) && $product['bulk_price'] != 0 ) || ( isset($product['bulk_price_usd']) && $product['bulk_price_usd'] != 0 )) {
    ?>

    Bulk Size Shipping: 
    <?php
    if ($this->session->userdata("site_currency") == "aud") {
        $bulk_price = number_format(($product['bulk_price'] * $product['qty']), 2, '.', '');
        echo "$" . number_format($bulk_price, 2, '.', ',') . " AUD";
    } else {
        $bulk_price_usd = number_format(($product['bulk_price_usd'] * $product['qty']), 2, '.', '');
        echo "$" . number_format($bulk_price_usd, 2, '.', ',') . " USD";
    }
    ?><br>
<?php } ?>

Sub Total: 
<?php
if ($this->session->userdata("site_currency") == "aud") {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price'] > 0) {
        $subtotal1 = number_format((($product['sale_price'] * $product['qty']) + ($product['bulk_price'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($subtotal1, 2, '.', ',') . " AUD";
    } else {
        $subtotal2 = number_format(($product['subtotal'] + ($product['bulk_price'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($subtotal2, 2, '.', ',') . " AUD";
    }
} else {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price_usd'] > 0) {
        $subtotal3 = number_format((($product['sale_price_usd'] * $product['qty']) + ($product['bulk_price_usd'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($subtotal3, 2) . " USD";
    } else {
        $subtotal4 = number_format(($product['subtotal_usd'] + ($product['bulk_price_usd'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($subtotal4, 2, '.', '') . " USD";
    }
}
?><br>