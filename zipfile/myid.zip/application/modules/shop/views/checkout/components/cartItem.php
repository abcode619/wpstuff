<?php if (!empty($product['image'])) : ?>
    <a href="<?php echo site_url($this->base_name . '/product/' . $product['slug']); ?>">
        <img src="<?php echo tt(site_url($product['image']), 164, 164, '&zc=2&q=100') ?>">
    </a>
<?php endif; ?>

<h4><?php echo $product['name']; ?></h4>

<!-- TODO: can only update quantityh on the first page -->
<?php if (!empty($product['qty'])) : ?>

    <select name="qty" class="quntity_select2" data-prid="<?= $product['id'] ?>" >
        <?php foreach (range(1, 10) as $value): ?>
            <?php if ($product['qty'] == (int) $value) : ?>
                <option selected value="<?= $value ?>">Qty: <?= $value ?></option>
            <?php else : ?>
                <option value="<?= $value ?>">Qty: <?= $value ?></option>
            <?php endif; ?>
        <?php endforeach; ?>
    </select>

    <input type="submit" data-prid="<?= $product['id'] ?>" value="Remove" class="remove-cart-item">                        

<?php endif; ?><br>

Product Type: <?php echo $product['price_name']; ?><br>

Each Product Price:
<?php
// process to add sale price in cart total if condition meets.
$date1 = strtotime($product['sale_end']);
$date2 = time();
$subTime = $date1 - $date2;
$y = ($subTime / (60 * 60 * 24 * 365));
$d = ($subTime / (60 * 60 * 24)) % 365;
$h = ($subTime / (60 * 60)) % 24;
$m = ($subTime / 60) % 60;
?>

<?php
if ($this->session->userdata("site_currency") == "aud") {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price'] > 0) {
        echo "$" . number_format(($product['sale_price']), 2) . " AUD";
    } else {
        echo "$" . number_format(($product['price']), 2) . " AUD";
    }
} else {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price_usd'] > 0) {
        echo "$" . number_format(($product['sale_price_usd']), 2) . " USD";
    } else {
        echo "$" . number_format(($product['price_usd']), 2) . " USD";
    }
}
?><br>

<?php
if (( isset($product['bulk_price']) && $product['bulk_price'] != 0 ) || ( isset($product['bulk_price_usd']) && $product['bulk_price_usd'] != 0 )) {
    ?>                
    Bulk Size Shipping: 
    <?php
    if ($this->session->userdata("site_currency") == "aud") {
        $bulk_price = number_format(($product['bulk_price'] * $product['qty']), 2, '.', '');
        echo "$" . number_format($bulk_price, 2) . " AUD";
    } else {
        $bulk_price_usd = number_format(($product['bulk_price_usd'] * $product['qty']), 2, '.', '');
        echo "$" . number_format($bulk_price_usd, 2) . " USD";
    }
    ?><br>
<?php } ?>

Sub Total: 
<?php
if ($this->session->userdata("site_currency") == "aud") {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price'] > 0) {
        $sub_total1 = number_format((($product['sale_price'] * $product['qty']) + ($product['bulk_price'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($sub_total1, 2) . " AUD";
    } else {
        $sub_total2 = number_format(($product['subtotal'] + ($product['bulk_price'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($sub_total2, 2) . " AUD";
    }
} else {
    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product['sale_price_usd'] > 0) {
        $sub_total3 = number_format((($product['sale_price_usd'] * $product['qty']) + ($product['bulk_price_usd'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($sub_total3, 2) . " USD";
    } else {
        $sub_total4 = number_format(($product['subtotal_usd'] + ($product['bulk_price_usd'] * $product['qty'])), 2, '.', '');
        echo "$" . number_format($sub_total4, 2) . " USD";
    }
}
?><br>