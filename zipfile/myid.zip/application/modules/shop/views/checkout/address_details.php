<?php $this->load->view($base_name . '/checkout/components/checkoutnav'); ?>

<div class="template-checkout" id="shippping-details">
    <!-- area -->
    <div class="template-checkout__main">

        <?php if ($message == "incorrect") { ?>                
            <p>You have entered incorrect details. Please try again or click <a href="/account/forgot_password">here</a> to recover your password.</p>
        <?php } elseif ($this->session->userdata('message') == "correct") { ?>
            <p>You have logged in successfully.</p>
            <?php
            $this->session->unset_userdata('message');
        } else {
            $errorData = validation_errors();
            if (!empty($errorData)) {
                echo '<div>';
                echo validation_errors('<div>', '</div>');
                echo '</div>';
            }
        }
        ?>

        <?php if ($this->config->item('login_module_in_checkout') && $this->session->userdata('email') == "") { ?>

                <h4>Already have an account ?</h4>
                <div>
                    <p>Enter your email address and password and we will fill your last billing and delivery 
                        address and apply any credit you have available to you. Earn credit when you refer paying customers! 
                        <a href="/account" class="text_undeline">Learn more here</a>.
                    </p>

                    <?php echo form_open("/shop/checkout/address_details", 'id="login_form"'); ?>                

                    <div>
                        <label><?php echo lang('login_identity_label', 'identity'); ?></label>
                        <?php echo form_input($identity); ?>
                    </div>

                    <div>
                        <label><?php echo lang('login_password_label', 'password'); ?></label>
                        <?php echo form_input($password); ?>
                    </div>

                    <!--<label style="width:60%;">Remember Me : </label>-->
                    <?php // echo form_checkbox('remember', '1', FALSE, 'id="remember"');     ?>

                    <div>
                        <?php echo form_submit('submit', lang('login_submit_btn'), 'class=""'); ?>                        
                        <?php echo form_close(); ?>
                    </div>
                </div>
                <hr>
                <?php
            }        
        ?>                    
        <br>        
        <?php
        
        if ($this->config->item('login_module_in_checkout')) {

            if ($this->session->userdata("email") == "") {
                ?>
                <h4>New Customer ? <a href="javascript:void(0)" class="show_billing">Click Here</a></h4>            
                <hr class="gry_bg">
                <?php
                if (!empty($shipping_details)) {
                    $form_style = "display: block";
                } else {
                    $form_style = "display: none";
                }
            } else {
                
            }
        } else {
            $form_style = "display: block";
        }
        ?>


        <form class="" method='post' action="/<?= $base_name ?>/checkout/address_details" id="billing_form" style="<?php echo $form_style; ?>">

            <h2>Shipping Address</h2>
            <p>Please provide the shipping address you would like your order posted to.</p>

            <input id="" type="text" name="s_firstname" placeholder="First Name"
                   value="<?= (isset($shipping_details['s_firstname']) ? $shipping_details['s_firstname'] : set_value('s_firstname')) ?>">
            <br>

            <input id="" type="text" name="s_lastname" placeholder="Last Name"
                   value="<?= (set_value('s_lastname') ? set_value('s_lastname') : (isset($shipping_details['s_lastname']) ? $shipping_details['s_lastname'] : '')) ?>">
            <br>

            <input id="" type="text" name="s_address_1" placeholder="Address Line 1"
                   value="<?= (set_value('s_address_1') ? set_value('s_address_1') : (isset($shipping_details['s_address_1']) ? $shipping_details['s_address_1'] : '')) ?>">
            <br>

            <input id="" type="text" name="s_address_2" placeholder="Address Line 2"
                   value="<?= (set_value('s_address_2') ? set_value('s_address_2') : (isset($shipping_details['s_address_2']) ? $shipping_details['s_address_2'] : '')) ?>">
            <br>

            <input id="" type="text" name="s_suburb" placeholder="Suburb"
                   value="<?= (set_value('s_suburb') ? set_value('s_suburb') : (isset($shipping_details['s_suburb']) ? $shipping_details['s_suburb'] : '')) ?>">
            <br>

            <input id="" type="text" name="s_postcode" placeholder="Postcode"
                   value="<?= (set_value('s_postcode') ? set_value('s_postcode') : (isset($shipping_details['s_postcode']) ? $shipping_details['s_postcode'] : '')) ?>">
            <br>

            <select id="country" name="s_country" class="" 
                    data-selected="<?= (set_value('s_country') ? set_value('s_country') : (isset($shipping_details['s_country']) ? $shipping_details['s_country'] : '')) ?>">               
            </select>
            <br>

            <select id="state" name="s_state" class="" 
                    data-selected="<?= (set_value('s_state') ? set_value('s_state') : (isset($shipping_details['s_state']) ? $shipping_details['s_state'] : '')) ?>">
            </select>
            <br>

            <input id="s_zmail" type="text" name="s_zmail" placeholder="Email Address"                          
            <?php
            if ($this->session->userdata("email") == "") {
                ?>
                       value="<?= (set_value('s_zmail') ? set_value('s_zmail') : (isset($shipping_details['s_zmail']) ? $shipping_details['s_zmail'] : '')) ?>"
                       <?php
                   } else {
                       ?>
                       value="<?php echo $this->session->userdata('email'); ?>" readonly="readonly"
                       <?php
                   }
                   ?>
                   >                
            <label id="already_registered" class="red_text" style="display: none;">You are already registered, please log in.</label>
            <br>

            <input id="" type="text" name="s_phone" placeholder="Phone Number"
                   value="<?= (set_value('s_phone') ? set_value('s_phone') : (isset($shipping_details['s_phone']) ? $shipping_details['s_phone'] : '')) ?>">
            <br>

            <textarea name="s_comments" placeholder="Delivery Comments (if required)"><?= (set_value('s_comments') ? set_value('s_comments') : (isset($shipping_details['s_comments']) ? $shipping_details['s_comments'] : '')) ?></textarea>
            <br>

            <div class="" id="billing-details-form">                
                <h4>Billing Address</h4>
                <p>Please provide the billing address as you would like it seen on the invoice.</p>
            </div>                    

            <!-- TODO: upon click insert form data from billing address -->
            <?php if (!isset($shipping_details['ShippingIsBilling'])) : ?>
                <label>
                    <input id="ShippingIsBillingAddressNew" type="checkbox" name="ShippingIsBilling" > My billing address is the same as my shipping address
                </label>
            <?php else : ?>
                <label>
                    <input id="ShippingIsBillingAddressNew" type="checkbox" name="ShippingIsBilling" checked> My shipping
                    address is the same as my billing address
                </label>
            <?php endif; ?>

            <!-- Group -->
            <div id="form-contents">

                <input id="" type="text" name="b_firstname" placeholder="First Name"
                       value= "<?= ((set_value('b_firstname') == '') ? (isset($billing_details['b_firstname']) ? $billing_details['b_firstname'] : '') : set_value('b_firstname')) ?>">
                <br>

                <input id="" type="text" name="b_lastname" placeholder="Last Name"
                       value="<?= (set_value('b_lastname') ? set_value('b_lastname') : (isset($billing_details['b_lastname']) ? $billing_details['b_lastname'] : '')) ?>">
                <br>

                <input id="" type="text" name="b_address_1" placeholder="Address Line 1"
                       value="<?= (set_value("b_address_1") ? set_value('b_address_1') : (isset($billing_details['b_address_1']) ? $billing_details['b_address_1'] : '')) ?>">
                <br>                    

                <input id="" type="text" name="b_address_2" placeholder="Address Line 2"
                       value="<?= (set_value('b_address_2') ? set_value('b_address_2') : (isset($billing_details['b_address_2']) ? $billing_details['b_address_2'] : '')) ?>">
                <br>

                <input id="" type="text" name="b_suburb" placeholder="Suburb"
                       value="<?= (set_value('b_suburb') ? set_value('b_suburb') : (isset($billing_details['b_suburb']) ? $billing_details['b_suburb'] : '')) ?>">
                <br>

                <input id="" type="text" name="b_postcode" placeholder="Postcode"
                       value="<?= (set_value('b_postcode') ? set_value('b_postcode') : (isset($billing_details['b_postcode']) ? $billing_details['b_postcode'] : '')) ?>">
                <br>

                <select id="country1" name="b_country" 
                        data-selected="<?= (set_value('b_country') ? set_value('b_country') : (isset($billing_details['b_country']) ? $billing_details['b_country'] : '')) ?>"
                        class=""
                        >
                </select>
                <br>

                <select id="state1" name="b_state" 
                        data-selected="<?= (set_value('b_state') ? set_value('b_state') : (isset($billing_details['b_state']) ? $billing_details['b_state'] : '')) ?>"
                        class=""
                        >
                </select>
                <br>

                <input id="b_zmail" type="text" name="b_zmail" placeholder="Email Address" 
                       value="<?= (set_value('b_zmail') ? set_value('b_zmail') : (isset($billing_details['b_zmail']) ? $billing_details['b_zmail'] : '')) ?>" >                        

                <input id="" type="hidden" name="email" class="honey">
                <br>

                <input id="" type="text" name="b_phone" placeholder="Phone Number"
                       value="<?= (set_value('b_phone') ? set_value('b_phone') : (isset($billing_details['b_phone']) ? $billing_details['b_phone'] : '')) ?>">
                <br>

            </div>

    </div>

</div>

<br>                

<div><button type="submit" name="billing_details" value="1" class="">DELIVERY DETAILS</button></div>

</form>            

</div>

<div class=" template-checkout__aside">
    <div class="" id="mini-template-order-summary"> </div>
    <?php $this->load->view('./widgets/sidebar/sidebar--link-list', array('sidebar_links__title' => $helpfulLinks__title, 'sidebar_links' => $helpfulLinks__nav_list,)); ?>
</div>

</div>

<script type="text/javascript">

    var counter = 0;

<?php if ($this->session->userdata("email") == "") { ?>

        $(document).ready(function() {

            populateCountries("country", "state");
            populateCountries("country1", "state1");

    <?php if ($this->config->item('login_module_in_checkout')) { ?>

                $("#s_zmail").on('blur', function() {
                    var email = $("#s_zmail").val();
                    var return_val = "yes";

                    $.ajax({
                        url: '/shop/check_registered_email',
                        type: 'post',
                        async: false,
                        data: {email: email},
                        success: function(msg) {
                            if (msg === "yes")
                            {
                                $("#s_zmail").val("");
                                $("#already_registered").css("display", "block");
                            } else {
                                return_val = "no";
                            }
                        }
                    });

                    if (return_val === "yes")
                    {
                        return false;
                    }

                });

                jQuery(document).on("keypress", "#s_zmail", function() {
                    $("#already_registered").css("display", "none");
                });

                jQuery(document).on("click", ".show_billing", function() {
                    $("#billing_form").toggle();
                    counter++;
                    if ((counter % 2) === 0) {
                        $("html, body").animate({scrollTop: 300}, 1000);
                    } else {
                        $("html, body").animate({scrollTop: 800}, 1000);
                    }
                });

    <?php } ?>

        });
<?php } ?>
</script>