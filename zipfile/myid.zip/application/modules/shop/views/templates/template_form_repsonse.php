<!-- Page Header -->
<? $this->load->view('./components/page/page-hd'); ?>

<!-- Wrap -->
<div class="site-wrap">

	<!-- template -->
	<div class="template-duo">

		<!-- area -->
		<div class="template-duo__main">

			<!-- Content -->
			<?=$content?>

		</div>

		<!-- area -->
		<div class="template-duo__aside">
			<ul class="list-of-items">
				<li>
					<!-- shoutbox -->
					<? $this->load->view('./widgets/shoutbox/shoutbox--newsletter-sign-up'); ?>
				<li>
					<!-- shoutbox -->
					<? $this->load->view('./widgets/shoutbox/shoutbox--question'); ?>
			<ul>
		</div>
	</div>
</div>