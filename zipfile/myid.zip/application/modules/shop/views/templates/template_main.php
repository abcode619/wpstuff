<!-- Page Header -->
<? $this->load->view('./components/page/page-hd'); ?>

<!-- Wrap -->
<!--<div class="site-wrap">-->
	
	<!-- Content -->
	<?=$content?>

<!--</div>-->