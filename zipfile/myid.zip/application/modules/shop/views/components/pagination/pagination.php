<!--<ul class="pagination">-->
<!--  <li><a href="#">&laquo;</a>-->
<!--  <li><a class="is-active" href="#">1</a>-->
<!--  <li><a href="#">2</a>-->
<!--  <li><a href="#">3</a>-->
<!--  <li><a href="#">4</a>-->
<!--  <li><a href="#">5</a>-->
<!--  <li><a href="#">&raquo;</a>-->
<!--</ul>-->

	<?= $this->pagination->create_links () ?>

