<a class="shoutbox shoutbox--viewcart eq-blocks" href="<?=$base_name?>/cart">
	<div class="shoutbox__wrap">		
		<span class="shoutbox__title">View Cart </span><i class="icon-cart"></i>
		<span class="shoutbox__text"><?= $view_cart_count ?> Items <?= $view_cart_total ?></span>
	</div>
</a>