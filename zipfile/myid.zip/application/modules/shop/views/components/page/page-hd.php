<?php // if (isset($page_title)) : ?>
<!--<div class="page-hd">
	<div class="page-hd__wrap  site-wrap">
		<h1 class="page-hd__title"><?=$page_title?></h1>

		<? if(isset($page_titlebar_nav)) :?>
		 menu right
		<ul class="page-nav__primary-menu2">
			<? foreach($page_titlebar_nav as $n) : ?>
			<li>
				<a class="<?=$n['class']?> <?=is_active($n['active'])?>" <?=(isset($n['custom'])? $n[ 'custom' ] :''); ?>  href="<?=$n['uri']?>"><?=isset($n['icon'])?$n['icon']:false?><span><?=$n['title']?></span></a>
			<? endforeach ?>
		</ul>
		<? endif ?>
	</div>
</div>-->
<?php // endif ?>
