<!-- page Nav -->
<div class="page-nav__primary">


	<!-- Information -->
	<div class="TabsContainer">
		<!-- the tabs -->
		<div class="TabsContainer-arrow">
			<nav class="TabsContainer-responsiveWrap">


	<div class="page-nav__primary__wrap">	

		<? if(isset($page_nav1)) :?>
		<!-- menu left -->
		<ul class="page-nav__primary-menu1">
			<? foreach($page_nav1 as $n) :
				$segment = (isset($n['segment'])? $n['segment']: 2)?>
			<li>
				<a class="<?=$n['class']?> <?=is_secondary_active($n['active'],$segment)?>" href="<?=$n['uri']?>"><?=$n['title']?></a>
			<? endforeach ?>
		</ul>
		<? endif ?>

		<? if(isset($page_nav2)) :?>
		<!-- menu right-->
		<ul class="page-nav__primary-menu2">
			<? foreach($page_nav2 as $n) : ?>
			<li>
				<a class="<?=$n['class']?> <?=is_active($n['active'])?>" href="<?=$n['uri']?>"><span><?=$n['title']?></span></a>
			<? endforeach ?>
		</ul>
		<? endif ?>
	</div>
	<nav></div></div>

	<? if (isset($page_subtitle)) : ?>
	<!-- This dsiplays the current selected page -->
	<h2 class="page-nav__primary__title"><?=$page_subtitle?></h2>
	<? endif ?>
</div>