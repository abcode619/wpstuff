<?php if(count($products) > 0 || !empty($products)) :   ?>
<?php foreach($products as $product) :  ?>
<li>
<a href="<?= site_url('/' . $base_name . '/product/' . $product->slug) ?>" class="box-primary eq-blocks">
<div class="box-primary__thumb">
<?php if(!empty($product->image)) :    ?>
                <img src="<?= tt(site_url($product->image), 300, 260, '&zc=2&q=100') ?>"
                     alt="<?= $product->image_alt_text ?>">
<?php endif;    ?>
</div>
<div class="box-primary__bd">
        <h2 class="box-primary__title ui-mb0"><?= $product->name ?></h2>

                                <p><?= $product->extract ?></p>
</div>
</a>
<?php endforeach    ?>
<?php else:    ?>
<p> NO Products </p>
<?php
 endif; ?>