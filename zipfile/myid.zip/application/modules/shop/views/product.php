<?php
$prices = $product->prices;
?>
<h1><?php echo $product->name; ?></h1>
<?php if (!empty($product->image)) { // Showing 1st image ?>               
    <li>
        <img src="<?php echo tt($product->image, 370, 370); ?>" alt="" class="img-responsive2">                        
    </li>
<?php } ?>
<?php if (!empty($product->image_1)) { // Showing 1st image ?>               
    <li>
        <img src="<?php echo tt($product->image_1, 370, 370); ?>" alt="" class="img-responsive2">
    </li>
<?php } ?>    
<?php if (!empty($product->image_2)) { // Showing 1st image ?>               
    <li>
        <img src="<?php echo tt($product->image_2, 370, 370); ?>" alt="" class="img-responsive2">
    </li>
<?php } ?>
<?php if (!empty($product->image_3)) { // Showing 1st image ?>               
    <li>
        <img src="<?php echo tt($product->image_3, 370, 370); ?>" alt="" class="img-responsive2">
    </li>
<?php } ?>
<?php if (!empty($product->image_4)) { // Showing 1st image ?>               
    <li>
        <img src="<?php echo tt($product->image_4, 370, 370); ?>" alt="" class="img-responsive2">
        <div class="bot_bg"><a href="<?php echo $product->image_4; ?>" class="fancybox"><i class="fa fa-expand"></i></a> </div>
    </li>
<?php } ?>    

<p>
    <?php
    $date11 = strtotime($product->sale_end);
    $date22 = time();
    $subTime = $date11 - $date22;
    $y = ($subTime / (60 * 60 * 24 * 365));
    $d = ($subTime / (60 * 60 * 24)) % 365;
    $h = ($subTime / (60 * 60)) % 24;
    $m = ($subTime / 60) % 60;

    if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product->min_sale_price > 0 && $product->min_sale_price_usd > 0) {
        ?>
        Product Status : On Sale
        <?php
    } else {
        
    }
    ?> 
</p>
<h6>
    <?php echo $product->extract; ?>
</h6>

<?php if ($product->stock != "Out of stock") { ?>

    <form method="post" action=''>
        <select name='size'>
            <?php foreach ($prices as $price) : ?>
                <option value="<?php echo $price->store_price_id; ?>">
                    <?php
                    if ($this->session->userdata("site_currency") == "aud") {
                        if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product->min_sale_price > 0) {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->sale_price . " AUD";
                        } else {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->price . " AUD";
                        }
                    } else {
                        if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $product->min_sale_price_usd > 0) {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->sale_price_usd . " USD";
                        } else {
                            echo $price->price_name;
                            ?> - <?php
                            echo '$' . $price->price_usd . " USD";
                        }
                    }
                    ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name='size' id="select_quantity" class="quntity_select">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
        </select>

        <input type="button" id="product_submit" value="Add to Cart" onclick="addToCart(<?php echo $product->store_product_id; ?>,<?php echo $prices[0]->store_price_id; ?>)" />
    </form>

    <script type="text/javascript">
        jQuery(document).on("change", ".quntity_select", function() {
            var prd_id = <?php echo $product->store_product_id; ?>;
            var price_id = $(".quntity_select").val();
            $("#product_submit").attr("onclick", "addToCart(" + prd_id + "," + price_id + ")");
        });
    </script>

<?php } else { ?>
    <h6 class="red_text">Out Of Stock!</h6>
<?php } ?>

<!--</div>-->
<p><strong>Please note:</strong> You can choose your currency at checkout.</p>
<!--</div>-->
<br class="clear">

<?php if ($product->social_sharing == "1") { ?>

    <div class="col-md-12 padi0">
        <!-- AddThis Button BEGIN -->
        <div class="addthis_toolbox addthis_default_style addthis_32x32_style">
            <a class="addthis_button_preferred_1"></a>
            <a class="addthis_button_preferred_2"></a>
            <a class="addthis_button_preferred_3"></a>
            <a class="addthis_button_preferred_4"></a>
            <a class="addthis_button_compact"></a>
            <a class="addthis_counter addthis_bubble_style"></a>
        </div>
        <script type="text/javascript">var addthis_config = {"data_track_addressbar": true};</script>
        <script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-538d8de6113b6dd2"></script>
        <!-- AddThis Button END -->
    </div>

<?php } ?>

<br class="clear">

<?php echo $product->primary_description; ?>

<?php if ($product->comments == "1") { ?>

    <div id="disqus_thread"></div>
    <script type="text/javascript">
            /* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
            var disqus_shortname = 'orgoneenergy'; // required: replace example with your forum shortname

            /* * * DON'T EDIT BELOW THIS LINE * * */
            (function() {
                var dsq = document.createElement('script');
                dsq.type = 'text/javascript';
                dsq.async = true;
                dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
            })();
    </script>
    <noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<?php } ?> 