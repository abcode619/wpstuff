<?php

	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */

	if (!defined ('BASEPATH'))
{
	exit('No direct script access allowed');
}

	if (!function_exists ('MoneyFormat'))
	{
		/**
		 * returns absolute asset path
		 */
		function MoneyFormat ($value)
		{
			$value = (int)$value;
			setlocale (LC_MONETARY, 'en_AU');
//			 echo  ''.money_format ('%(#3n', $value);
                         echo  ''.$value;
		}
	}

	if (!function_exists ('DisplayClass'))
	{
		/**
		 * returns absolute asset path
		 */
		function DisplayClass ($value,$current)
		{

			if ($value == $current)
			{
				return "isCurrent";
			}else{
			$menu = array ( 'cart',
			                'address_details',
			                'shipping_details',
			                'payment_and_summary',
			                'order_completed' );
           //$value = end ($this->uri->segment_array ());
			$c = array_search ($current, $menu);
			$k = array_search ($value, $menu);
             if($c > $k ){
			 foreach($menu as $key=>$link){
				 if($key > $k && $key != $k){
					return "isComplete";
				 }

			 }
             }
			}


		}
	}
