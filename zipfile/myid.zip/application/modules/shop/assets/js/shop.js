
//JQUERY functions
var base_name = 'shop';

function qty_update($product_id, $qty) {
    return $.post(base_name + "/qty_update", {id: $product_id, qty: $qty}, "json");
}

function update_displaying_cart() {
    return $.post(base_name + "/update_displaying_cart", "json");
}

function check_coupon_code($code) {
    $("#referral_loading").css("display", "block");
    return $.post(base_name + "/check_coupon_code", {code: $code}, "json");
}

function get_mini_order_summary() {
    return $.post('/' + base_name + "/get_mini_order_summary", "json");
}

function check_shipping_details() {
    return $.post('/' + base_name + "/check_shipping_options", "json");
}

function get_shipping_options() {
    return $.post('/' + base_name + "/get_shipping_options", "json");
}

function apply_shipping_pickup_options() {
    return $.post('/' + base_name + "/apply_shipping_pickup_options", "json");
}

function get_billing_and_shipping_details() {
    $.ajax({
        type: "POST",
        url: '/' + base_name + "/get_billing_and_shipping_details",
        dataType: "json",
        async: false,
        success: function(data) {
            $('#billing_and_shipping_info').html(data.results);
        }
    });
    /* Added By chintan reson : For making this ASYNC false in AJAX request handaling to prevent getting older cart object value*/
    //return $.post('/'+base_name +"/get_billing_and_shipping_details", "json");
}

function remove_cart_item($product_id) {
    return $.post(base_name + "/qty_update", {id: $product_id, qty: 0}, "json");
}


// On page load init

$(window).load(function() {


    // $("#tabs").tabs();
    //$("ul.tabs").tabs("div.panes > div", {
    //    current: 'isCurrent'
    //});

    // cart
    var $cartDiv = $('#maincart');
    // mini order summary - side bar with countries
    var $miniOrderSummary = $('#mini-template-order-summary');
    //  if shipping detils page
    var $shipping_details_page = $('#shippping-details');

    // mini order summary with payemtn summary
    var $miniOrderSummary_payment_summary = $('#mini-template-order-summary-payment-summary');
    //  display  billing and shipping info
    var $billing_and_shipping_info = $('#billing_and_shipping_info');


    // location : shipping details

    setTimeout(function() {

        if ($('#ShippingIsBillingAddress').is(':checked')) {
            $("#country").next('div').css('pointer-events', 'none');
            $("#state").next('div').css('pointer-events', 'none');
        } else {
            $("#country").next('div').removeAttr('style');
            $("#state").next('div').removeAttr('style');
        }

        if ($('#ShippingIsBillingAddressNew').is(':checked')) {
            $("#form-contents").css("display", "none");
        } else {
            $("#form-contents").css("display", "block");
        }

    }, 3000);



    $("#ShippingIsBillingAddressNew").click(function() {

        if ($('#ShippingIsBillingAddressNew').is(':checked')) {
            $("#country").next('div').css('pointer-events', 'none');
            $("#state").next('div').css('pointer-events', 'none');
        } else {
            $("#country").next('div').removeAttr('style');
            $("#state").next('div').removeAttr('style');
        }

    });

    // Location : shipping details

    $('#ShippingIsBillingAddressNew').on('click', function() {
        if ($(this).is(':checked')) {
            $("#form-contents").slideUp("slow", function() {
                // Animation complete.
//                $("#billing-details-form")[0].submit();
                // TODO : make a ajax function to handel this form -- more seriabble feature but runs with php rediection now
            });
        } else {
            $('#billing-details-form input[type="text"]').removeAttr('readonly');
            $('#billing-details-form input[type="text"]').val('');
            $('#billing-details-form select').removeAttr('disabled'); // apply read only if shipping  address is same as billing
            $("#form-contents").slideDown("slow", function() {
                // Animation complete.
            });
        }

    });

    // shipping options
    // just  checks if shipping details are avaliable if yes - apply shipping options
    if ($shipping_details_page.length) {
        var is_shipping_avaliable = check_shipping_details();
        is_shipping_avaliable.success(function(data)
        {
            var data = $.parseJSON(data);
            if (data.code == '201')
            {
                shipping_options('callme');  // need not call the miniorder summary function hence true is sent
            }
            if (data.code == '403') {
                miniordersummary();
            }

        });
    }

    // get the  shipping options and based on the value passsed - call the miniorder summary function s
    function shipping_options($value) {
        var options = get_shipping_options();
        options.success(function(data) {
            var data = $.parseJSON(data);
            console.log(data);
            if (data.code == '201') {

                $('#shipping-options').html(data.results[0]);
                //call pickup var so that checkbox click js is  in dome s
                pickuporder();
                // ony call if $value is false
                if ($value == 'callme') {
                    miniordersummary();
                }
                // rendering thed data to html

            }
        });
    }

    if ($('#pickup-order').is(':checked')) {
        console.log("checked");
        $('#billing-details-form').css('display', 'none');
    } else {
        $('#billing-details-form').css('display', 'block');
    }

    var pickuporder = function() {

        //This was add just to hide billing details form once  pick up is selected   --  TODO: move this button to more appropriate place -- stupid to be in here
        if ($('#pickup-order').is(':checked')) {
            $('#billing-details-form').parent('div').css('display', 'none');
            $('#shipping-options').append("<a href= /" + base_name + "/checkout/payment_and_summary ><button class='btn' id='shipping-btn'><span>Continue to Payment </span><i></i></button></a>");
        } else {
            $('#billing-details-form').parent('div').css('display', 'block');

        }

        $('#pickup-order').on('click', function(event) {
            event.preventDefault();

            // Once its clicked
            var options = apply_shipping_pickup_options();
            options.success(function(data) {
                var data = $.parseJSON(data);
                if (data.code == '201') {

                    shipping_options('callme'); // calling shipping with false so that I  call miniordersummay function  and reload the data
                }
            });

        });
    }


    if ($cartDiv.length) {
        // always call cart function
        var cart = function() {
            var globalobj = update_displaying_cart();
            globalobj.success(function(data) {

                var data = $.parseJSON(data);
                if (data.code == '403') {
                    window.location.replace("/" + base_name);
                }
                //$('.template-checkout').slideUp("slow");

                $('.template-checkout__main').html(data.results.cart);
                $('.template-checkout__aside').html(data.results.ordersummary);
                removeItem();
                // $('.template-checkout').slideDown("slow");
                updatecartqty();
                couponcode();
            });
        }

        cart(); // called gloabally

        //Main  functions
        function couponcode() {
            $('#couponsub').on('click', function(e) {
                e.preventDefault();
                var code = $('#shop-coupon-code').val();

                var ptag = $(this).parent('div').next('p');
                if (code == '') {
                    $("#referral_failure").html('You must enter something before we can apply !!!');

                    $("#referral_failure").show();

                    setTimeout(function() {
                        $("#referral_failure").fadeOut(2000);
                    }, 2000);

                    // out put message error -- need to enter something before I can apply !!!
                } else {
                    //  Entered Some data
                    // Check the code from db
                    var obj = check_coupon_code(code);

                    obj.success(function(data) {

                        $("#referral_loading").css("display", "none");

                        console.log(data);
                        var data = $.parseJSON(data);
                        if (data.code == '201') {//
                            cart();
                            // $.when(ptag.fadeOut(1000)).done(function () {cart(); }); // when and done function
                        }
                        else if (data.code == '403') {
                            $("#referral_failure").html(data.message);
                            $("#referral_failure").show();
                        } else {

                        }

                        setTimeout(function() {
                            $("#referral_failure").fadeOut(2000);
                        }, 2000);

                    });
                    obj.fail(function(data) {
                        $("#referral_loading").css("display", "none");
                        console.log('failed');
                        $("#referral_failure").html("Coupon not valid or Expried");

                        $("#referral_failure").show();
                        setTimeout(function() {
                            $("#referral_failure").fadeOut(2000);
                        }, 2000);

                    }); // end db che ck
                }
            });
        } // end  couponcdoe

        // Update cart qty on page cart
        function updatecartqty() {
            $('select[name="qty"]').on('change', function(e)
            {
                e.preventDefault();

                var id = $(this).data('prid');
                var qty = $(this).val();

                var obj = qty_update(id, qty);
                obj.success(function(data) {
                    cart(); // calling cart gloabaly
                });
                obj.fail(function(data) {
                    console.log('failed');
                });

            });
        } //  end update cartqty

        function removeItem() {
            $('.remove-cart-item').on('click', function(e) {
                e.preventDefault();
                var id = $(this).data('prid');

                var obj = remove_cart_item(id);
                obj.success(function(data) {
                    cart(); // calling cart gloabaly
                });
                obj.fail(function(data) {
                    console.log('failed');
                });

            });
        } //   remove cart Item

    }// end main cart

    // Mini order summary function
    var miniordersummary = function() {
        var globalobj = get_mini_order_summary();

        globalobj.success(function(data) {
            //prar();                
            var data = $.parseJSON(data);
            $('#mini-template-order-summary').parent('div').slideUp("slow");
            $('#mini-template-order-summary').html(data.results.miniordersummary);
            $('#mini-template-order-summary').parent('div').slideDown("slow");

        });
    }


    if ($miniOrderSummary.length) {
        //populateCountries("country", "state");
        if ($shipping_details_page.length == 0) { //  this function is manually called in  shipping details page  after some other functions
            miniordersummary(); // always call mini order summary
        }

    }

    //  billing and shipping info
    if ($billing_and_shipping_info.length) {
        var $obj = get_billing_and_shipping_details();

        /*Commented By Chintan **bellow code is written in actual ajax request Success event please go through it */

        /*        $obj.success(function(data){
         var data = $.parseJSON(data);
         //            alert(data.results);
         $('#billing_and_shipping_info').html(data.results);
         });
         */
    }


    if ($miniOrderSummary_payment_summary.length) {
        //TODO : ref this  to one  function
        var globalobj = get_mini_order_summary();
        globalobj.success(function(data) {
            //prar();
            var data = $.parseJSON(data);
            $('#mini-template-order-summary-payment-summary').parent('div').slideUp("slow");
            $('#mini-template-order-summary-payment-summary').html(data.results.miniordersummary);
            $('#mini-template-order-summary-payment-summary').parent('div').slideDown("slow");

        });
    }

    // Credit card validation
    // credit card validation
    $('#card_number').validateCreditCard(function(e) {
        return $("#card_number").removeClass(), null == e.card_type ? void $(".vertical.maestro").slideUp({
            duration: 200
        }).animate({
            opacity: 0
        }, {
            queue: !1,
            duration: 200
        }) : ($("#card_number").addClass(e.card_type.name), "maestro" === e.card_type.name ? $(".vertical.maestro").slideDown({
            duration: 200
        }).animate({
            opacity: 1
        }, {
            queue: !1
        }) : $(".vertical.maestro").slideUp({
            duration: 200
        }).animate({
            opacity: 0
        }, {
            queue: !1,
            duration: 200
        }), e.length_valid && e.luhn_valid ? $("#card_number").addClass("valid") : $("#card_number").removeClass("valid"))
    }, {
        accept: ["visa", "visa_electron", "mastercard", "maestro", "discover"]
    });


});

//Added By Hardik Sonchhabda

function calculateExtraCost(id)
{
    if ($("#extra_charge_" + id).is(':checked')) {
        var todo = "push";  // checked
    }
    else {
        var todo = "pop";  // unchecked
    }

    $.ajax({
        type: "POST",
        url: "/shop/calculate_extra_order_costs",
        data: {todo: todo, id: id},
        dataType: "html",
        beforeSend: function(xhr) {

        },
        success: function(result) {
            // location.reload();
            get_billing_and_shipping_details();
            local_getMiniOrderSummary();
        }
    });

}
function local_getMiniOrderSummary()
{
    $.ajax({
        type: "POST",
        url: '/' + base_name + "/get_mini_order_summary",
        dataType: "json",
        async: false,
        success: function(data) {
            $('#mini-template-order-summary-payment-summary').parent('div').slideUp("slow");
            $('#mini-template-order-summary-payment-summary').html(data.results.miniordersummary);
            $('#mini-template-order-summary-payment-summary').parent('div').slideDown("slow");

            var amount = $(".grand_amount").text();
            $(".process_transaction1").html("By processing this transaction, you agree to the <a href='/page/terms-and-conditions' target='_blank'><u>terms and conditions</u></a> of this website and agree that your PayPal account will be charged " + amount + " inc GST.");
            $(".process_transaction2").html("By processing this transaction, you agree to the <a href='/page/terms-and-conditions' target='_blank'><u>terms and conditions</u></a> of this website and agree that your creditcard will be charged " + amount + " inc GST.");
            $(".process_transaction3").html("Use of direct deposit is only for those who do not have Credit Card or PayPal payment options. Please note orders can take longer to process while we wait for payment through this method. You will be notified of bank details once the order has been placed.You will be charged " + amount + " inc GST.");

        }
    });
}

function change_shipping_method(id)
{
    $.ajax({
        type: "POST",
        url: "/shop/change_shipping_costs",
        data: {id: id},
        dataType: "html",
        beforeSend: function(xhr) {

        },
        success: function(result) {
            if (result === 'yes') {
                check_shipping_details();
                get_shipping_options();
                local_getMiniOrderSummary();
                update_page_info();
            } else {

            }
        }
    });

}
function local_getMiniOrderSummary()
{
    $.ajax({
        type: "POST",
        url: '/' + base_name + "/get_mini_order_summary",
        dataType: "json",
        async: false,
        success: function(data) {
            $('#mini-template-order-summary').parent('div').slideUp("slow");
            $('#mini-template-order-summary').html(data.results.miniordersummary);
            $('#mini-template-order-summary').parent('div').slideDown("slow");

            var amount = $(".grand_amount").text();
            $(".process_transaction").html("By processing this transaction, you agree to the <a href='/terms' target='_blank'>terms and conditions</a> of this website and agree that your creditcard will be charged " + amount + " inc GST.");

        }
    });
}
function update_page_info()
{
    $.ajax({
        type: "POST",
        url: '/' + base_name + "/update_delivery_options_info",
        async: false,
        success: function(data) {
            $("#shipping_dynamic_message").html("");
            $("#shipping_dynamic_message").html(data);
        }
    });
}