<?php
    /**
     *  Author : jay kora
     *  Email : kora.jayaram@gmail.com
     *  Company : Iddigital
     */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

//include_once ('shop_controller.php');

class Checkout extends MY_Controller
{

    var $base_name;

    public function __construct()
    {
        parent::__construct();

        # added this for all checkout urls should  have  htttps://
        # $this->ssl();

        $this->load->helper('language');
        $this->lang->load('shop');
        $this->load->config('shop_config');

        # cart variable
        $this->base_name = 'shop'; // replace this
        $this->data['base_name'] = $this->base_name; // this has to go ...I dont know Y its still there
        # Javascaript
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/shop.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/selectionCountry.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardValidator.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardTypeDetector.js'));

        # css
        $this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/css/store.css'));
        $this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/creditCardTypeDetector.css'));

        $this->load->model('idstore');
        $this->load->model('cart');
        $this->data['errors'] = array();
        $this->load->helper('jai'); // module helper
        # Loading helpers
        $this->load->helper(array('form',
            'url'));
        $this->load->library('form_validation');


        # Template
        $this->template->set_inner('templates/template_main');

        # Variables
        $this->data['page_title'] = 'Checkout';

        # Helpful links
        $this->data['helpfulLinks__title'] = 'Your order details are safe';
        $this->data['helpfulLinks__nav_list'] = array(
            array(
                'title' => 'Shipping Information',
                /* 'extra' => 'Learn more', */
                'uri' => site_url('/'),
            ),
            array(
                'title' => 'Privacy & Refund Policy',
                /* 'extra' => 'Learn more', */
                'uri' => site_url('/'),
            ),
            array(
                'title' => 'Terms & Conditions',
                /* 'extra' => 'Learn more', */
                'uri' => site_url('/'),
            ),
        );

        $this->data['page_title'] = lang('page title checkout');
        $this->data['breadcrumbs']["/" . $this->base_name] = ucfirst($this->base_name);
        $this->data['breadcrumbs']["/" . $this->base_name . '/checkout/address_details'] = ucfirst('chekcout');

        # Auth Login
        $this->load->library('../ion_auth');
        $this->load->library('form_validation');
        $this->load->helper('url');

        $this->load->database();

        $this->form_validation->set_error_delimiters($this->config->item('error_start_delimiter', 'ion_auth'), $this->config->item('error_end_delimiter', 'ion_auth'));

        $this->lang->load('../auth');
        $this->load->helper('./language');

        # sprintf(lang('welcome title'), 'jai'));
    }

    public function index()
    {
        # Template
        $this->template->add_page($this->base_name . '/checkout/index');


        //	$this->template->append_title($this->data['brand']->name);
        //	$this->template->append_title('Shop Online');
        //	$this->data['breadcrumbs']["/" . $this->data['base_name'] . "/brand/$slug"] = $this->data['brand']->name;
        # Render the goods
        $this->template->render($this->data);
    }

    /*
     * Displays cart Shipping - Billing and Login Form details
     * @param null $errors
     */

    public function Address_details()
    {

        if (!$this->ion_auth->logged_in()) { # Only if user is not looged in
            $post = $this->input->post();

            if ($post['submit'] == "Login") {
                # validate form input
                $this->form_validation->set_rules('identity', 'Identity', 'required');
                $this->form_validation->set_rules('password', 'Password', 'required');
            }

            if ($this->form_validation->run() == true) {
                # check to see if the user is logging in
                # check for "remember me"
                $remember = (bool) $this->input->post('remember');

                if ($this->ion_auth->login($this->input->post('identity'), $this->input->post('password'), $remember)) {
                    # if the login is successful
                    # redirect them back to the home page
                    # unsetting billing & shipping array if someone have inserted something there and then get logged in
                    $check_if_set_shipping = $this->session->userdata['cart_contents']['shipping'];
                    $check_if_set_billing = $this->session->userdata['cart_contents']['billing'];

                    if (!empty($check_if_set_shipping) || !empty($check_if_set_billing)) {
                        unset($this->session->userdata['cart_contents']['billing']);
                        unset($this->session->userdata['cart_contents']['shipping']);
                    }

                    # $this->session->set_flashdata('message', $this->ion_auth->messages());
                    $this->session->set_userdata('message', 'correct');

                    redirect('/shop/checkout/address_details', 'refresh');
                } else {
                    # if the login was un-successful
                    # redirect them back to the login page
                    # $this->session->set_flashdata('message', $this->ion_auth->errors());
                    $this->session->set_flashdata('message', "incorrect");
                    redirect('/shop/checkout/address_details', 'refresh'); //use redirects instead of loading views for compatibility with MY_Controller libraries
                }
            } else {
                # the user is not logging in so display the login page
                # set the flash data error message if there is one
                $this->data['message'] = (validation_errors()) ? validation_errors() : $this->session->flashdata('message');

                $this->data['identity'] = array('name' => 'identity',
                    'id' => 'identity',
                    'type' => 'text',
                    'value' => $this->form_validation->set_value('identity'),
                );
                $this->data['password'] = array('name' => 'password',
                    'id' => 'password',
                    'type' => 'password',
                );
            }
        }

        ## PRIMARY CONSIDERED AS BILLING DEATILS - this name makes more sense
        ## TODO : problem with form - set_value -- as we store billing details in session - when a user is  back again on address details page, he will  and leave a empty field ,  its loads up with session value

        $post = $this->input->post(); //  getting the post data

        if ($post && $post['billing_details'] == "1") {
            # check for email Honey pot - currently email field will be null
            if ($post['email'] != '') {
                echo "hi bot";
                die(); // check the robot
            }

            # Form validation  rules
            $this->form_validation->set_rules('s_firstname', 'Shipping - First name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('s_lastname', 'Shipping - Last Name ', 'trim|required');
            $this->form_validation->set_rules('s_address_1', 'Shipping - Address', 'trim|required');
            $this->form_validation->set_rules('s_country', 'Shipping - Country', 'trim|required');
            $this->form_validation->set_rules('s_state', 'Shipping - State', 'trim|required');
            $this->form_validation->set_rules('s_phone', 'Shipping - Phone', 'trim|required');
            $this->form_validation->set_rules('s_postcode', 'Shipping - PostCode', 'trim|required|alpha_numeric');
            $this->form_validation->set_rules('s_suburb', 'Shipping - Suburb', 'trim|required');
            $this->form_validation->set_rules('s_zmail', 'Shipping - Email', 'trim|required|valid_email');



            if ($this->form_validation->run() == false) {
                # validation  failed hence loads default  templete with error's
            } else {
                # validation success
                # send sanatize data to save

                $shipping_details = array(
                    "ShippingIsBilling" => $post['ShippingIsBilling'],
                    "s_firstname" => $post['s_firstname'],
                    "s_lastname" => $post['s_lastname'],
                    "s_address_1" => $post['s_address_1'],
                    "s_address_2" => $post['s_address_2'],
                    "s_suburb" => $post['s_suburb'],
                    "s_postcode" => $post['s_postcode'],
                    "s_country" => $post['s_country'],
                    "s_state" => $post['s_state'],
                    "s_zmail" => $post['s_zmail'],
                    "s_phone" => $post['s_phone'],
                    "s_comments" => $post['s_comments']
                );

                $save_shipping = $this->cart->save_cart_shipping_details($shipping_details);

                if ($save_shipping) {

                    # Shipping Details saved, now it's turn of Billing details
                    if (isset($post['ShippingIsBilling'])) {

                        $billing_details = array(
                            "b_firstname" => $post['s_firstname'],
                            "b_lastname" => $post['s_lastname'],
                            "b_address_1" => $post['s_address_1'],
                            "b_address_2" => $post['s_address_2'],
                            "b_suburb" => $post['s_suburb'],
                            "b_postcode" => $post['s_postcode'],
                            "b_country" => $post['s_country'],
                            "b_state" => $post['s_state'],
                            "b_zmail" => $post['s_zmail'],
                            "b_phone" => $post['s_phone']
                        );
                    } else {

                        # Form validation  rules
                        $this->form_validation->set_rules('b_firstname', 'Billing - First name', 'trim|required|xss_clean');
                        $this->form_validation->set_rules('b_lastname', 'Billing - Last Name ', 'trim|required');
                        $this->form_validation->set_rules('b_address_1', 'Billing - Address', 'trim|required');
                        $this->form_validation->set_rules('b_country', 'Billing - Country', 'trim|required');
                        $this->form_validation->set_rules('b_state', 'Billing - State', 'trim|required');
                        $this->form_validation->set_rules('b_phone', 'Billing - Phone', 'trim|required');
                        $this->form_validation->set_rules('b_postcode', 'Billing - PostCode', 'trim|required|alpha_numeric');
                        $this->form_validation->set_rules('b_suburb', 'Billing - Suburb', 'trim|required');
                        $this->form_validation->set_rules('b_zmail', 'Billing - Email', 'trim|required|valid_email');

                        if ($this->form_validation->run() == false) {
                            # Goes to  load template default
                        } else {
                            $billing_details = array(
                                "b_firstname" => $post['s_firstname'],
                                "b_lastname" => $post['s_lastname'],
                                "b_address_1" => $post['s_address_1'],
                                "b_address_2" => $post['s_address_2'],
                                "b_suburb" => $post['s_suburb'],
                                "b_postcode" => $post['s_postcode'],
                                "b_country" => $post['s_country'],
                                "b_state" => $post['s_state'],
                                "b_zmail" => $post['s_zmail'],
                                "b_phone" => $post['s_phone']
                            );
                        }# end validation
                    }

                    $save_billing = $this->cart->save_cart_billing_details($billing_details);
                    # saving data to cart
                    if ($save_billing) {
                        # data saved                         
                        redirect('/' . $this->base_name . '/checkout/shipping_options');
                    }
                }
            }
        }

        # Template
        $this->template->add_page($this->base_name . '/checkout/address_details');

        # Only first time this will be called if a user is logged in
        # When user gets logged in, coz we have unset both session variables in login process

        $checkSessionShipping = $this->session->userdata['cart_contents']['shipping'];
        $checkSessionBilling = $this->session->userdata['cart_contents']['billing'];

        if (isset($this->session->userdata) && $this->session->userdata('email') != "" && empty($checkSessionBilling) && empty($checkSessionShipping)) {
            $shippingData = $this->cart->save_cart_shipping_details_default();
            $this->data['shipping_details'] = $shippingData;

            $billingData = $this->cart->save_cart_billing_details_default();
            $this->data['billing_details'] = $billingData;
        } else {
            # Variables
            # On page Load chacking the cart - billing details if they are entered - then  load them up

            if ($this->cart->get_details('shipping') != false) {
                $this->data['shipping_details'] = $this->cart->get_details('shipping');
            }

            if ($this->cart->get_details('billing') != false) {
                $this->data['billing_details'] = $this->cart->get_details('billing');
            }
        }

        # meta title  & Desc
        $this->template->meta['title'] = lang('page meta title address details');
        $this->template->meta['description'] = lang('page meta description address details');

        # Render the goods
        $this->template->render($this->data);
    }

    /*
     * Displays cart Shipping Delivery Options
     * @param null $errors
     */

    public function Shipping_options()
    {
        $post = $this->input->post();
        if (!empty($post)) {
            $redirect = $this->base_name . '/checkout/shipping_options';
            redirect($redirect, 'refresh');
        }

        # Template
        $this->template->add_page($this->base_name . '/checkout/shipping_options.php');

        # Getting extraa charges details.
        $this->data['extra_charges'] = $this->idstore->getAllExtraCharges();

        # meta title  & Desc
        $this->template->meta['title'] = lang('page meta title shipping details');
        $this->template->meta['description'] = lang('page meta description shipping details');

        # Render the goods
        $this->template->render($this->data);
    }

    /*
     * Displays cart Payment and summary options
     * @param null $errors
     */

    public function Payment_and_summary($errors = NULL)
    {
        # need to check if all details are being filled
        if (!$this->cart->cart_check()) {
            redirect($this->base_name);
        }

        if (!$this->cart->get_details('billing')) {
            redirect($this->base_name . '/checkout/address_details');
        }

        if (!$this->cart->get_details('shipping')) {
            redirect($this->base_name . '/checkout/shipping_details');
        }

        $post = $this->input->post();

        if ($post && empty($errors)) {
            $this->form_validation->set_rules('card_name', 'Card Name', 'trim|required|xss_clean');
            $this->form_validation->set_rules('cc_number', ' Card Number', 'trim|required|xss_clean');
            $this->form_validation->set_rules('month', 'Month', 'trim|required');
            $this->form_validation->set_rules('year', 'year', 'trim|required|numeric'); //  earlier year option will not be displayed
            $this->form_validation->set_rules('cvv', 'CVV', 'trim|required|numeric|min_length[3]|max_length[4]');

            // Custom validations - for credit card number  and other stuff
            $errors = array();
            // Remove whitespaces
            $cc_number = preg_replace('/\s+/', '', $post['cc_number']);
            // check if its a inti
            if (!preg_match("/^[0-9 ]*$/", $cc_number)) {
                $errors[] = "<p>Credit Card number should be a Number.</p>"; // always wrap error message in p tag as html string is appended
            }
            // check for Month  and Year
            if ($this->form_validation->run() == false && count($errors > 0)) {
                $validation_errors = '';
                if (count($errors) > 0) {
                    foreach ($errors as $error) {
                        $validation_errors .= $error . validation_errors();
                    }
                } else { // if  only ci validation errors
                    $validation_errors .= validation_errors();
                }

                $this->data['validation_errors'] = $validation_errors;
            } else {
                $this->Order_completed($post); # Incase if payment is done via credit card.
                return;
            }
        }

        # Errors
        if (!empty($errors)) {
            foreach ($errors as $error) {
                $this->data['validation_errors'] = '<p>' . $error . '</p>';
            }
        }

        # Loading the cart to display
        $this->data['cart'] = $this->cart->get();

        $cart_grand_total = $this->cart->get_cart_total_after_discount();

        if ($this->session->userdata("site_currency") == "aud") {
            $cart_total = $this->cart->get_cart_total();
        } else {
            $cart_total = $this->cart->get_cart_usd_total();
        }

        if ($this->session->userdata('is_wholesaler') == "1") {
            $wholesaler_amount = number_format((($cart_total * WHOLESALER_DISCOUNT) / 100), 2, '.', '');
            $cart_grand_total = number_format(($cart_grand_total - $wholesaler_amount), 2, '.', '');
        } else {
            $cart_grand_total = $cart_grand_total;
        }
        $this->session->set_userdata('grand_total_cart', $cart_grand_total);

        # Template
        $this->template->add_page($this->base_name . '/checkout/payment_and_summary.php');

        # meta title  & Desc
        $this->template->meta['title'] = lang('page meta title payment summary');
        $this->template->meta['description'] = lang('page meta description payment summary');

        # Render the goods
        $this->template->render($this->data);
    }

    /*
     * Function used to make payment through Paypal - need to make modifications accordingly
     * @param null $errors
     */

    public function Paypal()
    {
        $complete_cart = $this->mycart->completecontents();
        $cart = $this->mycart->contents();

        # TODO : verify cart products total is equal to cart session total value
        # TODO :  -  Check for paymemt way if valid or not display relevent errors
        $cart_grand_total = number_format($this->cart->get_cart_total_after_discount(), 2, '.', '');

        if ($this->session->userdata("site_currency") == "aud") {
            $currency = "AUD";
            $cart_total = $this->cart->get_cart_total();
        } else {
            $currency = "USD";
            $cart_total = $this->cart->get_cart_usd_total();
        }

        # putting condition here to give 1 time 30% discount to the user if he is a wholesaler type.
        # Discount is being count on only total of all products rather than the final amount.
        # Final Amount is in $cart_grand_total variable.

        if ($this->session->userdata('is_wholesaler') == "1") {
            $wholesaler_amount = number_format((($cart_total * WHOLESALER_DISCOUNT) / 100), 2, '.', '');
            $cart_grand_total = number_format(($cart_grand_total - $wholesaler_amount), 2, '.', '');
        } else {
            $wholesaler_amount = "0.00";
            $cart_grand_total = $cart_grand_total;
        }

        # This part is done to check whether there is any credit amount available for this user or not
        # If so, reducing it from the original total and will update this user's credit amount to 0.00
        # deducting amount from grand total

        $user_id = $this->session->userdata('user_id');
        if (!empty($user_id)) {
            $cart_grand_total = number_format(($cart_grand_total - $this->session->userdata('current_credit')), 2, '.', '');
        }

        // echo $cart_grand_total;             
        # send user to paypal
        require_once(APPPATH . "libraries/paypal.php");
        $paypal = new SetExpressCheckout();
        $paypal->setNVP("CANCELURL", site_url('shop/checkout/payment_and_summary'));
        $paypal->setNVP("RETURNURL", site_url('shop/checkout/paypal_output'));
        $paypal->setNVP("HDRIMG", site_url('assets/images/logo.png'));

        $paypal->setNVP("NOSHIPPING", '0');

        if (!empty($shipping_cost)) {
            $paypal->setNVP("SHIPPINGAMT", number_format($shipping_cost['cost'], 2, '.', ''));
        }
        $paypal->setNVP("SHIPPINGAMT", "0");
        $paypal->setNVP("ALLOWNOTE", "0");
        $paypal->setNVP("LANDINGPAGE", "Billing");
        $paypal->setNVP("CUSTOM", "Orgone Energy");
        $paypal->setNVP("INVNUM", '0000');

        $count = 0;

        # Calculating Shipping Cost to add into total
        if (isset($complete_cart['shipping_cost'])) {
            if ($this->session->userdata("site_currency") == "aud") {
                $cart['wertyu565dsfs655hfgh'] = array("qty" => 1,
                    "name" => $complete_cart['shipping_cost']['name'],
                    "price" => number_format($complete_cart['shipping_cost']['cost'], 2, '.', ''),
                    "sale_price" => number_format($complete_cart['shipping_cost']['cost'], 2, '.', ''),
                    "price_usd" => number_format($complete_cart['shipping_cost']['cost'], 2, '.', ''),
                    "sale_price_usd" => number_format($complete_cart['shipping_cost']['cost'], 2, '.', '')
                );
            } else {
                $cart['wertyu565dsfs655hfgh'] = array("qty" => 1,
                    "name" => $complete_cart['shipping_cost']['name'],
                    "price" => number_format($complete_cart['shipping_cost']['cost_usd'], 2, '.', ''),
                    "sale_price" => number_format($complete_cart['shipping_cost']['cost_usd'], 2, '.', ''),
                    "price_usd" => number_format($complete_cart['shipping_cost']['cost_usd'], 2, '.', ''),
                    "sale_price_usd" => number_format($complete_cart['shipping_cost']['cost_usd'], 2, '.', '')
                );
            }
        }

        # Calculating Shipping Cost to deduct it from total
        if ($wholesaler_amount != "0.00") {
            $cart['wertyuiofhfghfghfgh'] = array("qty" => 1,
                "name" => "Wholesaller Discount",
                "price" => -$wholesaler_amount,
                "sale_price" => -$wholesaler_amount,
                "price_usd" => -$wholesaler_amount,
                "sale_price_usd" => -$wholesaler_amount
            );
        }

        # Calculating extra costs added in the payment page
        $extra_charges_mini = $this->session->userdata('extra_charges');
        if (!empty($extra_charges_mini)) {
            foreach ($extra_charges_mini as $key => $value) {
                $multiply_by = (floor($cart_total / $value['min_amount']) + 1);
                $cart['sdfsextracharges' . $key] = array("qty" => 1,
                    "qty" => $multiply_by,
                    "name" => $value['name'],
                    "price" => number_format(($value['val_aud']), 2, '.', ''),
                    "sale_price" => number_format(($value['val_aud']), 2, '.', ''),
                    "price_usd" => number_format(($value['val_usd']), 2, '.', ''),
                    "sale_price_usd" => number_format(($value['val_usd']), 2, '.', '')
                );
            }
        }

        # Calculating All Discounts (Coupon/Referrer) to deduct it from total
        if (isset($complete_cart['discount'])) {
            $cart['werfjdshfj679sdf7d7gh'] = array("qty" => 1,
                "name" => "Coupon/Referrer Discount",
                "price" => -number_format($complete_cart['discount']['COUPON']->amt, 2, '.', ''),
                "sale_price" => -number_format($complete_cart['discount']['COUPON']->amt, 2, '.', ''),
                "price_usd" => -number_format($complete_cart['discount']['COUPON']->amt, 2, '.', ''),
                "sale_price_usd" => -number_format($complete_cart['discount']['COUPON']->amt, 2, '.', '')
            );
        }

        # Calculating Credit Discount to deduct it from total
        if (!empty($user_id)) {
            if ($this->session->userdata('current_credit') == "" || $this->session->userdata('current_credit') == "0.00") {
                
            } else {
                $credit_discount = $this->session->userdata('current_credit');

                $cart['tretre0890dfvxf'] = array("qty" => 1,
                    "name" => "Credit Discount",
                    "price" => -number_format($credit_discount, 2, '.', ''),
                    "sale_price" => -number_format($credit_discount, 2, '.', ''),
                    "price_usd" => -number_format($credit_discount, 2, '.', ''),
                    "sale_price_usd" => -number_format($credit_discount, 2, '.', '')
                );
            }
        }

        # Calculating Total Bulk Shipping Cost to add it into total
        $bulk_total = 0.00;
        $bulk_total_usd = 0.00;
        foreach ($cart as $key => $value) {
            if ($this->session->userdata("site_currency") == "aud") {

                if (isset($value['bulk_price'])) {
                    $bulk_total += number_format($value['bulk_price'], 2, '.', '');
                } else {
                    
                }

                if ($bulk_total > 0) {
                    $cart['bulkds809sdfdsffvxf'] = array("qty" => 1,
                        "name" => "Total Bulk Size Shipping",
                        "price" => number_format($bulk_total, 2, '.', ''),
                        "sale_price" => number_format($bulk_total, 2, '.', ''),
                        "price_usd" => number_format($bulk_total, 2, '.', ''),
                        "sale_price_usd" => number_format($bulk_total, 2, '.', '')
                    );
                }
            } else {

                if (isset($value['bulk_price_usd'])) {
                    $bulk_total_usd += number_format($value['bulk_price_usd'], 2, '.', '');
                } else {
                    
                }

                if ($bulk_total_usd > 0) {
                    $cart['bulkusds809sdfdsffvxf'] = array("qty" => 1,
                        "name" => "Total Bulk Size Shipping",
                        "price" => number_format($bulk_total_usd, 2, '.', ''),
                        "sale_price" => number_format($bulk_total_usd, 2, '.', ''),
                        "price_usd" => number_format($bulk_total_usd, 2, '.', ''),
                        "sale_price_usd" => number_format($bulk_total_usd, 2, '.', '')
                    );
                }
            }
        }
        # Calculating All product's prices to add it into total 
        foreach ($cart as $key => $value) {

            $date11 = strtotime($value['sale_end']);
            $date22 = time();
            $subTime = $date11 - $date22;
            $y = ($subTime / (60 * 60 * 24 * 365));
            $d = ($subTime / (60 * 60 * 24)) % 365;
            $h = ($subTime / (60 * 60)) % 24;
            $m = ($subTime / 60) % 60;

            $paypal->setNVP("L_PAYMENTREQUEST_0_QTY" . $count, $value['qty']);

            if ($this->session->userdata("site_currency") == "aud") {
                if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $value['sale_price'] > 0) {
                    $paypal->setNVP("L_PAYMENTREQUEST_0_AMT" . $count, $value['sale_price']);
                } else {
                    $paypal->setNVP("L_PAYMENTREQUEST_0_AMT" . $count, $value['price']);
                }
            } else {
                if ($y >= 0 && $d >= 0 && $h >= 0 && $m >= 0 && $value['sale_price_usd'] > 0) {
                    $paypal->setNVP("L_PAYMENTREQUEST_0_AMT" . $count, $value['sale_price_usd']);
                } else {
                    $paypal->setNVP("L_PAYMENTREQUEST_0_AMT" . $count, $value['price_usd']);
                }
            }

            $paypal->setNVP("L_PAYMENTREQUEST_0_NAME" . $count, $value['name']);
            $count++;
        }

        $paypal->setNVP("PAYMENTREQUEST_0_SHIPPINGAMT", '');
        $paypal->setNVP("PAYMENTREQUEST_0_TAXAMT", '0');
        $paypal->setNVP("PAYMENTREQUEST_0_HANDLINGAMT", '0');
        $paypal->setNVP("PAYMENTREQUEST_0_CURRENCYCODE", $currency);
        $paypal->setNVP("PAYMENTREQUEST_0_ITEMAMT", number_format($cart_grand_total, 2, '.', ''));
        $paypal->setNVP("PAYMENTREQUEST_0_AMT", number_format($cart_grand_total, 2, '.', ''));

        $paypal->setNVP("PAYMENTREQUEST_0_DESC", 'Orgone Energy - ' . number_format($cart_grand_total, 2, '.', ''));
//            echo "<pre>";
//            print_r($paypal);
//            die;
        redirect($paypal->getResponse());
    }

    public function Paypal_output()
    {

        require_once(APPPATH . "libraries/paypal.php");

        $paypal = new GetExpressCheckoutDetails();
        $request = $paypal->getResponse(); # First response from Paypal

        $amount = (double) urldecode($request['PAYMENTREQUEST_0_AMT']);

        if ("SUCCESS" == strtoupper($request["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($request["ACK"])) {

            # Final request to let the payment get finished completely.
            $trmpCurrency = strtoupper($this->session->userdata('site_currency'));
            $paypal = new DoExpressCheckoutPayment(number_format($amount, 2, '.', ''), $trmpCurrency);

            $response = $paypal->getResponse();

            $transaction_id = $response['TRANSACTIONID'];

            if ("SUCCESS" == strtoupper($response["ACK"]) || "SUCCESSWITHWARNING" == strtoupper($response["ACK"])) {

                $complete_cart = $this->mycart->completecontents();
                $cart = $this->mycart->contents();

                // TODO : verify cart products total is equall to cart session totla  value
                // TODO :  -  Check for payemt way  if valid or not display relevent errors

                $cart_grand_total = $amount; # Amount sent to paypal - which is now paid.

                if ($this->session->userdata("site_currency") == "aud") {
                    $currency = "AUD";
                    $cart_total = $this->cart->get_cart_total();
                } else {
                    $currency = "USD";
                    $cart_total = $this->cart->get_cart_usd_total();
                }

                # putting condition here to give 1 time 30% discount to the user if he is a wholesaler type.
                # Discount is being count on only total of all products rather than the final amount.
                # Final Amount is in $cart_grand_total variable.

                if ($this->session->userdata('is_wholesaler') == "1") {
                    $wholesaler_amount = number_format((($cart_total * WHOLESALER_DISCOUNT) / 100), 2, '.', '');
                } else {
                    $wholesaler_amount = "0.00";
                }

                $order_no = $this->idstore->get_new_order_number();

                $complete_cart = $this->mycart->completecontents();

                # Register New User if user email not available in 'users' table
                $email_id = $this->session->userdata('email');

                # if A new user is registering - User table will store user's with unique ID
                if (empty($email_id)) {
                    $allData = $this->session->userdata('cart_contents');
                    $billing = $allData['shipping'];

                    $username = strtolower($billing['s_firstname']) . ' ' . strtolower($billing['s_lastname']);
                    $email = strtolower(strtolower(trim($billing['s_zmail'])));
                    
                    # Check to make user login or not after successful purchase
                    $this->check_to_make_user_login($email);
                    
                    // currently default password is "orgoneuser"
                    // comment the below line and uncomment the next line to it later
                    // $password = "orgoneuser";
                    $password = substr(md5(rand()), 0, 10);

                    $additional_data = array(
                        'first_name' => $billing['s_firstname'],
                        'last_name' => $billing['s_lastname'],
                        'company' => $billing['s_suburb'],
                        'phone' => $billing['s_phone'],
                    );

                    $active = 1;
            
                    if($this->config->item('login_module_in_checkout')) {
                        $registerUser = $this->ion_auth->register($username, $password, $email, $additional_data, $active);                
                    }

                    $additional_data['email'] = $email;
                    $additional_data['password'] = $password;

                    $new_user_details = new stdClass();
                    $new_user_details->email_to = $email; // as email will  be sent only to the billing email address            

                    $new_user_details->email_subject = "New Account Successfully Created - Orgone Energy";

                    //$order_email = $this->send_email_new_registration($additional_data, $new_user_details);

                    $registered_user_id = $this->db->insert_id("users");
                } else { // Get looged in user's id            
                    $registered_user_id = $this->session->userdata('user_id');
                }
                
                if (isset($complete_cart['discount']) && $this->session->userdata('is_wholesaler') == "0") {
                    $discount = $complete_cart['discount'];
                    $coupon = $discount['COUPON'];

                    if (isset($coupon->referrar_user_id) && $this->config->item('login_module_in_checkout') ) {
                    // if this is set, we will add discounted amount to user's credit
                    // And this entry will also be there in referral_history table
                        $referrar_user_id = $coupon->referrar_user_id;
                        $referrar_user_mail = $coupon->code;
                        $referrar_amount = number_format($coupon->amt, 2);
                        $referrar_currency = strtoupper($this->session->userdata('site_currency'));

                        $current_credit = $this->idstore->giveCurrentCreditAmount($referrar_user_id);
                        $credit_to_update = number_format(($current_credit + $referrar_amount), 2, '.', '');

                        $update_credit = $this->idstore->updateUserCredit($referrar_user_id, $credit_to_update);

                        if ($update_credit) {
                            $insert_data = array(
                                'to_user_id' => $referrar_user_id,
                                'to_user_mail' => $referrar_user_mail,
                                'from_user_id' => $this->session->userdata('user_id'),
                                'from_user_mail' => $this->session->userdata('email'),
                                'order_id' => $order_no,
                                'amount' => $referrar_amount,
                                'amount_currency' => $referrar_currency
                            );

                            $insert_referal_table = $this->idstore->insertReferalHistoryData($insert_data);
                            // Need to send a mail to the user whose emailid was used in the purchase
                            // Informing him/her about his/her credit updation.
                            $details->email_to = $referrar_user_mail;
                            $details->email_subject = 'Account Credited - Orgone Energy Australia';

                            $insert_data['total_credit'] = $credit_to_update;

                            $this->send_referal_email($insert_data, $details);
                        } else {
                            
                        }
                    } else {
                        
                    }
                }

                $payment_mode = "Paypal";

//                        echo $order_no;echo "<hr>";
//                        echo "<pre>";
//                        print_r($cart);                        
//                        echo "<hr>";
//                        print_r($complete_cart);                        
//                        echo "<hr>";
//                        echo $cart_grand_total;echo "<hr>";
//                        echo $transaction_id;echo "<hr>";
//                        echo $registered_user_id;echo "<hr>";
//                        echo $wholesaler_amount;echo "<hr>";
//                        echo $payment_mode;echo "<hr>";                        
//                        die;
                // So far Every thing is  true
                // TODO :  -  Once Eveything is valid - save them to order table //$id, $cart, $data, $paid)
                $saved_order_id = $this->idstore->save_order($order_no, $cart, $complete_cart, $cart_grand_total, $transaction_id, $registered_user_id, $wholesaler_amount, $payment_mode);

                $this->session->set_userdata("saved_order_id", $saved_order_id);

                if ($saved_order_id) {

                    $user_id = $this->session->userdata('user_id');
                    // update this user's credit to 0.00 after successful shopping with credit being used
                    if (!empty($user_id) && $this->session->userdata('is_wholesaler') != "1") {
                        $update_credit_after_use = $this->idstore->updateUserCredit($user_id, '0.00');
                    }

                    // Sending PDF files in the thank you page, if purchased any
                    $purchased_pdfs = array();
                    foreach ($cart as $key => $value) {
                        if ($value['to_be_shipped'] == "0") {
                            $purchased_pdfs[] = $value['product_pdf1'];
                            $purchased_pdfs[] = $value['product_pdf2'];
                        } else {
                            continue;
                        }
                    }
                    $this->session->set_userdata("purchased_pdfs", $purchased_pdfs);


                    # Everything  have  been saved  and this is the order id  that need to be displayed to client
                    # TODO : send am email to customer and also  admin once order  has been saved .
                    # Sending email to admin ( using default setting )

                    $additional_data['payment_method'] = $payment_mode;
                    $additional_data['order_id'] = $saved_order_id;
                    $additional_data['transaction_id'] = $transaction_id;

                    $admin_email = $this->send_email($post, $cart, $additional_data);
                    // Creating details to be loaded for order email !!as stupid I really dont knwo Y I am doing this
                    $details = new stdClass();
                    $details->email_to = $this->cart->get_billing_email(); // as email will  be sent only to the billing email address

                    if (!$details->email_to) {
                        redirect($this->base_name . '/checkout/address_details', 'refresh');
                    } // cannot find email address hence rediecting back

                    $details->email_subject = lang('default email subject');
                    $order_email = $this->send_email($post, $cart, $additional_data, $details);

                    if ($order_email) {
                        // Todo - kill shop session here
                        #Success Response on valid completion of order
                        $this->data['form_html_content'] = '
                                                    <div class="checkoutSection wysiwyg">
                                                    <h2>Thank you for your Order, please note your order# is <strong>' . $saved_order_id . '</strong>.</h2>
                                                    <p>We have received your order and have sent a copy of your order details to the email address provided.</p>
                                                    </div>
                                                    <p>If you have any questions about your order, please view our <a href="/faq">FAQ section</a> or <a href="/contact_us">contact us.</a></br>
                                                    Thank you again for shopping online with PARC Frankston.</p>
                                                ';
                    } else {    // cannot send email to client
                        $this->data['form_html_content'] = '
                                                                <div class="checkoutSection wysiwyg">
                                                                <h2>Thank you for your Order</h2>
                                                                <p>We have received your order and have tried to send you a copy of your order details to the email address provided, but there was some erro please contact Admin</p>
                                                                </div>
                                                                <p>If you have any questions about your order, please view our <a href="/faq">FAQ section</a> or <a href="/contact_us">contact us.</a></br>
                                                                Thank you again for shopping online with PARC Frankston.</p>
                                                            ';
                    }

                    # Variables
                    $this->data['page_title'] = 'Order Completed';
                    # meta title  & Desc
                    $this->template->meta['title'] = lang('page meta title order completed');
                    $this->template->meta['description'] = lang('page meta description order completed');

                    $this->cart->remove();
                    $this->session->unset_userdata("extra_charges");

                    redirect('/shop/checkout/order_status/success');

                    # Template
                    // $this->template->set_inner('templates/template_form_repsonse');
                    // $this->template->add_page('/shop/checkout/components/payment_complete');
                    # Render the goods

                    $this->template->render($this->data);
                }   # closing order save                        
            } else {
                redirect('/shop/checkout/order_status/failure');
            }
        } else {
            redirect('/shop/checkout/order_status/failure');
        }
    }

    /*
     * @param bool $page
     */

    public function Order_completed($post = false) // Credit Card Payment - eWay
    {

        if (!$post) {
            redirect($this->base_name . '/checkout/shipping_details'); // this allow if post variable is pass only
        }
        # validation success of credit card details
        # load cart contents
        $cart = $this->mycart->contents();

        # get  payment details
        $payment_details = $post;

        # TODO : verify cart products total is equall to cart session totla  value
        # TODO :  -  Check for payemt way  if valid or not display relevent errors
        $cart_grand_total = $this->cart->get_cart_total_after_discount();

        if ($this->session->userdata("site_currency") == "aud") {
            $cart_total = $this->cart->get_cart_total();
        } else {
            $cart_total = $this->cart->get_cart_usd_total();
        }

        # putting condition here to give 1 time 30% discount to the user if he is a wholesaler type.
        # Discount is being count on only total of all products rather than the final amount.
        # Final Amount is in $cart_grand_total variable.

        if ($this->session->userdata('is_wholesaler') == "1") {
            $wholesaler_amount = number_format((($cart_total * WHOLESALER_DISCOUNT) / 100), 2, '.', '');
            $cart_grand_total = number_format(($cart_grand_total - $wholesaler_amount), 2, '.', '');
        } else {
            $wholesaler_amount = "0.00";
            $cart_grand_total = $cart_grand_total;
        }

        # This part is done to check whether there is any credit amount available for this user or not
        # If so, reducing it from the original total and will update this user's credit amount to 0.00
        # deducting amount from grand total

        $user_id = $this->session->userdata('user_id');
        if (!empty($user_id)) {
            $cart_grand_total = number_format(($cart_grand_total - $this->session->userdata('current_credit')), 2, '.', '');
        }

        $order_no = $this->idstore->get_new_order_number();

        $payment_result = $this->make_payment($payment_details, $this->cart->get_details('billing'), $cart_grand_total, $order_no);

        # if payment gets fail, we will throw user back to payment_and_summary page
        # else it will follow the next code

        if ($payment_result['success'] == false) {
            $errors = array($payment_result['response']);
            $this->Payment_and_summary($errors);
            return;
        }

        # Get the eway_transaction_id 
        # $payment_result['eway_transaction_id'];

        $transaction_id = $payment_result['eway_transaction_id'];
        $complete_cart = $this->mycart->completecontents();

        # Register New User if user email not available in 'users' table
        $email_id = $this->session->userdata('email');

        # if A new user is registering - User table will store user's with unique ID
        if (empty($email_id)) {
            $allData = $this->session->userdata('cart_contents');
            $billing = $allData['shipping'];

            $username = strtolower($billing['s_firstname']) . ' ' . strtolower($billing['s_lastname']);
            $email = strtolower(strtolower($billing['s_zmail']));
            
            # Check to make user login or not after successful purchase
            $this->check_to_make_user_login($email);
            
            # currently default password is "orgoneuser"
            # comment the below line and uncomment the next line to it later
            # $password = "orgoneuser";
            $password = substr(md5(rand()), 0, 10);

            $additional_data = array(
                'first_name' => $billing['s_firstname'],
                'last_name' => $billing['s_lastname'],
                'company' => $billing['s_suburb'],
                'phone' => $billing['s_phone'],
            );

            $active = 1;
            
            if($this->config->item('login_module_in_checkout')) {
                $registerUser = $this->ion_auth->register($username, $password, $email, $additional_data, $active);                
            }

            $additional_data['email'] = $email;
            $additional_data['password'] = $password;

            $new_user_details = new stdClass();
            $new_user_details->email_to = $email; // as email will  be sent only to the billing email address            

            $new_user_details->email_subject = "New Account Successfully Created - Orgone Energy";

            //$order_email = $this->send_email_new_registration($additional_data, $new_user_details);
            # need to send a new registration mail to this user.            
            # need to send a mail instructing referral system.

            $registered_user_id = $this->db->insert_id("users");
        } else { // Get looged in user's id            
            $registered_user_id = $this->session->userdata('user_id');
        }

        if (isset($complete_cart['discount']) && $this->session->userdata('is_wholesaler') == "0") {
            $discount = $complete_cart['discount'];
            $coupon = $discount['COUPON'];

            if (isset($coupon->referrar_user_id) && $this->config->item('login_module_in_checkout')) {
                # if this is set, we will add discounted amount to user's credit
                # And this entry will also be there in referral_history table
                $referrar_user_id = $coupon->referrar_user_id;
                $referrar_user_mail = $coupon->code;
                $referrar_amount = number_format($coupon->amt, 2);
                $referrar_currency = strtoupper($this->session->userdata('site_currency'));

                $current_credit = $this->idstore->giveCurrentCreditAmount($referrar_user_id);
                $credit_to_update = number_format(($current_credit + $referrar_amount), 2, '.', '');

                $update_credit = $this->idstore->updateUserCredit($referrar_user_id, $credit_to_update);

                if ($update_credit) {
                    $insert_data = array(
                        'to_user_id' => $referrar_user_id,
                        'to_user_mail' => $referrar_user_mail,
                        'from_user_id' => $this->session->userdata('user_id'),
                        'from_user_mail' => $this->session->userdata('email'),
                        'order_id' => $order_no,
                        'amount' => $referrar_amount,
                        'amount_currency' => $referrar_currency
                    );

                    $insert_referal_table = $this->idstore->insertReferalHistoryData($insert_data);

                    // Need to send a mail to the user whose emailid was used in the purchase
                    // Informing him/her about his/her credit updation.
                    $details->email_to = $referrar_user_mail;
                    $details->email_subject = 'Account Credited - Orgone Energy Australia';

                    $insert_data['total_credit'] = $credit_to_update;

                    $this->send_referal_email($insert_data, $details);
                } else {
                    
                }
            } else {
                
            }
        }

        $payment_mode = "eway";

        # So far Every thing is  true
        # TODO :  -  Once Eveything is valid - save them to order table //$id, $cart, $data, $paid)
        $saved_order_id = $this->idstore->save_order($order_no, $cart, $complete_cart, $cart_grand_total, $transaction_id, $registered_user_id, $wholesaler_amount, $payment_mode);
        $this->session->set_userdata("saved_order_id", $saved_order_id);

        if ($saved_order_id) {

            // update this user's credit to 0.00 after successful shopping with credit being used
            if (!empty($user_id) && $this->session->userdata('is_wholesaler') != "1") {
                $update_credit_after_use = $this->idstore->updateUserCredit($user_id, '0.00');
            }

            // Sending PDF files in the thank you page, if purchased any
            $purchased_pdfs = array();
            foreach ($cart as $key => $value) {
                if ($value['to_be_shipped'] == "0") {
                    $purchased_pdfs[] = $value['product_pdf1'];
                    $purchased_pdfs[] = $value['product_pdf2'];
                } else {
                    continue;
                }
            }
            $this->session->set_userdata("purchased_pdfs", $purchased_pdfs);

            // Everything  have  been saved  and this is the order id  that need to be displayed to client
            // TODO : send am email to customer and also  admin once order  has been saved .
            // Sending email to admin ( using default setting )

            $additional_data['payment_method'] = 'eWay';
            $additional_data['order_id'] = $saved_order_id;
            $additional_data['transaction_id'] = $transaction_id;

            $admin_email = $this->send_email($post, $cart, $additional_data);
            // Creating details to be loaded for order email !!as stupid I really dont knwo Y I am doing this
            $details = new stdClass();
            $details->email_to = $this->cart->get_billing_email(); // as email will  be sent only to the billing email address

            if (!$details->email_to) {
                redirect($this->base_name . '/checkout/address_details', 'refresh');
            } // cannot find email address hence rediecting back

            $details->email_subject = lang('default email subject');

            $order_email = $this->send_email($post, $cart, $additional_data, $details);

            if ($order_email) {
                // Todo - kill shop session here
                #Success Response on valid completion of order
                $this->data['form_html_content'] = '
                                    <div class="checkoutSection wysiwyg">
                                    <h2>Thank you for your Order, please note your order# is <strong>' . $saved_order_id . '</strong>.</h2>
                                    <p>We have received your order and have sent a copy of your order details to the email address provided.</p>
                                    </div>
                                    <p>If you have any questions about your order, please view our <a href="/faq">FAQ section</a> or <a href="/contact_us">contact us.</a></br>
                                    Thank you again for shopping online with PARC Frankston.</p>
				';
            } else {    // cannot send email to client
                $this->data['form_html_content'] = '
                                                <div class="checkoutSection wysiwyg">
                                                <h2>Thank you for your Order</h2>
                                                <p>We have received your order and have tried to send you a copy of your order details to the email address provided, but there was some erro please contact Admin</p>
                                                </div>
						<p>If you have any questions about your order, please view our <a href="/faq">FAQ section</a> or <a href="/contact_us">contact us.</a></br>
						Thank you again for shopping online with PARC Frankston.</p>
                                            ';
            }

            # Variables
            $this->data['page_title'] = 'Order Completed';
            # meta title  & Desc
            $this->template->meta['title'] = lang('page meta title order completed');
            $this->template->meta['description'] = lang('page meta description order completed');

            $this->cart->remove();
            $this->session->unset_userdata("extra_charges");

            redirect('/shop/checkout/order_status/success');

            # Template
//            $this->template->set_inner('templates/template_form_repsonse');
//            $this->template->add_page('/shop/checkout/components/payment_complete');
            # Render the goods

            $this->template->render($this->data);
        } else {
            redirect('/shop/checkout/order_status/failure');
        }//  closing order save
    }

    public function Direct_order($post = false)
    {

        # Checking if this url is fired from payment_and_summary or not
        $url_pieces = explode('/', $_SERVER['HTTP_REFERER']);

        if ($url_pieces[5] != "payment_and_summary") {
            redirect($this->base_name . '/checkout/shipping_details'); // this allow if post variable is pass only
        }

        # validation success
        # load cart content
        $cart = $this->mycart->contents();

        # TODO : verify cart products total is equall to cart session totla  value
        # TODO :  -  Check for payemt way  if valid or not display relevent errors
        $cart_grand_total = $this->cart->get_cart_total_after_discount();

        if ($this->session->userdata("site_currency") == "aud") {
            $cart_total = $this->cart->get_cart_total();
        } else {
            $cart_total = $this->cart->get_cart_usd_total();
        }

        # putting condition here to give 1 time 30% discount to the user if he is a wholesaler type.
        # Discount is being count on only total of all products rather than the final amount.
        # Final Amount is in $cart_grand_total variable.

        if ($this->session->userdata('is_wholesaler') == "1") {
            $wholesaler_amount = number_format((($cart_total * WHOLESALER_DISCOUNT) / 100), 2, '.', '');
            $cart_grand_total = number_format(($cart_grand_total - $wholesaler_amount), 2, '.', '');
        } else {
            $wholesaler_amount = "0.00";
            $cart_grand_total = $cart_grand_total;
        }

        # This part is done to check whether there is any credit amount available for this user or not
        # If so, reducing it from the original total and will update this user's credit amount to 0.00
        # deducting amount from grand total

        $user_id = $this->session->userdata('user_id');
        if (!empty($user_id)) {
            $cart_grand_total = number_format(($cart_grand_total - $this->session->userdata('current_credit')), 2, '.', '');
        }

        $order_no = $this->idstore->get_new_order_number();

        $complete_cart = $this->mycart->completecontents();

        # Register New User if user email not available in 'users' table
        $email_id = $this->session->userdata('email');

        # if A new user is registering - User table will store user's with unique ID
        if (empty($email_id)) {            
            
            $allData = $this->session->userdata('cart_contents');
            $billing = $allData['shipping'];

            $username = strtolower($billing['s_firstname']) . ' ' . strtolower($billing['s_lastname']);
            $email = strtolower(strtolower($billing['s_zmail']));
            
            # Check to make user login or not after successful purchase
            $this->check_to_make_user_login($email);
            
            # currently default password is "orgoneuser"
            # comment the below line and uncomment the next line to it later
            # $password = "orgoneuser";
            $password = substr(md5(rand()), 0, 10);

            $additional_data = array(
                'first_name' => $billing['s_firstname'],
                'last_name' => $billing['s_lastname'],
                'company' => $billing['s_suburb'],
                'phone' => $billing['s_phone'],
            );

            $active = 1;
            
            if($this->config->item('login_module_in_checkout')) {
                $registerUser = $this->ion_auth->register($username, $password, $email, $additional_data, $active);                
            }

            $additional_data['email'] = $email;
            $additional_data['password'] = $password;

            $new_user_details = new stdClass();
            $new_user_details->email_to = $email; // as email will  be sent only to the billing email address            

            $new_user_details->email_subject = "New Account Successfully Created - Orgone Energy";

            # $order_email = $this->send_email_new_registration($additional_data, $new_user_details);            
            # need to send a new registration mail to this user.            
            # need to send a mail instructing referral system

            $registered_user_id = $this->db->insert_id("users");
        } else { # Get looged in user's id            
            $registered_user_id = $this->session->userdata('user_id');
        }

        if (isset($complete_cart['discount']) && $this->session->userdata('is_wholesaler') == "0") {
            $discount = $complete_cart['discount'];
            $coupon = $discount['COUPON'];

            if (isset($coupon->referrar_user_id) && $this->config->item('login_module_in_checkout')) {
                # if this is set, we will add discounted amount to user's credit
                # And this entry will also be there in referral_history table
                $referrar_user_id = $coupon->referrar_user_id;
                $referrar_user_mail = $coupon->code;
                $referrar_amount = number_format($coupon->amt, 2);
                $referrar_currency = strtoupper($this->session->userdata('site_currency'));

                $current_credit = $this->idstore->giveCurrentCreditAmount($referrar_user_id);
                $credit_to_update = number_format(($current_credit + $referrar_amount), 2, '.', '');

                $update_credit = $this->idstore->updateUserCredit($referrar_user_id, $credit_to_update);

                if ($update_credit) {
                    $insert_data = array(
                        'to_user_id' => $referrar_user_id,
                        'to_user_mail' => $referrar_user_mail,
                        'from_user_id' => $this->session->userdata('user_id'),
                        'from_user_mail' => $this->session->userdata('email'),
                        'order_id' => $order_no,
                        'amount' => $referrar_amount,
                        'amount_currency' => $referrar_currency
                    );

                    $insert_referal_table = $this->idstore->insertReferalHistoryData($insert_data);

                    # Need to send a mail to the user whose emailid was used in the purchase
                    # Informing him/her about his/her credit updation.
                    $details->email_to = $referrar_user_mail;
                    $details->email_subject = 'Account Credited - Orgone Energy Australia';

                    $insert_data['total_credit'] = $credit_to_update;

                    $this->send_referal_email($insert_data, $details);
                } else {
                    
                }
            } else {
                
            }
        }


        $payment_mode = "Direct Bank Deposit";


        # So far Every thing is  true
        # TODO :  -  Once Eveything is valid - save them to order table //$id, $cart, $data, $paid)
        $saved_order_id = $this->idstore->save_order($order_no, $cart, $complete_cart, $cart_grand_total, $transaction_id, $registered_user_id, $wholesaler_amount, $payment_mode);
        $this->session->set_userdata("saved_order_id", $saved_order_id);

        if ($saved_order_id) {

            # update this user's credit to 0.00 after successful shopping with credit being used
            # if(!empty($user_id) && $this->session->userdata('is_wholesaler') == "1")
            if (!empty($user_id)) {
                $update_credit_after_use = $this->idstore->updateUserCredit($user_id, '0.00');
            }

            // Sending PDF files in the thank you page, if purchased any
            $purchased_pdfs = array();
            foreach ($cart as $key => $value) {
                if ($value['to_be_shipped'] == "0") {
                    $purchased_pdfs[] = $value['product_pdf1'];
                    $purchased_pdfs[] = $value['product_pdf2'];
                } else {
                    continue;
                }
            }
            $this->session->set_userdata("purchased_pdfs", $purchased_pdfs);

            # Everything  have  been saved  and this is the order id  that need to be displayed to client
            # TODO : send am email to customer and also  admin once order  has been saved .
            # Sending email to admin ( using default setting )

            $additional_data['payment_method'] = 'Direct Bank Deposit';
            $additional_data['order_id'] = $saved_order_id;
            $additional_data['transaction_id'] = $transaction_id;

            $admin_email = $this->send_email($post, $cart, $additional_data);
            # Creating details to be loaded for order email !!as stupid I really dont knwo Y I am doing this
            $details = new stdClass();
            $details->email_to = $this->cart->get_billing_email(); // as email will  be sent only to the billing email address

            if (!$details->email_to) {
                redirect($this->base_name . '/checkout/address_details', 'refresh');
            } // cannot find email address hence rediecting back

            $details->email_subject = lang('default email subject');

            $order_email = $this->send_email($post, $cart, $additional_data, $details);

            # Variables
            $this->data['page_title'] = 'Order Completed';
            # meta title  & Desc
            $this->template->meta['title'] = lang('page meta title order completed');
            $this->template->meta['description'] = lang('page meta description order completed');

            $this->cart->remove();
            $this->session->unset_userdata("extra_charges");

            redirect('/shop/checkout/order_status/success');

            # Template
            // $this->template->set_inner('templates/template_form_repsonse');
            // $this->template->add_page('/shop/checkout/components/payment_complete');
            # Render the goods

            $this->template->render($this->data);
        } else {
            redirect('/shop/checkout/order_status/failure');
        } // closing order save
    }
    
    public function check_to_make_user_login($email)
    {        
        if ($this->config->item('login_module_in_checkout') && $this->config->item('login_user_after_checkout')) {
            if ($this->session->userdata("email") == "") {
                $this->session->set_userdata("make_this_user_login", $email);
            } else {
                #
            }
        } else {            
            #
        }     
    }

    public function Order_status($status)
    {
        
        if($status == "success" && 
                $this->session->userdata("email") == "" 
                    && $this->session->userdata("make_this_user_login") != "")
        {            
         
            $registered = $this->session->userdata("make_this_user_login");
            
            $query = $this->db->select($this->identity_column . ', first_name, last_name, username, email, id, password, active, last_login, wholesaler')
		                  ->where("email", $registered)
		                  ->limit(1)
		                  ->get('users')->row();
            
            $session_data = array();
            
            $session_data = array(
                    'first_name'           => $query->first_name,
                    'last_name'            => $query->last_name,		    
		    'username'             => $query->username,
		    'email'                => $query->email,
		    'user_id'              => $query->id, //everyone likes to overwrite id so we'll use user_id
		    'old_last_login'       => $query->last_login,
		    'is_wholesaler'       =>  $query->wholesaler
		);  
                    
            $this->session->set_userdata($session_data);
            
        }
        
        # Template
        $this->template->add_page($this->base_name . '/checkout/order_status');

        # meta title  & Desc
        $this->template->meta['title'] = "Order Status";
        $this->template->meta['description'] = lang('page meta description address details');

        # Render the goods
        $this->template->render($this->data);
    }

    /**
     * Private function to go through the process of making payment
     * @param $details
     * @param $billing_info
     * @param $value
     * @param $order_no
     * @return mixed
     */
    private function make_payment($details, $billing_info, $value, $order_no)
    {
        if (!$this->config->item('payment_institute')) {
            die('Not payment settings found');
        }

        if (!in_array($this->config->item('payment_institute'), array('nab', 'anz', 'eway'))) {
            die("Unknown Payment Institute ({$this->config->item('payment_institute')})");
        }

        //Assume  that  payment setting have  been set
        $payment_settigs = new stdClass();

        //if (defined(PAYMENT_MODE)) {
        if (PAYMENT_MODE == 'live') {
            $payment_settigs->user_id = $this->config->item('live_payment_user_id');
        } else { // testing
            $payment_settigs->sandbox_user_id = $this->config->item('test_payment_user_id');
        }
        //} else {
        //    $payment_settigs->sandbox_user_id = $this->config->item('test_payment_user_id');
        // }
        //echo $this->config->item('live_payment_user_id');
        //var_dump($payment_settigs);die();
        // # load  payment LIB   this should be present in  payment folder
        $this->payment = $this->load->library('payment/' . $this->config->item('payment_institute'), $payment_settigs);
        //  adding user data to payment LIB
        $this->payment->add_user_data(array(
            'name_on_card' => $details['card_name'],
            'first_name' => $billing_info['b_firstname'],
            'last_name' => $billing_info['b_lastname'],
            'email' => $billing_info['b_zmail'],
            'address' => $billing_info['b_address_1'] . ', ' . $billing_info['b_address_2'] . ', ' . $billing_info['b_country'] . ', ' . $billing_info['b_state'] . ',' . $billing_info['b_country'],
            'postcode' => $billing_info['b_postcode']
        ));

        // making sure that month is in right format
        if (is_int($details['month'])) {
            $month = $details['month'];
        } else {
            $date = date_parse($details['month']);
            $month = $date['month'];
        }

        $result_array = $this->payment->pay($value, $details['cc_number'], $month . '/' . $details['year'], $details['cvv'], $order_no);

        return $result_array; // return the resutl array
    }

    /**
     * Sends Email  to  client and admin
     * @param $data
     * @param $cart
     * @param null $email_details
     * @return bool
     */
    private function send_email($data, $cart, $additional_data, $email_details = NULL)
    {

        $productType = array();
        foreach ($cart as $key => $value) {
            $productType[$key] = $this->idstore->getThisProductPriceName($value['price_id']);
        }

//       echo "<pre>";
//       print_r($productType);
//       print_r($cart);
//       die;
        #loading the email lib
        $this->load->library('email');
        #inti with config
        $this->email->initialize(array('mailtype' => 'html',
            'useragent' => 'my[id]'));

        # Getting the requ data to fill  the template
        $settings = array('sitename' => $this->config->item('site_name'),);
        $data = $this->mycart->completecontents();
        $data['grand_total'] = $this->cart->get_cart_total_after_discount();

        if (!empty($email_details)) { // if not empty load the details
            $this->email->from($this->config->item('from_email'), SITE_NAME);
            $this->email->reply_to($this->config->item('reply_to_email'), $this->config->item('reply_to_name'));
            $this->email->to($email_details->email_to);
            $this->email->subject(SITE_NAME . " - " . $this->config->item('order_email_subject'));
        }
        // default setting  for email
        if (empty($email_details)) { // Default settings
            $this->email->from($this->config->item('from_email'), SITE_NAME);
            $this->email->reply_to($this->config->item('reply_to_email'), $this->config->item('reply_to_name'));
            $this->email->to($this->config->item('to_email'));
            $this->email->subject(SITE_NAME . " - " . $this->config->item('order_email_subject'));
        }

        //loading the email template
        $this->email->message($this->load->view($this->base_name . '/email_templates/new_order', array('data' => $data,
                    'cart' => $cart,
                    'user' => $additional_data,
                    'productType' => $productType,
                    'settings' => $this->settings), true));

        // Set up alternate message
        $this->email->set_alt_message('this is alternate alternative message');

        if (!$this->email->send()) {
            if ($this->config->item('email_debug')) {
                echo $this->email->print_debugger(); // debug email if necessary
            }
            return false; // else return false
        } else {
            return true; // return true
        }
    }

    private function send_referal_email($additional_data, $details)
    {


        $this->load->library('email');
        $this->email->initialize(array('mailtype' => 'html', 'useragent' => 'my[id]'));
        $this->email->from($this->config->item('from_email'), SITE_NAME);
        $this->email->to($details->email_to);
        $this->email->subject($details->email_subject);
        $this->email->message($this->load->view($this->base_name . '/email_templates/referral_email', array('data' => $additional_data, 'settings' => $this->settings), true));

        if (!$this->email->send()) {
            if ($this->config->item('email_debug')) {
                echo $this->email->print_debugger(); // debug email if necessary
            }
            return false; // else return false
        } else {
            return true; // return true
        }
    }

}