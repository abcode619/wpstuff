<?php
    /**
     *  Author : jay kora
     *  Email : kora.jayaram@gmail.com
     *  Company : Iddigital
     */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

// echo BASEPATH.'../application/' ;
//require_once (dirname(__FILE__).'/shop_controller.php'); // Ideally this is should be autoloaded dint find anything that can autload this -- crap man

class Shop extends MY_Controller
{

    var $base_name;
    var $title_prefix;

    public function __construct()
    {

        parent::__construct();

        /* ----This has to be moved comman class - I dont requried_once doesnt work in preflight  ----- */
        $this->load->config('shop_config');

        # cart variable
        $this->base_name = 'shop'; // replace this
        $this->title_prefix = '4 Step Cart';
        $this->data['base_name'] = $this->base_name; //  this  has to go ...I dont knwo Y its still there
        #Javascaript
        //	$this->template->add_script('http://cdn.jquerytools.org/1.2.6/full/jquery.tools.min.js');
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/shop.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/selectionCountry.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardValidator.js'));
        $this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardTypeDetector.js'));

        #css
        $this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/css/store.css'));
        $this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/creditCardTypeDetector.css'));

        /* ----This has to be moved comman folder  ----- */

        # Helper
        $this->load->helper('jai'); // module helper costomer moudle

        # Model
        $this->load->model('idstore');
        $this->load->model('cart');

        $this->data['base_name'] = $this->config->item('base_name');
        $this->base_name = $this->data['base_name']; // TODO : this has to be removed  -- deprecated
        $this->data['breadcrumbs']['/' . $this->data['base_name'] . '/'] = ucfirst($this->data['base_name']);

        # Model -  Get all categories
        $categories = $this->idstore->get_categories_with_products();

        # Template
        $this->template->set_inner('templates/template_main');

        # Variables
        $this->data['page_title'] = '';
        $this->data['errors'] = array();
        $this->base_name = $this->config->item('base_name'); // replace this
        # Menus
        # Category links
        $this->data['category__title'] = 'Browse By Category';

        $this->data['category__nav_list'] = array();
        foreach ($categories as $value) {
            if ($value->noproducts > 0) {
                $this->data['category__nav_list'][] = array(
                    'title' => $value->name,
                    'extra' => $value->noproducts . ' Products',
                    'uri' => site_url('/' . $this->base_name . '/category/' . $value->slug),
                );
            }
        }

        # Brands Menu
        # Brand  - get all brands
        $brands = $this->idstore->get_brands();
        $this->data['brands__title'] = 'Browse By Brand';

        $this->data['brands__nav_list'] = array();

        foreach ($brands as $value) {
            if ($value->noproducts > 0) {
                $this->data['brands__nav_list'][] = array('title' => $value->name,
                    'extra' => $value->noproducts . ' Products',
                    'uri' => site_url('/' . $this->base_name . '/brand/' . $value->slug),);
            }
        }

        // Load cart  items
        $this->data['view_cart'] = $this->cart->cart_check();
        if ($this->cart->cart_check()) {
            $this->data['view_cart_count'] = $this->cart->cart_count();
            $this->data['view_cart_total'] = $this->cart->get_cart_total_after_discount();
        }
    }

    public function index()
    {
        # only for featured  products
        //$this->data['products'] = $this->idstore->get_featured_products();
        # Get all products
        $this->data['products'] = $this->idstore->get_all_products();

        # Template
        $this->template->add_page($this->base_name . '/home');

        # Render the goods
        $this->template->render($this->data);
    }

    public function category($slug)
    {
        $sortBy = $this->input->post('sort_by');

        echo $sortBy;

        //TODO: still need to  be configured
        $this->data['category'] = $this->idstore->get_category($slug);
        $this->data['products'] = $this->idstore->get_products($this->data['category']->store_categories_id, $sortBy);

        # meta title s
        $this->template->meta['title'] = $this->data['category']->seo_title . ' | ' . SITE_TITLE;
        $this->template->meta['description'] = $this->data['category']->seo_description;


        # template Data
        $this->template->add_page($this->base_name . '/category');
        $this->template->render($this->data);
    }


    public function product($slug)
    {
        # get product details with slug
        $this->data['product'] = $this->idstore->get_product_by_slug($slug, true);

//        echo "<pre>";
//        print_r($this->data['product']);
//        die;
        # get related categories Names
//        $this->data['related_categories'] = $this->idstore->getRelatedCategories($this->data['product']->store_product_id);

        # get related Uses Names
//        $this->data['related_uses'] = $this->idstore->getRelatedUses($this->data['product']->store_product_id);

        # get related products of this product
//        $this->data['related_products'] = $this->idstore->getRelatedProducts($this->data['product']->store_product_id);

        # Adding the product from product specific page
        $post = $this->input->post();
        if ($post) {

            /* Someone tries to add something to the cart */
            // no qty in products specific page default is 1
            if (isset($post['qty'])) {
                $qty = intval($post['qty']);
                if (!$qty) {
                    $this->data['errors'][] = 'Invalid Qty ';
                }
            } else {
                $qty = 1; // default QTy
            }
            //  this is  mandatroy
            if (!isset($post['size']))
                $this->data['errors'][] = 'Please select a size';

            if (empty($this->data['errors'])) {

                /* Everything ok. Add it to the cart */
                $this->cart->add($this->data['product']->store_product_id, $post['size'], $qty);

                redirect('/' . $this->base_name . '/cart/');
            }
        }

        # Loading the realated products by category
//        $this->data['related_categories_products'] = $this->idstore->get_related_products_in_same_category($this->data['product']->store_product_id);

        # Title
        //$this->template->meta['title'] = $this->title_prefix . ' - ' . ucfirst($this->base_name) . ' - ' . $this->data['product']->categories[0]->name . ' - ' . $this->data['product']->seo_title;
        $this->template->meta['title'] = $this->data['product']->seo_title . ' | ' . $this->data['product']->categories[0]->name . ' | Shop | ' . SITE_TITLE;
        $this->template->meta['description'] = $this->data['product']->seo_description;
        # bread
//        if (count($this->data['product']->categories)) {
//            $this->data['breadcrumbs']["/$this->base_name/category/{$this->data['product']->categories[0]->slug}"] = $this->data['product']->categories[0]->name;
//        }
//        $this->data['breadcrumbs']["/$this->base_name/product/{$this->data['product']->store_product_id}/{$this->data['product']->slug}"] = $this->data['product']->name;

//        echo "<pre>";
//        print_r($this->data);
//        die;
        # Render data here
        $this->template->add_page($this->base_name . '/product');
        $this->template->render($this->data);
    }

    public function addtocart()
    {
        # Adding the product from product specific page
        $post = $this->input->post();

        if ($post) {

            if (empty($this->data['errors'])) {

                /* Everything ok. Add it to the cart */
                $data = array();
                # get Single Product
                $data['product'] = $this->idstore->get_product($post['product_id'], true);
                $data['product_price_id'] = $post['price_id'];
                $data['product_qty'] = $post['qty'];
                # get related categories Names
                $data['related_categories'] = $this->idstore->getRelatedCategories($post['product_id']);

                # get related Uses Names
                //$data['related_uses'] = $this->idstore->getRelatedUses($post['product_id']);
                $this->load->view($this->base_name . '/widgets/cart_popup', $data);
            }
        }
    }

    public function addtocartitem()
    {
        # Adding the product from product specific page
        $post = $this->input->post();

        if ($post) {

            if (empty($this->data['errors'])) {
                /* Everything ok. Add it to the cart */
                $data = $this->cart->add($post['product_id'], $post['price_id'], $post['qty']);
                if ($data) {
                    echo "yes";
                } else {
                    echo "no";
                }
            } else {
                echo "no";
            }
        } else {
            echo "no";
        }
    }

    public function reorder()
    {
        # Adding the product from product specific page
        $post = $this->input->post();

        if ($post) {
            /* Someone tries to add something to the cart */
            for ($i = 0; $i < $post['total_products']; $i++) {
                // no qty in products specific page default is 1            
                if (isset($post['product_quantity_' . $i])) {
                    $qty = intval($post['product_quantity_' . $i]);
                    if (!$qty) {
                        $this->data['errors'][] = 'Invalid Qty ';
                    }
                } else {
                    $qty = 1; // default QTy
                }
                //  this is  mandatroy
                if (!isset($post['price_id_' . $i]))
                    $this->data['errors'][] = 'Please select a size';

                if (empty($this->data['errors'])) {

                    /* Everything ok. Add it to the cart */
                    $this->cart->add($post['product_id_' . $i], $post['price_id_' . $i], $qty);
                }
            }
        }

        redirect('/' . $this->base_name . '/cart/');
    }

    public function cart()
    {
        # cart check
        if (!$this->cart->cart_check())
            redirect(site_url($this->base_name));
        # Get Cart data
        // Main function reads throught the cart data -  get the revelent details - calculates the  subtotals
        $this->data['cart'] = $this->cart->get();

        $this->template->meta['title'] = $this->title_prefix . ' - ' . ucfirst($this->base_name) . ' - Cart ';

        #bread
        $this->data['breadcrumbs']['/' . $this->base_name . '/cart'] = 'Cart';

        # rendering data to cart completely
        $this->template->add_page($this->base_name . '/checkout/my_cart');
        $this->template->render($this->data);
    }

    public function cart_added()
    {
        $this->template->add_page($this->base_name . '/cart_added');
        $this->template->render($this->data);
    }

    public function pay()
    {
        /**
          GATEWAY
         */
        $this->load->library('form_validation');
        //$postcode = $this->session->userdata('postcode');

        $post = $this->input->post();

        /* User did not post anything. Send him back to the cart */
        if (empty($post)) {
            redirect($this->base_name . '/cart');
            exit;
        }

        $fields = $this->cart->fields();

        /* Validate input */
        foreach ($fields->credit_card as $field) {
            $this->form_validation->set_rules($field['html']['name'], $field['title'], $field['validate']);
        }

        if (!$this->form_validation->run()) {
            $this->checkout();
            return;
        }

        $cart = $this->cart->get();
        $total = 0;
        if ($cart) {
            foreach ($cart as $item) {
                $total += $item['qty'] * $item['price'];
            }
        }

        $shipping = intval($post['shipping']);
        $shipping = ($shipping < 10) ? 10 : $shipping; //prevent form hacking (min $10)

        $coupon = $this->idstore->get_coupon($this->session->userdata('coupon'));
        $coupon_value = 0;
        if ($coupon) {
            if ($coupon->unit == '%') {
                $coupon_value = $total / 100 * $coupon->value;
            } elseif ($coupon->unit == '$') {
                $coupon_value = $coupon->value;
            }
        }

        //Check if cart value has changed
        if ($total != $post['total']) {
            redirect($this->base_name . '/cart/');
        }

        $value = ($total - $coupon_value) + $shipping;
        $order_no = $this->idstore->get_new_order_number();

        if (!isset($this->settings->payment->institute)) {
            die('Not payment settings found');
        }

        if (!in_array($this->settings->payment->institute, array('nab', 'anz', 'eway'))) {
            die("Unknown Payment Institute ({$this->settings->payment->institute})");
        }

        $this->payment = $this->load->library('payment/' . $this->settings->payment->institute, $this->settings->payment);
        $this->payment->add_user_data(array(
            'name_on_card' => $post['name'],
            'first_name' => $post['first_name'],
            'last_name' => $post['last_name'],
            'email' => $post['email'],
            'address' => $post['address'] . ', ' . $post['address2'] . ', ' . $post['suburb'] . ', ' . $post['state'],
            'postcode' => $post['postcode']
        ));

        $result_array = $this->payment->pay($value, $post['cc_no'], $post['cc_expiry_month'] . '/' . $post['cc_expiry_year'], $post['cc_cvv'], $order_no);

        if ($result_array['success'] == false) {
            $this->data['errors'][] = $result_array['response'];
            $this->checkout();
            return;
        }

        $post['coupon_value'] = $coupon_value;

        $this->idstore->save_order($order_no, $cart, $post, $value);
        $this->idstore->send_order_email(
                $post['email'], "Order Confirmation", "Thank you for your order. You will receive another email, once the order has been shipped.", array('cart' => $cart, 'data' => $post));

        $this->idstore->send_order_email(
                $this->settings->site->email, "New order", "A new order was made on your website.", array('cart' => $cart, 'data' => $post));

        $this->template->add_page($this->base_name . '/paid');
        $this->template->render($this->data);
    }

###########################################################################################################################

    /* Little helpers */

    public function cart_set_qty($id, $qty, $redirect = false)
    {
        $this->cart->set_qty(intval($id), intval($qty));
        if ($redirect)
            redirect($this->base_name . '/cart/');
    }

    public function cart_remove($id, $redirect = false)
    {
        $this->cart->remove(intval($id));
        if ($redirect) {
            redirect($this->base_name . '/cart/');
        }
    }

    // AJAX functions
    /**
     *   loading the MINI BILLING and SHIPPING DETAILS
     */
    public function get_billing_and_shipping_details()
    {
        $billing = $this->cart->get_details('billing');
        $shipping = $this->cart->get_details('shipping');
        $shipping_cost = $this->cart->get_details('shipping_cost');

        // find out  if its pick up from here   only for pci up
        $pickup = false; //  by default its always false
        if (is_array($shipping_cost)) {
            if ($shipping_cost['name'] == 'pickup') {
                $pickup = true;
            }
        }

        /* required for Update cart object for changing country At RUNTIME */

        $shipping_details = $this->cart->get_details('shipping'); // get h shippinng details

        if ($shipping_details) {
            $shipping_array = array();
            $shipping_array['pickup'] = $pickup;
            if ($pickup == false) {
                $shipping2 = $this->idstore->shipping_options($shipping_details['s_country']);
                if ($shipping2) {
                    $shipping_array['name'] = $shipping2->name;
                    $shipping_array['display_mess'] = $shipping2->display_mess;
                    $shipping_array['cost'] = $shipping2->cost;
                    $shipping_array['cost_usd'] = $shipping2->cost_usd;
                } else { // apply default valus
                    $shipping_array['name'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['display_mess'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['cost'] = $this->config->item('default_shipping_cost');
                    $shipping_array['cost'] = $this->config->item('default_shipping_cost_usd');
                }

//                $this->cart->apply_shipping_cost($shipping_array);
            }
        }

        /* END Added by Cintan */
        if ($billing && $shipping) {
            //both are avaliable
            $html = $this->load->view($this->base_name . '/checkout/components/mini_billing_and_shipping_details', array('billing' => $billing,
                'shipping' => $shipping, 'pickup' => $pickup), true);

            echo json_encode(array('code' => 201,
                'message' => 'Billing&Shiping',
                'results' => $html));
        } else {
            //  TODO: search  which one is not set and rediect to  that page
            //  this shoudl not happen though
        }
    }

    /*  AJAX functions
      /*
     *   Calculating extra costs added to cart at payment and order details page
     */

    public function calculate_extra_order_costs()
    {
        $post = $this->input->post();

        if (isset($post) && $post['todo'] == "push") {
            $id = $post['id'];
            $charge_data = $this->idstore->getThisExtraCharge($id);
            $set_data = array(
                'name' => $charge_data['name'],
                'val_aud' => $charge_data['val_aud'],
                'val_usd' => $charge_data['val_usd'],
                'min_amount' => $charge_data['min_amount'],
            );

            $this->mycart->apply_extra_charges($id, $set_data);
        } elseif (isset($post) && $post['todo'] == "pop") {
            $id = $post['id'];

            $arrTemp = $this->session->userdata['extra_charges'];
            unset($arrTemp['charge_' . $id]);

            $this->session->set_userdata(
                    array(
                        'extra_charges' => $arrTemp
                    )
            );
            echo "done";
            die;
        } else {
            
        }
    }

    /**
     * Helper function used for checking if pick is already applied or not
     * @return bool
     */
    public function check_shipping_pickup()
    {
        $is_shipping_applied = $this->cart->get_shipping_cost();
        if ($is_shipping_applied != false) {
            if ($is_shipping_applied['name'] == 'pickup') { // only check for pikup
                return true;
            } else {
                return false;
            }
        }
    }

    /**
     * user when checks shipping pickup option
     */
    public function apply_shipping_pickup_options()
    {
        $pickup = $this->check_shipping_pickup();
        if (!$pickup) {

            $shipping_array = array();
            $shipping_array['name'] = 'pickup';
            $shipping_array['display_mess'] = 'Pick up';
            $shipping_array['cost'] = 0.00; // set value of pick up
//            $this->cart->apply_shipping_cost($shipping_array);

            echo json_encode(array('code' => 201,
                'message' => 'shipping entered',
                'results' => true));
        } else {
            // if not a pick up option
            $shipping_details = $this->cart->get_details('shipping'); // get the shippinng details
            if ($shipping_details) {
                $shipping_array = array();
                $shipping = $this->idstore->shipping_options($shipping_details['s_country']);

                if ($shipping) {
                    $shipping_array['name'] = $shipping->name;
                    $shipping_array['display_mess'] = $shipping->display_mess;
                    $shipping_array['cost'] = $shipping->cost;
                    $shipping_array['cost_usd'] = $shipping->cost_usd;
                } else { // apply default valus
                    $shipping_array['name'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['display_mess'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['cost'] = $this->config->item('default_shipping_cost');
                    $shipping_array['cost_usd'] = $this->config->item('default_shipping_cost_usd');
                }

//                $this->cart->apply_shipping_cost($shipping_array);
                // remvoe shipping
                echo json_encode(array('code' => 201,
                    'message' => 'remove pick up successful ',
                    'results' => null));
            }
        }
    }

    /**
     * what todo :
     * - check if shiping session is already filled - if filedd deletthe seesion  
     * make new ajax function  to load  - db sipiing otions - same function  send array[1] details to apply shipinng optionsfunc
     *
     *  - more more ajax function to updaate selcted shipping option-   view(id of shiiping )- apply update/apply shipping optin  function   /
     *  - when user chnages country - look above 
     * - 
     */
    public function get_shipping_options()
    {
        //echo "on";
        //default
        $pickup = $this->check_shipping_pickup(); // true

        $shipping_details = $this->cart->get_details('shipping'); // get h shippinng details
        $shipping_cost_details = $this->cart->get_details('shipping_cost'); // get h shippinng details        
        // ['shipping'] -options shipping_options[]
        if ($shipping_details) {
            $shipping_array = array();
            $shipping_array['pickup'] = $pickup;
            if ($pickup == false) {
                $shipping = $this->idstore->shipping_options($shipping_details['s_country']);

                if ($shipping && $this->config->item('countrywide_shipping')) {
                    if (empty($shipping_cost_details)) {  // Shipping cost been setted for the first time here
                        $shipping_array['shipping_id'] = $shipping[0]->store_shippings_id;
                        $shipping_array['name'] = $shipping[0]->name;
                        $shipping_array['display_mess'] = $shipping[0]->display_mess;
                        $shipping_array['description'] = $shipping[0]->description;
                        $shipping_array['cost'] = $shipping[0]->cost;
                        $shipping_array['cost_usd'] = $shipping[0]->cost_usd;

                        $this->cart->apply_shipping_cost($shipping_array);
                    } else {

                        foreach ($shipping as $key => $value) {
                            if ($shipping_cost_details['shipping_id'] == $value->store_shippings_id) {
                                $shipping_array['shipping_id'] = $value->store_shippings_id;
                                $shipping_array['name'] = $value->name;
                                $shipping_array['display_mess'] = $value->display_mess;
                                $shipping_array['description'] = $value->description;
                                $shipping_array['cost'] = $value->cost;
                                $shipping_array['cost_usd'] = $value->cost_usd;

                                $this->cart->apply_shipping_cost($shipping_array);
                            } else {
                                // In first iteration if it will not found the exact matching id
                                // then it will set first one as default                                
                                if ($key == 0) {
                                    $shipping_array['shipping_id'] = $shipping[0]->store_shippings_id;
                                    $shipping_array['name'] = $shipping[0]->name;
                                    $shipping_array['display_mess'] = $shipping[0]->display_mess;
                                    $shipping_array['description'] = $shipping[0]->description;
                                    $shipping_array['cost'] = $shipping[0]->cost;
                                    $shipping_array['cost_usd'] = $shipping[0]->cost_usd;

                                    $this->cart->apply_shipping_cost($shipping_array);
                                    continue;
                                } else {
                                    continue;
                                }
                            }
                        }
                    }
                } else { // apply default values
                    $shipping_array['name'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['display_mess'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['cost'] = $this->config->item('default_shipping_cost');
                    $shipping_array['cost_usd'] = $this->config->item('default_shipping_cost_usd');

                    $this->cart->apply_shipping_cost($shipping_array);
                }
            }

            //var_dump($shipping_array); var_dump($shipping_details); die(); // remember this  jai
            $shipping_array['country'] = $shipping_details['s_country'];
            $html = $this->load->view($this->base_name . '/checkout/components/shipping_options', array('shipping' => $shipping_array, 'shipping_options' => $shipping), true);

            echo json_encode(array('code' => 201,
                'message' => 'shipping entered',
                'results' => array($html,
                    $pickup)));
        } else {
            echo json_encode(array('code' => 403,
                'message' => 'shipping details not entered',
                'results' => null));
        }
    }

    public function change_shipping_costs()
    {
        $pickup = false;

        $post = $this->input->post();
        $shipping_id = $post['id'];

        $shipping_details = $this->cart->get_details('shipping'); // get h shippinng details
        $shipping_cost_details = $this->cart->get_details('shipping_cost'); // get h shippinng details

        if ($shipping_details) {
            $shipping_array = array();
            $shipping_array['pickup'] = $pickup;// $pickup
            if ($pickup == false) {
                $shipping = $this->idstore->shipping_options_custom($shipping_id);

                if ($shipping) {
                    $shipping_array['shipping_id'] = $shipping[0]->store_shippings_id;
                    $shipping_array['name'] = $shipping[0]->name;
                    $shipping_array['display_mess'] = $shipping[0]->display_mess;
                    $shipping_array['description'] = $shipping[0]->description;
                    $shipping_array['cost'] = $shipping[0]->cost;
                    $shipping_array['cost_usd'] = $shipping[0]->cost_usd;

                    if ($shipping_cost_details['shipping_id'] == $shipping[0]->store_shippings_id) {
                        echo 'no';
                    } else {
                        $this->cart->apply_shipping_cost($shipping_array);
                        $shipping_cost_details = $this->cart->get_details('shipping_cost');
                        echo 'yes';
                    }
                } else { // apply default values
                    $shipping_array['name'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['display_mess'] = $this->config->item('default_shipping_cost_message');
                    $shipping_array['cost'] = $this->config->item('default_shipping_cost');
                    $shipping_array['cost_usd'] = $this->config->item('default_shipping_cost_usd');

                    $this->cart->apply_shipping_cost($shipping_array);
                    echo 'yes';
                }
            }
        } else {
            echo 'no';
        }
    }

    public function update_delivery_options_info()
    {
        $shipping_cost_details = $this->cart->get_details('shipping_cost'); // get shippinng details

        if ($this->session->userdata("site_currency") == "aud") {
            $amount = "$" . number_format($shipping_cost_details['cost'], 2, '.', '') . " AUD";
        } else {
            $amount = "$" . number_format($shipping_cost_details['cost_usd'], 2, '.', '') . " USD";
        }

        echo "<p>" . $shipping_cost_details['name'] . "</p>";
        echo "<p>Cost : <strong>" . $amount . "</strong></p>";
    }

    /**
     *  have shipping country entreed
     * @return mixed //  false if not avaliable
     */
    public function check_shipping_options()
    {
        if ($this->cart->get_details('shipping') != false) {
            echo json_encode(array('code' => 201,
                'message' => 'shipping details are avaliable',
                'results' => $this->cart->get_details('shipping')));
        } else {
            echo json_encode(array('code' => 403,
                'message' => 'shipping details not entered',
                'results' => null));
        }
    }

    /**
     *  Updating the  qty of product
     */
    public function qty_update()
    {
        $data = $this->post_data;
        $return = $this->cart->update_qty($data['id'], $data['qty']);
        if ($return === false) {
            echo json_encode(array('code' => 403, 'message' => 'unable to update product qty'));
        } else {
            echo json_encode(array('code' => 201,
                'message' => 'quantity updated'));
        }
    }

    /**
     * User when used coupon code
     * -  check if its already applied
     * -  check if valid  and apply this
     * @return bool
     */
    public function check_coupon_code()
    {
        //Get Post data
        $data = $this->post_data;

        // Get coupon details
        $result = $this->idstore->get_coupon($data['code']); //  apply  coupon

        if ($result) {
            if ($this->cart->apply_coupon($result) == false) {
                echo json_encode(array('code' => 403,
                    'message' => 'coupon already applied'));
            } else {
                echo json_encode(array('code' => 201,
                    'message' => 'Coupon applied'));
            }
        } else { // checking if it is email referral or not
            if ($this->config->item('coupon_code_referrar')) {

                $result1 = $this->idstore->get_referral($data['code']); //  apply  coupon

                if ($result1) {
                    if ($result1->code === $this->session->userdata('email')) {
                        echo json_encode(array('code' => 403,
                            'message' => "You can not use your email as referral email"));
                    } else {
                        $result1->value = REFERRAL_PERCENTAGES;
                        $result1->unit = '%';

                        if ($this->cart->apply_referral($result1) == false) {
                            echo json_encode(array('code' => 403,
                                'message' => 'Referral Email id already applyied'));
                        } else {
                            echo json_encode(array('code' => 201,
                                'message' => 'Referral Email id applied'));
                        }
                    }
                } else {
                    echo json_encode(array('code' => 403,
                        'message' => "Coupon/Referrar Email Expried or not valid"));
                }
            } else { # if referral system not exists
                echo json_encode(array('code' => 403,
                    'message' => "Coupon not valid or Expried"));
            }
        }
    }

    /*
     *  Updae the dispying cart with  any chnages
     * @param null $product_id
     */

    public function update_displaying_cart($product_id = NULL)
    {
        # intilize
        $return_array = array();
        $html = array();
        $h = '';
        # get the current cart contents
        $cart = $this->cart->get();

        if (!$cart) {
            echo json_encode(array('code' => 403,
                'message' => ' cart empty ',
                'results' => '<p> cart is empty </p>'));
            return;
        }
        # if there is a given product id add it to cart --  todo : this can be removed
        if ($product_id) {
            # get the cart id of the product (  THIS Should not be here )
            $cart_id = $this->cart->get_cartid_by_productid($product_id);
            $return_array['subtotal'] = $cart[$cart_id]['subtotal'];
            $return_array['subtotal_usd'] = $cart[$cart_id]['subtotal_usd'];
            $return_array['total'] = 500; // dummy value
        } else {

            $return_array = $cart; // this always valid
        }

        # Disocunts
        ##  calculate Spend over discount
        if ($this->config->item('spent_over_discount')) {
            # if there there is a valid SOD - they get the revelent message
            $spent_over_discount = $this->cart->get_spent_over_discount();
            #  assgin the relevent message to be displayed
            if ($spent_over_discount) {
                $summary['spent_over_discount'] = $spent_over_discount->display_mess;
                $spent_over_discount = $spent_over_discount->amt;
            }
        }
        ## COUPON CODE - discount
        if ($this->config->item('coupon_code')) {
            #  chekc if applied
            $coupon = $this->cart->is_coupon_applied();
            if ($coupon) {
                $summary['coupon_applied'] = $coupon->code;
            }
        }

        # Calculate Shipping
        $shipping = $this->cart->get_shipping_cost();

        if ($shipping) {
            $summary['shipping_message'] = $shipping['display_mess'];
            $summary['shipping_cost'] = $shipping['cost'];
            $summary['shipping_cost_usd'] = $shipping['cost_usd'];
        }

        # ALWAYS LOAD THESE
        //grand total
        $summary['total'] = $this->cart->get_cart_total_after_discount(); //  pushing the total

        $summary['cart_total'] = $this->cart->get_cart_total(); //  pushing the total
        $summary['cart_total_usd'] = $this->cart->get_cart_usd_total(); //  pushing the total

        $summary['bulk_total'] = $this->cart->get_bulk_total(); //  pushing the total
        $summary['bulk_total_usd'] = $this->cart->get_bulk_usd_total(); //  pushing the total
        //Grand Discount
        $summary['discount'] = $this->cart->get_cart_total_discount(); // adds all discounts
        # load  view for each cart item
        foreach ($cart as $product) :
            $h .=$this->load->view($this->base_name . '/checkout/components/cartItem', array('product' => $product), true);
        endforeach;
        $html['cart'] = $h;

        // assign view html to variable
        $html['ordersummary'] = $this->load->view($this->base_name . '/checkout/components/order_summary', array('summary' => $summary), true);

        #json encoded response
        echo json_encode(array('code' => 201,
            'message' => 'quantity updated',
            'results' => $html));
    }

    /**
     * Display for Mini order summary box
     */
    public function get_mini_order_summary()
    {

        #Intilize
        $html = array();
        $mini_summary = array();
        $discounts = array();

        // Discounts  variables
        # Coupon Code
        if ($this->config->item('coupon_code')) {
            $coupon = $this->cart->is_coupon_applied();

            if ($coupon) {
                // updated this so that it calculates the amount
                // If you want other things to be displayed -- chnage the way $coupn  has name and other things

                $discounts['coupon_applied'] = '&#36;' . number_format((float) $this->cart->calculate_coupon_amt(true), 2, '.', '');
            }
        }
        # Spend over  discount
        if ($this->config->item('spent_over_discount')) {
            $spent_over_discount = $this->cart->get_spent_over_discount();
            if ($spent_over_discount) {
                $discounts['spent_over_discount'] = '&#36;' . $spent_over_discount->amt;
            }
        }


        # calculate the shipping costs
        $shipping = $this->cart->get_shipping_cost();

        if (count($shipping) > 0) {
            $mini_summary['shipping_message'] = $shipping['display_mess'];
            $mini_summary['shipping_cost'] = $shipping['cost'];
            $mini_summary['shipping_cost_usd'] = $shipping['cost_usd'];
        }

        //  OTHER ALWAYS  always get these variables
        $mini_summary['cart_total'] = $this->cart->get_cart_total();
        $mini_summary['cart_total_usd'] = $this->cart->get_cart_usd_total();

        $mini_summary['bulk_total'] = $this->cart->get_bulk_total();
        $mini_summary['bulk_total_usd'] = $this->cart->get_bulk_usd_total();

        $mini_summary['grand_total'] = $this->cart->get_cart_total_after_discount();

        $mini_summary['all'] = $this->mycart;
        # Load HTML data
        $html['miniordersummary'] = $this->load->view($this->base_name . '/checkout/components/mini_order_summary', array('discounts' => $discounts, 'mini_summary' => $mini_summary), true);


        # json ouput  to render
        echo json_encode(array('code' => 201,
            'message' => '',
            'results' => $html,
        ));
    }

    public function check_registered_email()
    {
        $post = $this->input->post();

        $getEmailAddress = $this->idstore->isEmailRegistered($post['email']);

        if ($getEmailAddress['total'] == "1") {
            echo "yes";
        } else {
            echo "no";
        } die;
    }

}
