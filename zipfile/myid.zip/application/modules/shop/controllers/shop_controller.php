<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */

class Shop_controller extends MY_Controller
{
	public function __construct ()
	{
		parent::__construct ();

		$this->load->config ('shop_config');


		#Javascaript
		$this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/shop.js'));
		$this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/selectionCountry.js'));
		$this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardValidator.js'));
		$this->template->add_script(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/jquery.creditCardTypeDetector.js'));

		#css
		$this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/css/store.css'));
		$this->template->add_css(base_url('application/modules/' . $this->base_name . '/assets/js/creditcardvalidator/creditCardTypeDetector.css'));

	}
} 