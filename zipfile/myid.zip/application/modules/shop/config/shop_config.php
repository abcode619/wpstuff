<?php
    /**
     *  Author : jay kora
     *  Email : kora.jayaram@gmail.com
     *  Company : Iddigital
     */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

// please set this up before intilizing the shop
$config['base_name'] = 'shop'; // plase do not change this ( if changed  make sure that the document name should also ne changed)
$config['site_name'] = 'MYID cart';

// SHOP PRODUCT SPECIFIC PAGE //
#shipping details
$config['is_shipping_avaliabe'] = TRUE; // true or false
$config['shipping_table_name'] = 'store_shippings'; // null or string  - assumption status field  = 1 and field - spend_over is  necessary
$config['spent_over_discount'] = FALSE; // true / false;
# Adding the products again
$config['add_product_again'] = FALSE; // true or false--  add an existing cart product  increments the qty by 1 if  enabled  else returns the rowid

# Coupon code
$config['coupon_code'] = TRUE; // true / false
$config['coupon_code_referrar'] = TRUE; // true / false
$config['coupon_code_display_text'] = ' Do you have a coupon code ?'; //  enter the text you want to display

# Login functionality in cart

// Added By Hardik 
$config['login_module_in_checkout'] = TRUE; // to put login functionality while checkout
$config['login_user_after_checkout'] = TRUE; // This will only work if the above one is true.
// errors  i  found = when above settings are false , then the  while filling the shipping address details  email field -- comes up saying " you are already"

# Extra shipping charges
$config['extraa_charges'] = False;

# shipping
$config['countrywide_shipping'] = False;

# Default shipping  has to be used 
$config['default_shipping_cost'] = 75.00; //  if no shipping is specified in db we apply  this
$config['default_shipping_cost_usd'] = 75.00; //  if no shipping is specified in db we apply  this
$config['default_shipping_cost_message'] = 'Default Shipping price $75.00'; //  if no shippin is specified in db we apply  this

//  this is not working -- for soem reson 
$config['pick_up_option'] = false; // true or false // show pick up option -- shipping value  will be 0.00
$config['pick_up_option_display_message'] = 'I prefer to pick up my order .';

# Order email
$config['email_debug'] = FALSE; // true or false default false;
$config['from_email'] = 'developer.esb@gmail.com'; // true or false default false;
$config['reply_to_email'] = 'developer.esb@gmail.com'; // true or false default false;
$config['reply_to_name'] = 'Orgone Energy Australia'; // true or false default false;
//$config['to_email'] = 'support@orgoneenergy.org'; // true or false default false;
$config['to_email'] = 'developer.esb@gmail.com'; // true or false default false;
$config['order_email_subject'] = 'New order email'; // true or false default false;
$config['order_email_heading'] = 'New Order Email';
$config['order_email_intro'] = 'intro'; /// put in  intro html here
#payement
$config['payment_institute'] = 'eway';        // Payment institute
$config['live_payment_user_id']= '14147708';
//$config['live_payment_user_id'] = '14147708'; //  jay@iddigital.com.au ( Account mapped with paypal API  )Give  in  live payment userid
$config['test_payment_user_id'] = '91241154'; //chris@iddigital.com.au.sand
