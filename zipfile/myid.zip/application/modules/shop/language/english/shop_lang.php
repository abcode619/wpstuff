<?php

	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
	if(!defined('BASEPATH'))
{
	exit('No direct script access allowed');
}
	/**
	 * Welcome Page Language File
	 */

	// Titles
	$lang['site name']                    = "PARC %s";
	$lang['page title checkout']          = "PARC Shop - checkout";

	// Meta Title s
	$lang['page meta title address details'] = "Address details ";
	$lang['page meta title shipping details'] = "Shipping details ";
	$lang['page meta title payment summary'] = "payment summary";
	$lang['page meta title order completed'] = "Order Completed";

	// Meta Description
	$lang['page meta description address details'] = "Address details ";
	$lang['page meta description shipping details'] = "Shipping details ";
	$lang['page meta description payment summary'] = "payment summary";
	$lang['page meta description order completed'] = "Order Completed";

	 //  default email subject
	$lang['default email subject '] ='You have placed an order';

