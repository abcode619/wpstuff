<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
/*  idstore  class  extends MY_Model  NOTE : doesn't uses any  functions from  that ( just  inherit core functions )
 *  Responsibility :  shop infractions  with database
 * 		-  Defining the table names
 * 		-
 *  Infractions :
 *  TODO : clean up  and comment and refactor can be done bett
 */

class idstore extends MY_Model {

	var $product_table_name;
	var $price_table_name;
	var $categories_table_name;
	var $brand_table_name;
        var $uses_table_name;

	//shipping table name
	var $shipping_table_name;
	var $spent_over_discount_table_name;


	function __construct() {
		parent::__construct();
		$this->load->model('myid');
		 # get settings
		$this->settings = $this->myid->settings();

		# Load table names     	// config
		$this->product_table_name = 'store_product';

		$this->price_table_name = 'store_price';

		$this->categories_table_name = 'store_categories';

		$this->brand_table_name = 'store_brand';
		
                $this->uses_table_name = 'store_uses';

		// Config initialize
		if($this->config->item('spent_over_discount')){
			$this->set_spent_over_discount_table();
		}

		#shipping  table details
		$this->shipping_table_name = 'store_shippings';


	}


	public function set_spent_over_discount_table ()
	{
		$this->spent_over_discount_table_name = 'store_spent_over_discount';
		// by default  status field  should be there
	}


	# Common Functions

	/**
	 *   status field name  and ENUM is 1,0
	 */
	private function apply_status_filter()
	{
		$this->db->where('status','1');
	}

	/**
	 * @param null $key_name
	 * @param string $order
	 */
	private function apply_order_filter ($key_name = NULL, $order='ASC')
	{
		if(!empty($key_name)){
			$this->db->order_by ($key_name,$order); // default is ASCE
		}else{
			$this->db->order_by ('order_index');
		}
	}

	##### DB operations to function #########

	# categories functions

	public function get_categories_with_products()
	{

		$this->apply_status_filter();
		$this->apply_order_filter();

		$results = $this->db->get($this->categories_table_name)->result();
		if(count($results)>0)
		{
			foreach($results as $key => $result)
			{
				$results[$key]->noproducts = count($this->get_products($result->store_categories_id));
			}
			return $results;
		}else
		{
			return NULL;
		}

	}

	public function get_categories() {

		$this->apply_status_filter();
		$this->apply_order_filter();
		return $this->db
			->get($this->categories_table_name)
			->result();
	}

	public function get_category($slug) {
		return $this->db
			->where('slug', $slug)
			->get($this->categories_table_name)
			->row();
	}

        public function get_use($slug) {
		return $this->db
			->where('slug', $slug)
			->get($this->uses_table_name)
			->row();
	}
        
	# Brand functions  #####

	/**
	 * Return brands with count of products with each brand
	 * @return null
	 */
	public function get_brands() {
		$results = $this->db
						->where('status', '1')
						->order_by('order_index')
						->get($this->brand_table_name)
						->result();

		if(count($results) > 0)
		{// if valid results
			foreach($results as $key=>$result)
			{
				$results[$key]->noproducts = count($this->get_products_by_brand($result->store_brand_id));
			}
			return $results;
		}else{

			return null;
		}

	}

	public function get_brand($slug) {
		return $this->db
			->where('slug', $slug)
			->get($this->brand_table_name)
			->row();
	}

	public function get_brand_by_id($id) {
		return $this->db
			->where($this->brand_table_name.'_id', $id)
			->get($this->brand_table_name)
			->row();
	}

        public function get_use_by_id($id) {
		return $this->db
			->where($this->uses_table_name.'_id', $id)
			->get($this->uses_table_name)
			->row();
	}
        
	# Product functions ####################

	public function get_all_products ()
	{
		$this->apply_status_filter ();
		$this->apply_order_filter ();

		$products = $this->db
			->get ($this->product_table_name)
			->result ();
                
                foreach ($products as $key => &$p) {
			$this->get_prices($p);
			
		}

		return $products;
	}

	public function get_featured_products_by_last_updated()
	{
		$this->apply_status_filter();
		$this->db->where('featured','1');
		$this->apply_order_filter('updated_date', 'DESC');
		$products = $this->db->get($this->product_table_name)->result();

		return $products;
	}

        /*---- Sorting any array of objects ----*/
        public function _osort(&$products, $p) {
            usort($products, create_function('$a,$b', 'if($a->' . $p . ' == $b->' . $p . ') { return 0; } else { return ($a->' . $p . ' > $b->' . $p . ' ? 1 : -1); }'));
        }
        
	public function get_products($category, $sortBy = '') {
            
		$products = $this->db
			->where('map_table_a', $this->product_table_name)
			->where('map_id_a = store_product.store_product_id')
			->where('map_table_b', 'store_categories')
			->where('map_id_b', $category)
			->where('status', '1')
			->order_by('order_index')
			->get('store_product, map')
			->result();
                
		foreach ($products as $key => &$p) {
			$this->get_prices($p);
			$p->brand = $this->get_brand_by_id($p->store_brand_id);
		}
                                
                if(isset($sortBy) && $sortBy == 'highest')
                {
                    $this->_osort($products, 'min_price');
                    $result= array_reverse($products);                    
                    return $result;
                }
                elseif(isset($sortBy) && $sortBy == 'lowest')
                {
                    $this->_osort($products, 'min_price');
                    return $products;
                } else {
                    $this->_osort($products, 'name');                    
                    return $products;
                }
	}
         

            
	public function get_products_of_uses($use, $sortBy = '') {
		$products = $this->db
			->where('map_table_a', $this->product_table_name)
			->where('map_id_a = store_product.store_product_id')
			->where('map_table_b', 'store_uses')
			->where('map_id_b', $use)
			->where('status', '1')
			->order_by('order_index')
			->get('store_product, map')
			->result();               
                
		foreach ($products as $key => &$p) {
			$this->get_prices($p);
			
		}
                
                if(isset($sortBy) && $sortBy == 'highest')
                {
                    $this->_osort($products, 'min_price');
                    $result= array_reverse($products);                    
                    return $result;
                }
                elseif(isset($sortBy) && $sortBy == 'lowest')
                {
                    $this->_osort($products, 'min_price');
                    return $products;
                } else {
                    $this->_osort($products, 'name');                    
                    return $products;
                }
	}

	public function get_featured_products() {
		$products = $this->db
			->where('status', 1)
			->where('featured', 1)
			->get('store_product')
			->result();
		foreach ($products as $key => &$p) {
			$this->get_prices($p);
			$p->brand = $this->get_brand_by_id($p->brand_id);
		}
		return $products;
	}

	public function get_products_by_brand($brand_id ) {
		$brand = $this->get_brand_by_id($brand_id);
		$products = $this->db
			->where('product.store_brand_id', $brand_id)
			->order_by('product.order_index')
			->get('store_product product')
			->result();
		foreach ($products as $key => &$p) {
			$this->get_prices($p);
			$p->brand = $brand;
		}
		return $products;
	}

	public function get_product($id, $details = true) {
		$product = $this->db
			->where('store_product_id', $id)
			->get('store_product')
			->row();

		if (!$product)
			return false;

		if (!$details)
			return $product;

		$product->categories = $this->db
			->select('name, slug')
			->where('map_table_a', 'store_product')
			->where('map_id_a', $id)
			->where('map_table_b', 'store_categories')
			->where('map_id_b = store_categories.store_categories_id')
			->where('status', '1')
			->order_by('order_index')
			->get('map, store_categories')
			->result();
			;

		$product->brand = $this->get_brand_by_id($product->store_brand_id);
		$this->get_prices($product);
		return $product;
	}

	public function get_product_by_slug ($slug, $details = true)
	{
		$product = $this->db
			->where ('slug', $slug)
			->get ('store_product')
			->row ();

		if (!$product)
		{
			return false;
		}

		if (!$details)
		{
			return $product;
		}

		$product->categories = $this->db
			->select ('name, slug')
			->where ('map_table_a', 'store_product')
			->where ('map_id_a', $product->store_product_id)
			->where ('map_table_b', 'store_categories')
			->where ('map_id_b = store_categories.store_categories_id')
			->where ('status', '1')
			->order_by ('order_index')
			->get ('map, store_categories')
			->result ();;

		$product->brand = $this->get_brand_by_id ($product->store_brand_id);                
		$this->get_prices ($product);

		return $product;
	}

	/**
	 * @param $id
	 * @return mixed
	 */
	function get_related_products_in_same_category($id) {

                   	$product_categories =  $this->db
			->where('map_id_a', $id)
			->where('map_table_a', 'store_product')
			->where('map_table_b', 'store_categories')
			->get('map')
			->result();

			// a product can have more than one cat hence  yes its stupid
			$related_products =array();
			foreach($product_categories as $cat)
			{

				$pr= $this->db
					->select('map.map_id_a')
					->where('map_id_b', $cat->map_id_b)
					->where('map_id_a !=', $id)
					->where('map_table_a', 'store_product')
					->where('map_table_b', 'store_categories')
					->get('map')
					->result();
			}

			// TODO ::there might be  a repetation  not sure through
                        $count = 0;
			foreach($pr as $p){
			    $related_products[$count] = $this->db
			                        ->where('store_product_id',$p->map_id_a)
			                        ->get('store_product')
			                        ->row();
                            $this->get_prices($related_products[$count]);
                            $count++;
			}

			return $related_products;

	}

	public function get_prices(&$product) {            
                                   
		$product->prices = $this->db
			->where('store_product_id', $product->store_product_id)
                        ->order_by('store_price_id')
			->get('store_price')
			->result();
                                               
		if (count($product->prices) > 1) {                   
                        
			/* We have multiple unit sizes, get the cheapest price */
			$product->min_price = 99999999999999999;
                        
			foreach ($product->prices as $price) {                            
				if ($product->min_price >= $price->price && $price->price != 0) {
					$product->min_price = $price->price;
					$product->min_price_usd = $price->price_usd;
					$product->min_sale_price = $price->sale_price;
					$product->min_sale_price_usd = $price->sale_price_usd;
					$product->sale_end = $price->sale_end;
					$product->original_price = $price->original_price;
					$product->price_id = $price->store_price_id;
                                        $product->to_be_shipped = $price->to_be_shipped;
				}
			}

		} else if (count($product->prices) == 1) {                    
			/* Only one size available */
			$product->price = $product->prices[0]->price;
			$product->min_price = $product->prices[0]->price;
			$product->price_usd = $product->prices[0]->price_usd;
			$product->min_price_usd = $product->prices[0]->price_usd;
                        $product->min_sale_price = $product->prices[0]->sale_price;
			$product->min_sale_price_usd = $product->prices[0]->sale_price_usd;
                        $product->sale_end = $product->prices[0]->sale_end;
			$product->original_price = $product->prices[0]->original_price;
                        $product->price_id = $product->prices[0]->store_price_id;
                        $product->to_be_shipped = $price->to_be_shipped;
		} else {
			return false;
		}
		return true;
	}

	// TODO : need to rename this function this  is even used to get price detauils
	public function get_product_size($product_id, $size_id) {
		return $this->db
			->where($this->price_table_name.'_id', $size_id)
			->where($this->product_table_name.'_id', $product_id)
			->get($this->price_table_name)
			->row();
	}

	/**
	 * Fetch the spent over discounts and trim expired discounts
	 * @return bool
	 */
	public function get_spent_over_discounts ()
	{
		// check the config if tru
		if($this->config->item('spent_over_discount')){

			// get all active records by orderindex
			$this->db->order_by ('limit',"desc");
			$results = $this->db
				->where ('status', 1)
				->get ($this->spent_over_discount_table_name)
				->result ();
			$today = date ("Y-m-d");

			//check for expiry
			foreach ($results as $key =>$result)
			{
				if(!empty($result->expiry) && $result->expiry_check !='0'){
					if(strtotime($result->expiry) < strtotime($today) ){
						unset($results[ $key ]); //  expired hence unset the value
					}
				}
			}

			return $results;//   return only valid results

		}else{
			return false; // config not set
		}
	}

	//----------------------------------------------------------------------
	// get coupon details

	public function get_coupon_details ($code)
	{

		$result =  $this->db
			->where (array('status'=> 1,'name'=>$code))
			->get ($this->coupon_table_name)
			->result ();
	}
	//----------------------------------------------------------------------

	// shipoing get the spendover limit spend _over < total
	public function get_shipping_spend_over_options($total)
	{
		$methods = $this->shipping_options ();
		$value = false;
		foreach ($methods as $key => $method)
		{
			if (!empty($method->spend_over) && $method->spend_over <= $total )
			{
				$value =  $methods[$key];
			}
		}
		return $value;
	}

	// Shipping options
	public function get_shipping_methods ()
	{
		$methods = $this->shipping_options();
		foreach ($methods as $key => $method)
		{
			if(!empty($method->spend_over))	{
				unset($methods[$key]);
			}
		}

		return $methods;
	}

	// getting shipping options if  avaliable
	public function shipping_options ($country=NULL)
	{
            //  to do - fetch the db all options relevent ot the selcted country - 
            //  return from db query = 
            //  array (array('shippi_ngname'=>'flatshipping'),array('shipping_name'=>bulk_shipping))
            
            $this->db->select("store_shipping_countries_id");
            $this->db->where("name", $country);
            $country_id_data = $this->db->get('store_shipping_countries')->row();
            
            $country_id = $country_id_data->store_shipping_countries_id;
            
            $this->db->select('store_shippings.*');
            $this->db->from('store_shippings');
            $this->db->join('map', 'map.map_id_a = store_shippings.store_shippings_id');
            $this->db->where('map.map_table_a', "store_shippings");
            $this->db->where('map.map_table_b', "store_shipping_countries");
            $this->db->where('map.map_id_b', $country_id);
            $this->db->order_by('store_shippings.order_index');
            
            $query = $this->db->get()->result();
            
//            echo "<pre>";
//            print_r($country_id);
//            echo $this->db->last_query();
//            print_r($query);
//            die;
            
            if(!empty($query))
            {
                return $query;
            } else {
                return false;
            }
            
//            $this->db->order_by ('order_index');
//                            $results =  $this->db
//                                    ->where ('status', 1)
//                                    ->get ($this->shipping_table_name)
//                                    ->result ();
//                
//                $others_data = array();
//                
//		if(!empty($country) && count($results) > 0)
//		{
//			foreach($results as $key => $result)
//			{   
//				if($result->destination == $country){
//					return $results[$key];
//                                } elseif($result->destination == "Others") {
//                                    $others_data = $results[$key];
//                                } else {
//                                    continue;
//                                }
//			}  
//                        if(!empty($others_data))
//                        {
//                            return $others_data;                        
//                        } else{
//                            return false;
//                        } 
//                        
////                        if($result->destination == 'Others')    {
////				return $results[$key];
////			}
//
//		} else
//		{ // If Nothing is found
//			return false;
//		}

	}
        
	// getting shipping options if  avaliable
	public function shipping_options_custom ($shipping_id = NULL)
	{
            //  to do - fetch the db all options relevent ot the selcted country - 
            //  return from db query = 
            //  array (array('shippi_ngname'=>'flatshipping'),array('shipping_name'=>bulk_shipping))
                       
            
            $this->db->order_by ('order_index');
                            $results =  $this->db
                                    ->where ('status', 1)
                                    ->where ('store_shippings_id', $shipping_id)
                                    ->get ($this->shipping_table_name)
                                    ->result ();
                
                $others_data = array();
                
		if(!empty($shipping_id) && count($results) > 0)
		{			
                    return $results;
		} else
		{ // If Nothing is found
			return false;
		}

	}




	# Order functions

	/**
	 * returns the last enteres record +1
	 * @return int
	 */
	public function get_new_order_number()
	{
		$last = $this->db->select_max('store_order_id')->get('store_order')->row()->store_order_id;

		return intval($last) + 1;
	}

	/**
	 * Responsible for save the order into respective tables
	 * @param $id
	 * @param $cart
	 * @param $data
	 * @param $paid
	 * @return mixed
	 */
	public function save_order($id, $cart, $data, $paid, $transaction_id, $registered_user_id, $wholesaler_amount, $payment_mode)
	 {                               

//                echo "<pre>";
//                echo $id;echo "<hr/>";
//                print_r($cart);echo "<hr/>";
//                print_r($data);echo "<hr/>";
//                echo $paid;echo "<hr/>";
//                echo $transaction_id;echo "<hr/>";
//                echo $registered_user_id;echo "<hr/>";
//                die;             
                     
            
                # Variables
		$discounts  = $data['discount'];
		$shipping_details = $data['shipping'];
		$shipping_cost = $data['shipping_cost'];
                
                $shipping_method = $shipping_cost['name'];
                if($this->session->userdata("site_currency") == "aud") {
                    $shipping_cost = $shipping_cost['cost'];
                } else {
                    $shipping_cost = $shipping_cost['cost_usd'];
                }                
                
		$billing_details = $data['billing'];
                
                # Variables for adding extra charges
                $extra_charges_mini = $this->session->userdata('extra_charges');
                $all_ids = array();
                if(!empty($extra_charges_mini))
                {
                    foreach ($extra_charges_mini as $key => $value)
                    {
                        $all_ids[] = substr($key, -1);
                    }
                }
                
                $current_credit_of_user = $this->session->userdata(current_credit);
                if(empty($current_credit_of_user))
                {
                    $credit_to_update = "0.00";
                } else 
                {
                    $credit_to_update = $current_credit_of_user;
                }
                
                if($this->session->userdata("site_currency") == "aud") {
                    $payment_currency = "AUD";
                    $order_amount = number_format($data['cart_total'], 2, '.', '');
                } else {
                    $payment_currency = "USD";
                    $order_amount = number_format($data['cart_total_usd'], 2, '.', '');
                }

                if($payment_mode == "Direct Bank Deposit")
                {
                    $shipping = "Incomplete";
                } else {
                    $shipping = "New";
                }
                
		$order = array(
                    
                        'created_date'      => date('Y-m-d H:i:s'),
                    
			'firstname'         => $shipping_details['s_firstname'],
			'lastname'          => $shipping_details['s_lastname'],
			'email'             => $shipping_details['s_zmail'],
			'phone'             => $shipping_details['s_phone'],
			'address1'          => $shipping_details['s_address_1'],
			'address2'          => $shipping_details['s_address_2'],
			'suburb'            => $shipping_details['s_suburb'],
			'country'           => $shipping_details['s_country'],
			'state'             => $shipping_details['s_state'],
			'postcode'          => $shipping_details['s_postcode'],
			'shipped'           => $shipping,                    
			
			'paid' => $paid,
                    
			'billing_firstname'     => $billing_details['b_firstname'],
			'billing_lastname'      => $billing_details['b_lastname'],
			'billing_email'         => $billing_details['b_zmail'],
			'billing_phone'         => $billing_details['b_phone'],
			'billing_address1'      => $billing_details['b_address_1'],
			'billing_address2'      => $billing_details['b_address_2'],
			'billing_suburb'        => $billing_details['b_suburb'],
			'billing_country'       => $billing_details['b_country'],
			'billing_state'         => $billing_details['b_state'],
			'billing_postcode'      => $billing_details['b_postcode'],
                    
                        'order_amount'      => $order_amount,
                        'shipping_fee'      => number_format($shipping_cost, 2, '.', ''),
                        'shipping_method'   => $shipping_method,
                    
			'reference_no'      => $transaction_id,
                    
                        'wholesaler_amount_used' => $wholesaler_amount,
                        'account_credit_used' => $credit_to_update,
                    
                        'payment_method'    => $payment_mode,
                        'payment_currency'  => $payment_currency, 
                    
                        'ex_charge_1' => in_array("1", $all_ids) ? "1" : "0",
                        'ex_charge_2' => in_array("2", $all_ids) ? "1" : "0",
                        'ex_charge_3' => in_array("3", $all_ids) ? "1" : "0",
                        'ex_charge_4' => in_array("4", $all_ids) ? "1" : "0",
                        'ex_charge_5' => in_array("5", $all_ids) ? "1" : "0"
		);
                $this->db->insert('store_order', $order);
                $inserted_id =  $this->db->insert_id('store_order', $order);
		# discounts saving to table
		if(count($discounts)>0)
		{
			foreach($discounts as $key =>$discount)
			{
				$disc = new stdClass();
				$disc->store_order_id = $inserted_id;
                                
                                if(isset($discount->referrar_user_id))
                                {
                                    $disc->name = "REFERRER";
                                } else {
                                    $disc->name = $key;
                                }
				
				if(isset($discount->code)){ // for coupon code
					$disc->code = $discount->code;
					$disc->unit = $discount->unit;
				}
				$disc->amt = $discount->amt;

				// update the ddiscount coupon
				if($key == 'COUPON' && !isset($discount->referrar_user_id)){
					$this->db->query("UPDATE store_coupon SET times_used = times_used + 1 WHERE name = '{$discount->code}'");
				}
				$this->db->insert('store_order_discounts', $disc);
			}
		}

		# saving prices  to table
		$product_insert = array();
		foreach ($cart as $item) {
                    
                        if($this->session->userdata("site_currency") == "aud") {
                            $item_price = $item['price'];
                        } else {
                            $item_price = $item['price_usd'];
                        }
                    
                        $price_name = $this->getThisProductPriceName($item['price_id']);
                        
			$product_insert[] = array(
				'store_order_id' => $inserted_id,
				'store_product_id' => $item['product_id'],
				'store_price_id' => $item['price_id'],
				'store_price_name' => $price_name->price_name,
				'name' => $item['name'],
				'quantity' => $item['qty'],
				'price' => $item_price,
				'created_date' => date('Y-m-d H:i:s')
			);
		}

		$this->db->insert_batch('store_order_product', $product_insert);
		//$this->db->insert('store_order', $order);
		//$inserted_id =  $this->db->insert_id('store_order', $order);

                if($inserted_id) // saving data into 'users_order_details' table
                {
                        $users_order_details = array(
                            'id'              => $registered_user_id,
                            'order_id'        => $inserted_id,
                            'created_date'    => date('Y-m-d H:i:s'),
                            'updated_date'    => date('Y-m-d H:i:s'),
                            'address1'        => $billing_details['b_address_1'],
                            'address2'        => $billing_details['b_address_2'],
                            'suburb'          => $billing_details['b_suburb'],
                            'country'         => $billing_details['b_country'],
                            'state'           => $billing_details['b_state'],
                            'postcode'        => $billing_details['b_postcode'],
                            'delivery_notes'  => $shipping_details['s_comments']
                        );
                        
                        $this->db->insert('users_order_details', $users_order_details);
                        
                }
                
		return $inserted_id;

	}

                public function getThisProductPriceName($id)
                {
                    $this->db->select('price_name');
                    $this->db->where('store_price_id', $id);
                    $query = $this->db->get('store_price')->row();
                    return $query;
                }

                public function send_order_email($recipient, $subject, $intro, $data) {
		$this->load->library('email');
		$this->email->initialize(array('mailtype' => 'html', 'useragent' => 'my[id]'));
		$this->email->from($this->settings->site->email, $this->settings->site->title);
		$this->email->to($recipient);
		$this->email->subject("{$this->settings->site->title}] $subject");
		$data['settings'] = $this->settings;
		$data['heading'] = $subject;
		$data['intro'] = $intro;
		$this->email->message($this->load->view('email_templates/order', $data, true));
		$this->email->send();
	}


//	public function get_delivery_fee($postcode = false) {
//		/* example method. Just add whatever logic you need */
//		if (!$postcode)
//			return false;
//
//		$postcode = intval($postcode);
//		if ($postcode < 100 OR $postcode > 9999)
//			return false;
//
//		return floor($postcode/400);
//	}
//
//
//
//
	public function get_coupon($code) {
		if (!$code)
			return false;
		return $this->db->query("
			SELECT name AS code,store_coupon_id, value, type AS unit
			FROM store_coupon
			WHERE name = '$code'
			  AND status = 1
			  AND ((`limit` = 'Once' AND times_used = 0) OR `limit` = 'Unlimited')
			  ")->row();
	}
        
        public function get_referral($code) {
		if (!$code)
			return false;
		return $this->db->query("
			SELECT email AS code, id as referrar_user_id
			FROM users
			WHERE email = '$code'
			  AND active = 1			  
			  ")->row();
	}
        
        
        function getRelatedProducts($product_id) {

		$this->db->select('*');
                $this->db->from('map');
                $this->db->join('store_product', 'store_product.store_product_id = map.map_id_b');
                $this->db->where("map.map_table_a", "store_product");
                $this->db->where("map.map_table_b", "store_product");
                $this->db->where("map.map_id_a", $product_id);
                $query = $this->db->get()->result_array();  
                
                $relatedPrices = array();
                $productWithAllPrices = array();
                
                foreach ($query as $key => $value)
                {
                    $relatedPrices[] = $this->getRelatedProductPrices($value['store_product_id']);
                }
                
                $productWithAllPrices = array("product_info"=>$query, "prices"=>$relatedPrices);
                return $productWithAllPrices;
	}      
        
        
        function getRelatedProductPrices($product_id)
        {
            $this->db->select('store_product_id, store_price_id, 
                    MIN(price) as min_price, MAX(price) as max_price, MIN(price_usd) as min_price_usd, MAX(price_usd) as max_price_usd,
                    MIN(sale_price) as min_sale_price, MAX(sale_price) as max_sale_price, MIN(sale_price_usd) as min_sale_price_usd, MAX(sale_price_usd) as max_sale_price_usd'
                    );
            $this->db->where("store_product_id", $product_id);
            $query = $this->db->get('store_price')->result_array();           
            
            return $query[0];            
        } 
        
        function getRelatedCategories($product_id) {

		$this->db->select('store_categories.store_categories_id, store_categories.name, store_categories.slug');
                $this->db->from('map');
                $this->db->join('store_categories', 'store_categories.store_categories_id = map.map_id_b');
                $this->db->where("map.map_table_a", "store_product");
                $this->db->where("map.map_table_b", "store_categories");
                $this->db->where("map.map_id_a", $product_id);
                $query = $this->db->get()->result_array();                
                return $query;
	}
        
        function getRelatedUses($product_id) {

		$this->db->select('store_uses.name, store_uses.slug');
                $this->db->from('map');
                $this->db->join('store_uses', 'store_uses.store_uses_id = map.map_id_b');
                $this->db->where("map.map_table_a", "store_product");
                $this->db->where("map.map_table_b", "store_uses");
                $this->db->where("map.map_id_a", $product_id);
                $query = $this->db->get()->result_array();
                return $query;
	}

		function getHotDealsProducts($sortBy = '')
		{
			$this->db->select("*");
			$this->db->where("status", "1");
			$query = $this->db->get("store_product")->result();

			$finalData = array();
			$count     = 0;
			foreach ($query as $p) {
				$finalData[$count] = $p;
				$this->get_prices($query[$count]);
				$count++;
			}

			if (isset($sortBy) && $sortBy == 'highest') {
				$this->_osort($finalData, 'min_price');
				$result = array_reverse($products);

				return $result;
			} elseif (isset($sortBy) && $sortBy == 'lowest') {
				$this->_osort($finalData, 'min_price');

				return $finalData;
			} else {
				$this->_osort($finalData, 'name');

				return $finalData;
			}

		}
        
        public function giveCurrentCreditAmount($id)
        {
            $this->db->select('current_credit');
            $this->db->where('id', $id);
            $query = $this->db->get('users')->row();            
            return $query->current_credit;                        
        }
        
        public function updateUserCredit($referrar_user_id, $credit_to_update)
        {
            $data = array(
               'current_credit' => $credit_to_update               
            );

            $this->db->where('id', $referrar_user_id);
            $query = $this->db->update('users', $data); 
            return $query;
        }
        
        public function insertReferalHistoryData($data)
        {
            $query = $this->db->insert('referral_history', $data); 
            return $query;
        }
        
        public function getAllExtraCharges()
        {
            $this->db->select('*');
            $this->db->where('status', "1");
            $query = $this->db->get('store_order_extra')->result_array();            
            return $query;
        }
        
        public function getThisExtraCharge($id)
        {
            $this->db->select('*');
            $this->db->where('status', "1");
            $this->db->where('store_order_extra_id', $id);
            $query = $this->db->get('store_order_extra')->result_array();            
            return $query[0];
        }
        
        public function isEmailRegistered($email)
        {
            $this->db->select('COUNT(*) as total');            
            $this->db->where('email', $email);
            $query = $this->db->get('users')->result_array();            
            return $query[0];
        }
        
}
