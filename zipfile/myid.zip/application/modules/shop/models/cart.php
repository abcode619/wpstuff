<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
/*
 *  Cart class
 *  Responsibility :  helper to cart library -
 * 		- accessing cart session
 * 		- adding the session values
 * 		- calculating the cart params like total cost, total shipping cost  ect
 * 		- validates discounts
 * 		- NOTES : for simplicity  and strict check : discounts have been code named (CAPITALS)
 * 				SOD : spent over discount
 * 				COUPON : coupon code
 *  Infractions :    extends MY_MODEL  but doesnt uses any of my_model function only  for core extemsions like l $this->load  you can use MY_CONTROLLER  insted
 *
 *  DOESNT DO : Minimum db operations
 * */

class Cart extends MY_Model {

	/*
	 * shipping discount bool
	 *  TODO : check if using this i dont  think so
	 */
	var $shipping_discount = false;
	var $base_name = 'shop';


	function __construct() {
		parent::__construct();

		# libs
		$this->load->library('session');
		$this->load->library('cart');
		$this->load->libraries(array($this->base_name.'/mycart'));
	    # helper
		$this->load->helper('form');

	}


	/**
	 *  Reads through the cart -  attaches the relevant details - calculates the sub total
	 * @return mixed
	 */
	public function get()
	{
		$cart = $this->mycart->contents();

                
                
		if (empty($cart)){ return false; }  // No products in cart

		foreach ($cart as $id => $entry)
		{
			$item = $this->idstore->get_product($entry['id'], false); // Getting the product details

			foreach ($item as $key => $value){
				$cart[$id][$key] = $value;
			}

			$size = $this->idstore->get_product_size($entry['id'], $entry['price_id']); // get  the  size details
			$cart[$id]['price_usd'] = $size->price_usd;
			$cart[$id]['price_name'] = $size->price_name;
			$cart[$id]['original_price'] = $size->original_price;
			$cart[$id]['sale_price'] = $size->sale_price;
			$cart[$id][ 'size' ] = $size->size;
			$cart[$id][ 'subtotal' ] = number_format($cart[ $id ][ 'subtotal' ],2,'.','');// having 2 decimaal plac and  replace , with ''
			$cart[$id][ 'subtotal_usd' ] = number_format(($cart[$id]['price_usd']*$cart[$id]['qty']),2,'.','');// having 2 decimaal plac and  replace , with ''

		}
                
		return $cart;
	}

	/**
	 * checks if its has a valid spent over discount and  it  to discounts
	 *  DB operation to fetch valid discounts
	 */
	public function check_spent_over_discount()
	{
		// Fetch valid discount  records
		$discounts = $this->idstore->get_spent_over_discounts ();
		// checking if  any discounts that have been applied
		$existing_discounts = $this->get_cart_discount ();

		if (count ($existing_discounts) == 0)
		{ // IF no discounts applied
			$existing_discounts = array (); // make a new  discounts array
		}

		// for each discount obj
		foreach ($discounts as $discount)
		{
			// verify each discount and add to cart discount    ONLY GREATER THAN
			if ($this->mycart->total () > $discount->limit)
			{
				// Yes : now create spend over discount object
				$SOD               = new stdClass();
				$SOD->display_mess = $discount->display_mess;
				$SOD->amt          = $discount->amt;
				$existing_discounts['SOD']= $SOD;
				$this->mycart->apply_discount ($existing_discounts); // add to cart discount only one discount if error it fails here
				//all went through  hence return true
				return true;

			} else
			{ // remove the discount if it dint meet the condtion // also helps if has be applied first and products have been removed
				$array = $this->get_cart_discount ();
				// removes only SPENT OVER DISCOUNT
				if ($array && array_key_exists ('SOD', $array)   )
				{
					unset($array[ 'SOD' ]); // remove the SOD object
					$this->mycart->apply_discount ($array); // update cart discount value
				}
			}
		}

	}

	/**
	 * Applying coupon discount
	 * @param $coupon
	 * @return bool
	 */
	public function apply_coupon ($coupon)
	{
		// Get the existing discounts if any
		$existing_discounts = $this->get_cart_discount ();

		if(count ($existing_discounts) == 0 ){ // IF no discounts applied
			$existing_discounts = array (); // make a new array
		}
		//only one coupon can be applied hence checking
		if(array_key_exists('COUPON',$existing_discounts) == false)
		{
			// new std coupon
			$COUPON               = new stdClass();
			$COUPON->coupon_id    = $coupon->store_coupon_id;
			$COUPON->code         = $coupon->code;
			$COUPON->unit         = $coupon->unit;
			$COUPON->value        = $coupon->value;

			$existing_discounts['COUPON'] =  $COUPON ;
			return $this->mycart->apply_discount ($existing_discounts); // add to cart discount only one discount

		}else{
			return false;  // COUPON already applied
		}

	}

        
        public function apply_referral ($coupon)
	{   
		// Get the existing discounts if any
		$existing_discounts = $this->get_cart_discount ();

		if(count ($existing_discounts) == 0 ){ // IF no discounts applied
			$existing_discounts = array (); // make a new array
		}
		//only one coupon can be applied hence checking
		if(array_key_exists('COUPON',$existing_discounts) == false)
		{
			// new std coupon
			$COUPON               = new stdClass();
			$COUPON->referrar_user_id    = $coupon->referrar_user_id;
			$COUPON->code         = $coupon->code;
			$COUPON->unit         = $coupon->unit;
			$COUPON->value        = $coupon->value;

			$existing_discounts['COUPON'] =  $COUPON ;
			return $this->mycart->apply_discount ($existing_discounts); // add to cart discount only one discount

                        }else{
			return false;  // COUPON already applied
		}

	}
        
        
	/**
	 * will check and add if applicable and return if applicable
	 * @return bool
	 */        
	public function get_spent_over_discount ()
	{
		$this->check_spent_over_discount(); // check  and add if applicable
		$newdiscount = $this->get_cart_discount ();

		if(!is_null($newdiscount) && array_key_exists('SOD',$newdiscount)){
			return $newdiscount['SOD']; // return this
		}else{
			return false; // no discount applied
		}
	}

	/**
	 * check if copon is applied
	 * @return bool
	 */
	public function is_coupon_applied()
	{
		$discounts = $this->get_cart_discount ();
                
		if(is_array($discounts))
		{
			if(array_key_exists ('COUPON', $discounts) )
			{
				return $discounts['COUPON'];
			}else{
				return false;// not found
			}
		}
	}

	/**
	 * just cart total with out discount being applied
	 * @return mixed
	 */
	public function get_cart_total ()
	{
		$cart =$this->mycart->completecontents();
                return $cart['cart_total']; 		
	}
        
	public function get_bulk_total ()
	{
		$cart =$this->mycart->completecontents();
                return $cart['bulk_total']; 		
	}
        
        public function get_cart_usd_total ()
	{
		$cart =$this->mycart->completecontents();
                return $cart['cart_total_usd']; 		
	}
        
        public function get_bulk_usd_total ()
	{
		$cart =$this->mycart->completecontents();
                return $cart['bulk_total_usd']; 		
	}

	/**
	 * complete discount object
	 * @return mixed
	 */
	public function get_cart_discount ()
	{
                $cart = $this->mycart->completecontents ();
                
                // unlinking all other discounts if user is a wholesaler one
                if($this->session->userdata('is_wholesaler') == "1" || $this->session->userdata('email') == $cart['discount']['COUPON']->code)                   
                {
                    if(isset($cart['discount']))
                    {
                        unset($cart['discount']);
                        return false;
                    }
                } else {          
                    return $cart[ 'discount' ];
                }
	}

	/**
	 * Get total after subtracting discounts including shipping if available
	 * @return float
	 */
	public function get_cart_total_after_discount ()
	{
                // Giving final amount as AUD or USD based on user input.
                if($this->session->userdata("site_currency") == "aud") {
                    $total = ($this->get_cart_total() + $this->get_bulk_total());
                } else 
                {
                    $total = ($this->get_cart_usd_total() + $this->get_bulk_usd_total());                    
                }
            
                $total = number_format($total, 2, '.', '');
                
                
		
		$discount = number_format($this->get_cart_total_discount(), 2, '.', '');

                $extra_charges = $this->get_cart_total_extra_charges();
                
                $grand_total_with_extra = $total + $extra_charges;
                
                
                
                
		$grand_total = $grand_total_with_extra - number_format($discount, 2, '.', '');               
                
                
                
		// apply shipping
		if($this->get_total_shipping_cost())
		{
			$grand_total = $grand_total + (float) $this->get_total_shipping_cost();
		}
                
		return $grand_total;
	}

	/**
	 * as coupon has % and $ in them which is dependent on the pre discount hence can be calculated separately
	 * @param null $return_calculated_amt
	 *
	 */
	public function calculate_coupon_amt ($return_calculated_amt=NULL)
	{
		if ($this->session->userdata("site_currency") == "aud") {
                    $total = $this->get_cart_total();// get total with out discounts
                } else {
                    $total = $this->get_cart_usd_total();// get total with out discounts
                }
                
                
		$existing_discounts = $this->get_cart_discount (); // get discout obj

		if(count($existing_discounts)>0 )
		{
			// If Spend over discount is avaliable them get total - discount
			if(array_key_exists('SOD',$existing_discounts) &&$this->config->item('spent_over_discount'))
			{
				$SOD = $this->get_spent_over_discount();
				$total = $total - $SOD->amt;
			}
			// If coupon is applied
			if (array_key_exists ('COUPON', $existing_discounts))
			{
				$coupon = $existing_discounts['COUPON'];

				if ($coupon->unit == '%')
				{
					$coupon_discount =(float) ($total / 100 * $coupon->value);
				} else if ($coupon->unit == '$')
				{
					$coupon_discount = $coupon->value;
				}

				if(!empty($return_calculated_amt)){
					 return $coupon_discount;
				}
				$existing_discounts[ 'COUPON' ]->amt = $coupon_discount;
				// add this to cat discounts now !!!
				$this->mycart->apply_discount ($existing_discounts); // add to cart discount only one discount
			}
		}
	}

	/**
	 * Getting total discounts
	 * @return float
	 */
	public function get_cart_total_discount()
	{
		$cart           = $this->mycart->completecontents();
                
		$total_discount = 0.00;
                
                // unlinking all other discounts if user is a wholesaler one
                if($this->session->userdata('is_wholesaler') == "1" || $this->session->userdata('email') == $cart['discount']['COUPON']->code)                   
                {
                    if(isset($cart['discount']))
                    {
                        unset($cart['discount']);
                    }
                }                
                
		// if discounts is available
		if(isset($cart['discount']) && $cart['discount'] > 0)
		{
			// if coupon is applied -- calculate now !!! due to % of total
			if(isset($cart['discount']['COUPON']))
			{
				$this->calculate_coupon_amt();
			}

			foreach($cart['discount'] as $discount)
			{
				$total_discount += (float) $discount->amt;
			}
		}

		return $total_discount;
	}
        
	/**
	 * Getting total discounts
	 * @return float
	 */
	public function get_cart_total_extra_charges()
	{
            
                $cart_total = $this->session->userdata['cart_contents']['cart_total'];
                $cart_total_usd = $this->session->userdata['cart_contents']['cart_total_usd'];
            
		$all_extra_charges = $this->session->userdata('extra_charges');
                
                $return_aud = 0;
                $return_usd = 0;
                
                if(!empty($all_extra_charges)) {
                
	                foreach ($all_extra_charges as $key => $value)
	                {                    
	                    $multiply_by = (floor($cart_total/$value['min_amount']) + 1);                        
	                    $return_aud += number_format(($value['val_aud'] * $multiply_by), 2, '.', '');
	                    
	                    $multiply_by_usd = (floor($cart_total_usd/$value['min_amount']) + 1);                        
	                    $return_usd += number_format(($value['val_usd'] * $multiply_by_usd), 2, '.', '');
	                }  
	        }                   
                
                if ($this->session->userdata("site_currency") == "aud") {
                    return number_format($return_aud, 2, '.', ''); // get total with out discounts
                } else {
                    return number_format($return_usd, 2, '.', ''); // get total with out discounts
                }                
                
                
                
	}

	/**
	 *  total return shipping cost
	 * @return bool
	 */
	public function get_total_shipping_cost()
	{
		$cart = $this->mycart->completecontents();
		if(isset($cart['shipping_cost']))
		{
                    if($this->session->userdata("site_currency") == "aud") {
                        return $cart['shipping_cost']['cost'];
                    } else {
                        return $cart['shipping_cost']['cost_usd'];
                    }  
			
		} else
		{
			return false;
		}
	}

	/**
	 *  return shipping cost array
	 * @return bool
	 */
	public function get_shipping_cost()
	{
		$cart = $this->mycart->completecontents();
                
		if(isset($cart['shipping_cost'])){
			return $cart['shipping_cost'];
		}else{
			return false;
		}
	}

	/**
	 * Get the details by name { shipping or billing }
	 * @param $name
	 * @return bool
	 */
	public function get_details($name)
	{
		$cart = $this->mycart->completecontents();

		return isset($cart[$name]) ? $cart[$name] : false;
	}

	/**
	 * Only  to get billing details email address
	 * @return bool
	 */
	public function get_billing_email()
	{
		$details = $this->get_details('billing');

		return $details? $details['b_zmail'] :false;
	}

	/**
	 * updated cart qty
	 * @param $id
	 * @param $qty
	 * @return mixed
	 */
	public function update_qty ($id,$qty)
	{
		return $this->mycart->update_cart(array('id'=>$id,'qty'=>$qty));
	}

	/**
	 *  Empty cart contents or remove a particular cart item
	 * @param null $product_id
	 */
	public function remove ($product_id =NULL)
	{

		if(!empty($product_id)){
			return $this->mycart->remove($product_id);
		}else{
			$this->mycart->remove ();; // removes all cart items
		}
	}

	/**
	 * @param $total
	 * @return bool
	 */
	public function calculate_shipping_discounts($total)
	{
		if($this->config->item('shipping_activate_spent_over') === true){
			$value = $this->idstore->get_shipping_spend_over_options($total);
			if($value != false ){
				$this->shipping_discount = true;
				$shipping_fees =  $value->delivery_fee;
			}else{
				$shipping_fees = false;
			}
		}

		return $shipping_fees;

	}

	/**
	 * add products to the cart session s
	 * @param $product_id
	 * @param $price_id
	 * @param $qty
	 * @return mixed
	 */
	function add($product_id, $price_id, $qty)
	{   
            
		$id = $this->mycart->make_suk($product_id, $price_id);
                
		// Check if prodoct exists in the cart
		$result = $this->mycart->in_cart($id);

                if(!empty($result))
		{
			// config option - add on adding pproduct to cart again
			if($this->config->item('add_product_again') === true)
			{
				$this->_update_item(array('rowid' => $result['rowid'],
				                          'qty'   => $result['qty'] + 1                                                          
                                        )); // add one to qty
			} else
			{

				return $result['rowid']; // returns the products cart row i
			}

		} else
		{
			// Product doesnt exist hence add it
			$item  = $this->idstore->get_product($product_id, false);
                        
			$price = $this->idstore->get_product_size($product_id, $price_id);
                        
			$entry = array(
				'id'                => $id,
				'qty'               => (int) $qty,
				'product_id'        => (int) $product_id,
				'price_id'          => (int) $price->store_price_id,
				'price'             => (float) $price->price,
				'price_usd'         => (float) $price->price_usd,				
				'sale_price'        => (float) $price->sale_price,
				'sale_price_usd'    => (float) $price->sale_price_usd,				
				'sale_end'          => $price->sale_end,				
				'bulk_price'        => (float) $price->bulk_price,
				'bulk_price_usd'    => (float) $price->bulk_price_usd,				
				'name'              => $item->name,
				'to_be_shipped'     => (int) $price->to_be_shipped,
				'product_pdf1'      => $price->product_pdf1,
				'product_pdf2'      => $price->product_pdf2,
				'options'           => array()
				// optional  not necessary in this case
			);

			return $this->mycart->insert($entry); // return  true or false
		}
	}

        

	/**
	 * Saving  billing details to session variable // user login also can be used
	 * @param null $data
	 * @return bool
	 */
	public function save_cart_billing_details($data = NULL)
	{   
		if(!empty($data))
		{
                    
				// Not in cart session hence save it
				return $this->mycart->save_to_cart('billing', $data);
		}
	}

	/**
	 *  saving shipping details to seesion
	 * @param null $data
	 */
        
        public function save_cart_billing_details_default()
        {
//            $this->db->select("MAX(store_order_id) as store_id");
            $this->db->select("*");
            $this->db->where("  store_order_id "
                    . " IN  ( SELECT MAX(store_order_id) FROM (`store_order`) "
                    . " WHERE `billing_email` = '".$this->session->userdata("email")."')", NULL, FALSE);
            $query = $this->db->get("store_order")->result_array();
            
            $data = array(
                    "b_firstname" => trim($query[0]['billing_firstname']),
                    "b_lastname" => trim($query[0]['billing_lastname']),
                    "b_address_1" => trim($query[0]['billing_address1']),
                    "b_address_2" => trim($query[0]['billing_address2']),
                    "b_country" => trim($query[0]['billing_country']),
                    "b_state" => trim($query[0]['billing_state']),
                    "b_suburb" => trim($query[0]['billing_suburb']),
                    "b_postcode" => trim($query[0]['billing_postcode']),
                    "b_zmail" => trim($query[0]['billing_email']),
                    "email" => "",
                    "b_phone" => trim($query[0]['billing_phone']) 
            );
            
            $response = $this->mycart->save_to_cart('billing', $data);
            if($response)
            {
                return $data;
            }
            
        }


        public function save_cart_shipping_details($data = null)
	{
		if(!empty($data))
		{
			return $this->mycart->save_to_cart('shipping', $data);
		}
	}
        
        public function save_cart_shipping_details_default()
        {
//            $this->db->select("MAX(store_order_id) as store_id");
            $this->db->select("*");
            $this->db->where("  store_order_id "
                    . " IN  ( SELECT MAX(store_order_id) FROM (`store_order`) "
                    . " WHERE `billing_email` = '".$this->session->userdata("email")."')", NULL, FALSE);
            $query = $this->db->get("store_order")->result_array();
            
            $data = array(
                    "s_firstname" => trim($query[0]['firstname']),
                    "s_lastname" => trim($query[0]['lastname']),
                    "s_address_1" => trim($query[0]['address1']),
                    "s_address_2" => trim($query[0]['address2']),
                    "s_country" => trim($query[0]['country']),
                    "s_state" => trim($query[0]['state']),
                    "s_suburb" => trim($query[0]['suburb']),
                    "s_postcode" => trim($query[0]['postcode']),
                    "s_zmail" => trim($query[0]['email']),                    
                    "s_phone" => trim($query[0]['phone']) 
            );
            
            $response = $this->mycart->save_to_cart('shipping', $data);
            if($response)
            {
                return $data;
            }            
            
        }

	/**
	 * Add the shipping cost to cart session
	 * @param $shipping
	 * @return mixed
	 */
	public function apply_shipping_cost($shipping)
	{
		if(!empty($shipping))
		{
			return $this->mycart->save_to_cart('shipping_cost', $shipping);
		}
	}


	/**
	 *  Checks if cart has valid items
	 */
	public function cart_check()
	{
		return $this->mycart->is_cart_valid();
	}

	/**
	 * counts items in cart
	 * @return mixed
	 */
	public function cart_count()
	{
		return $this->mycart->all_item_count();
	}







}
