# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.33)
# Database: orgone
# Generation Time: 2014-09-30 01:02:12 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table map
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map`;

CREATE TABLE `map` (
  `map_table_a` varchar(25) DEFAULT NULL,
  `map_id_a` int(10) DEFAULT NULL,
  `map_table_b` varchar(25) DEFAULT NULL,
  `map_id_b` int(10) DEFAULT NULL,
  KEY `map_table_a_map_id_a` (`map_table_a`,`map_id_a`),
  KEY `map_table_b_map_id_b` (`map_table_b`,`map_id_b`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `map` WRITE;
/*!40000 ALTER TABLE `map` DISABLE KEYS */;

INSERT INTO `map` (`map_table_a`, `map_id_a`, `map_table_b`, `map_id_b`)
VALUES
	('team_members',1,'group_classes',2),
	('team_members',3,'group_classes',5),
	('team_members',3,'group_classes',1),
	('store_product',1,'store_categories',3),
	('store_product',1,'store_categories',1),
	('store_product',2,'store_categories',2),
	('store_product',2,'store_categories',1),
	('store_product',3,'store_categories',2),
	('store_product',3,'store_categories',1),
	('store_product',4,'store_categories',2),
	('store_product',4,'store_categories',1);

/*!40000 ALTER TABLE `map` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_brand
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_brand`;

CREATE TABLE `store_brand` (
  `store_brand_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_brand` WRITE;
/*!40000 ALTER TABLE `store_brand` DISABLE KEYS */;

INSERT INTO `store_brand` (`store_brand_id`, `created_date`, `updated_date`, `order_index`, `name`, `slug`, `description`, `image`, `status`, `seo_title`, `seo_description`)
VALUES
	(1,'2014-08-19 14:30:10','2014-09-25 15:53:02',1,'BONDS','bonds','<p>fgasdfa</p>','','1','Bonds title ','Bond desc'),
	(2,'2014-08-20 09:18:59','2014-09-25 15:53:22',2,'ID agency ','id-agency-','','','1','ID title ','id desc');

/*!40000 ALTER TABLE `store_brand` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_categories
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_categories`;

CREATE TABLE `store_categories` (
  `store_categories_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_categories_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_categories` WRITE;
/*!40000 ALTER TABLE `store_categories` DISABLE KEYS */;

INSERT INTO `store_categories` (`store_categories_id`, `created_date`, `updated_date`, `order_index`, `name`, `seo_title`, `seo_description`, `status`, `slug`)
VALUES
	(1,'2014-05-05 15:01:07','2014-08-19 15:05:58',2,'category1','dfasf','dfa','1','category1'),
	(2,'2014-08-19 15:04:02','2014-08-19 15:06:03',3,'category 2 ','dafsd','dfadsf','1','category-2-'),
	(3,'2014-08-19 15:04:23','2014-08-19 15:06:13',1,'category 3','dfasdfa','dfasdfa','1','category-3');

/*!40000 ALTER TABLE `store_categories` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_coupon
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_coupon`;

CREATE TABLE `store_coupon` (
  `store_coupon_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `limit` enum('Once','Unlimited') DEFAULT NULL,
  `type` enum('%','$') DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `times_used` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`store_coupon_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_coupon` WRITE;
/*!40000 ALTER TABLE `store_coupon` DISABLE KEYS */;

INSERT INTO `store_coupon` (`store_coupon_id`, `created_date`, `updated_date`, `order_index`, `name`, `limit`, `type`, `value`, `times_used`, `status`)
VALUES
	(1,'2014-08-28 13:12:43','2014-09-22 14:31:54',0,'testing','Unlimited','$','10','18','1');

/*!40000 ALTER TABLE `store_coupon` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_order
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_order`;

CREATE TABLE `store_order` (
  `store_order_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(225) DEFAULT NULL,
  `lastname` varchar(225) DEFAULT NULL,
  `email` varchar(225) DEFAULT NULL,
  `phone` int(10) DEFAULT NULL,
  `address1` varchar(225) DEFAULT NULL,
  `address2` varchar(225) DEFAULT NULL,
  `suburb` varchar(225) DEFAULT NULL,
  `state` varchar(225) DEFAULT NULL,
  `postcode` int(10) DEFAULT NULL,
  `shipped` varchar(225) DEFAULT NULL,
  `paid` double DEFAULT NULL,
  `billing_firstname` varchar(225) DEFAULT NULL,
  `billing_lastname` varchar(225) DEFAULT NULL,
  `billing_email` varchar(225) DEFAULT NULL,
  `billing_phone` varchar(225) DEFAULT NULL,
  `billing_address1` varchar(225) DEFAULT NULL,
  `billing_address2` varchar(225) DEFAULT NULL,
  `billing_suburb` varchar(225) DEFAULT '',
  `billing_state` varchar(225) DEFAULT NULL,
  `billing_postcode` varchar(225) DEFAULT NULL,
  `order_amount` int(100) DEFAULT NULL,
  `shipping_fee` int(100) DEFAULT NULL,
  `order_phone` varchar(255) DEFAULT NULL,
  `tracking_code` varchar(255) DEFAULT NULL,
  `tracking_url` varchar(255) DEFAULT NULL,
  `reference_no` varchar(255) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `coupon_value` varchar(255) DEFAULT NULL,
  `comments` text,
  PRIMARY KEY (`store_order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_order` WRITE;
/*!40000 ALTER TABLE `store_order` DISABLE KEYS */;

INSERT INTO `store_order` (`store_order_id`, `created_date`, `updated_date`, `order_index`, `firstname`, `lastname`, `email`, `phone`, `address1`, `address2`, `suburb`, `state`, `postcode`, `shipped`, `paid`, `billing_firstname`, `billing_lastname`, `billing_email`, `billing_phone`, `billing_address1`, `billing_address2`, `billing_suburb`, `billing_state`, `billing_postcode`, `order_amount`, `shipping_fee`, `order_phone`, `tracking_code`, `tracking_url`, `reference_no`, `coupon_code`, `coupon_value`, `comments`)
VALUES
	(1,'2014-09-23 10:03:39',NULL,0,'kora','jayaram','kora.jayaram@gmail.com',2147483647,'brunswick ','dkfjakdfaks','djhfajs','Anguilla',3122,'No',1490,'kora','jayaram  ','kora.jayaram@gmail.com','1212121212121','brunswick ','dkfjakdfaks','djhfajs','Anguilla','3122',1500,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(2,'2014-09-23 10:08:07',NULL,0,'kora','jayaram','kora.jayaram@gmail.com',2147483647,'brunswick ','dkfjakdfaks','djhfajs','Anguilla',3122,'No',1490,'kora','jayaram  ','kora.jayaram@gmail.com','1212121212121','brunswick ','dkfjakdfaks','djhfajs','Anguilla','3122',1500,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(3,'2014-09-23 10:12:17',NULL,0,'kora','jayaram','kora.jayaram@gmail.com',2147483647,'brunswick ','dkfjakdfaks','djhfajs','Anguilla',3122,'No',1490,'kora','jayaram  ','kora.jayaram@gmail.com','1212121212121','brunswick ','dkfjakdfaks','djhfajs','Anguilla','3122',1500,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(4,'2014-09-23 10:21:06',NULL,0,'kora','jay ','kora.jayaram@gmail.com',2147483647,'dsfjas','dsfasd','brunswick','Anguilla',3122,'No',620,'kora','jay ','kora.jayaram@gmail.com','1212121212121','dsfjas','dsfasd','brunswick','Anguilla','3122',640,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
	(5,'2014-09-23 14:27:33',NULL,0,'kora','dfadf                ','kora.jayaram@gmail.com',2147483647,'fasdf','dfas','badsfas','Northern Territory',2133,'No',1801,'kora','dfadf                ','kora.jayaram@gmail.com','1212121212121','fasdf','dfas','badsfas','Northern Territory','2133',1800,11,NULL,NULL,NULL,'10957068',NULL,NULL,NULL),
	(6,'2014-09-29 14:42:03',NULL,0,'tgwer',' dfa','kora.jayaram@gmail.com',12233,'fasd','fsfd','dfdfa','Victoria',3056,'No',10220,'tgwer',' dfa','kora.jayaram@gmail.com','12233','fasd','fsfd','dfdfa','Victoria','3056',10240,0,NULL,NULL,NULL,'10967141',NULL,NULL,NULL);

/*!40000 ALTER TABLE `store_order` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_order_discounts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_order_discounts`;

CREATE TABLE `store_order_discounts` (
  `store_order_discounts_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `store_order_id` int(11) DEFAULT NULL,
  `name` varchar(225) DEFAULT NULL,
  `code` varchar(225) DEFAULT NULL,
  `unit` varchar(225) DEFAULT NULL,
  `amt` varchar(225) DEFAULT NULL,
  PRIMARY KEY (`store_order_discounts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `store_order_discounts` WRITE;
/*!40000 ALTER TABLE `store_order_discounts` DISABLE KEYS */;

INSERT INTO `store_order_discounts` (`store_order_discounts_id`, `store_order_id`, `name`, `code`, `unit`, `amt`)
VALUES
	(27,1,'SOD',NULL,NULL,'10.00'),
	(28,1,'COUPON','testing','$','10'),
	(29,1,'SOD',NULL,NULL,'10.00'),
	(30,1,'COUPON','testing','$','10'),
	(31,2,'SOD',NULL,NULL,'10.00'),
	(32,2,'COUPON','testing','$','10'),
	(33,3,'SOD',NULL,NULL,'10.00'),
	(34,3,'COUPON','testing','$','10'),
	(35,4,'SOD',NULL,NULL,'10.00'),
	(36,4,'COUPON','testing','$','10'),
	(37,5,'SOD',NULL,NULL,'10.00'),
	(38,6,'SOD',NULL,NULL,'10.00'),
	(39,6,'COUPON','testing','$','10');

/*!40000 ALTER TABLE `store_order_discounts` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_order_product
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_order_product`;

CREATE TABLE `store_order_product` (
  `store_order_product_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `store_product_id` int(10) DEFAULT NULL,
  `store_price_id` int(10) DEFAULT NULL,
  `store_order_id` int(10) DEFAULT NULL,
  `name` varchar(225) DEFAULT NULL,
  `size` varchar(225) DEFAULT NULL,
  `quantity` varchar(225) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`store_order_product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `store_order_product` WRITE;
/*!40000 ALTER TABLE `store_order_product` DISABLE KEYS */;

INSERT INTO `store_order_product` (`store_order_product_id`, `store_product_id`, `store_price_id`, `store_order_id`, `name`, `size`, `quantity`, `price`, `created_date`)
VALUES
	(9,1,4,1,'fadfasd sdfasd',NULL,'5',300,'2014-09-23 09:58:30'),
	(10,1,4,1,'fadfasd sdfasd',NULL,'5',300,'2014-09-23 10:03:39'),
	(11,1,4,2,'fadfasd sdfasd',NULL,'5',300,'2014-09-23 10:08:07'),
	(12,1,4,3,'fadfasd sdfasd',NULL,'5',300,'2014-09-23 10:12:17'),
	(13,1,5,4,'fadfasd sdfasd',NULL,'2',320,'2014-09-23 10:21:06'),
	(14,1,4,5,'fadfasd sdfasd',NULL,'6',300,'2014-09-23 14:27:33'),
	(15,1,5,6,'fadfasd sdfasd',NULL,'32',320,'2014-09-29 14:42:03');

/*!40000 ALTER TABLE `store_order_product` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_price
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_price`;

CREATE TABLE `store_price` (
  `store_price_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `store_product_id` int(11) NOT NULL,
  `size` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `original_price` varchar(255) DEFAULT NULL,
  `price_name` varchar(255) DEFAULT NULL,
  `sale_price` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_price_id`),
  KEY `store_product_id` (`store_product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_price` WRITE;
/*!40000 ALTER TABLE `store_price` DISABLE KEYS */;

INSERT INTO `store_price` (`store_price_id`, `created_date`, `updated_date`, `order_index`, `store_product_id`, `size`, `price`, `original_price`, `price_name`, `sale_price`)
VALUES
	(2,'2012-07-23 17:01:52','2014-08-19 14:18:43',0,2,'12','12','121','dsasdf','12'),
	(3,'2014-08-19 14:19:33','2014-08-26 11:49:55',0,2,'','12.00','15.00','new Price ','12.00'),
	(4,'2014-08-20 11:43:45','2014-08-20 12:21:17',0,1,'','300.00','300.00','small',''),
	(5,'2014-08-20 11:44:08','2014-08-20 12:21:29',0,1,'','320.00','325.00','Medium','320.00'),
	(6,'2014-08-20 11:44:24','2014-08-20 12:19:10',0,1,'','330.00','330.00','Large','350.00'),
	(7,'2014-09-26 14:12:22','2014-09-26 14:12:22',0,4,'','10.00','20.00','jajsd','10.00');

/*!40000 ALTER TABLE `store_price` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_product
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_product`;

CREATE TABLE `store_product` (
  `store_product_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `image_1` varchar(255) DEFAULT NULL,
  `image_2` varchar(255) DEFAULT NULL,
  `image_3` varchar(255) DEFAULT NULL,
  `image_4` varchar(255) DEFAULT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text,
  `store_brand_id` int(11) NOT NULL,
  `specifications_tab` text,
  `featured` tinyint(1) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `extract` varchar(255) DEFAULT NULL,
  `primary_description` text,
  `features_tab` text,
  `full_details_tab` text,
  `image_alt_text` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_product_id`),
  KEY `store_brand_id` (`store_brand_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_product` WRITE;
/*!40000 ALTER TABLE `store_product` DISABLE KEYS */;

INSERT INTO `store_product` (`store_product_id`, `created_date`, `updated_date`, `order_index`, `name`, `slug`, `image`, `image_1`, `image_2`, `image_3`, `image_4`, `seo_title`, `seo_description`, `store_brand_id`, `specifications_tab`, `featured`, `status`, `extract`, `primary_description`, `features_tab`, `full_details_tab`, `image_alt_text`)
VALUES
	(1,'2014-08-19 15:42:38','2014-09-26 14:37:27',1,'fadfasd sdfasd','fadfasd-sdfasd','/resources/download(6).jpeg','/resources/product_specific.jpeg','','','','fasf','fgsfgs',1,'<pre><span>Specificationsfgadsgadgasdgadsgadgasdg</span></pre>',1,'1','Vestibulum ante ipsum primis in faucibus orci luctus ','<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibu &nbsp; s.</p>','<p>VeSDsdsdasdfasdfasdvasdv sdvasdfadf sdfasdstibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>','<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>','dfadfasdfas'),
	(4,'2014-09-25 09:25:40','2014-09-26 14:38:07',4,'product 4','product-4','','','','','','fasdf','dfasdf',2,'<p>fasdfdsdgsfdsdfdf</p>',1,'1','dsfaksdfkalsdnfvasd','<p>fasdfa</p>','','','dfasf'),
	(2,'2014-08-19 15:49:10','2014-08-20 11:08:41',2,'new product 2','new-product-2','','','','','','dfasdfadsf','dfafafasdfa',0,'<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>',0,'1','Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla porttitor accumsan tincidunt. Nulla quis lorem ut libero malesuada feugiat. Proin eget tortor risus. Curabitur arcu erat, ac','<p>Sed porttitor lectus nibh. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur aliquet quam id dui posuere blandit. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Curabitur aliquet quam id dui posuere blandit. Vivamus magna justo, lacinia eget consectetur sed, convallis at tellus. Pellentesque in ipsum id orci porta dapibus. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Donec rutrum congue leo eget malesuada. Donec rutrum congue leo eget malesuada.</p>\n<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>\n<p>&nbsp;</p>','<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>','<p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Sed porttitor lectus nibh. Sed porttitor lectus nibh. Nulla porttitor accumsan tincidunt. Vivamus suscipit tortor eget felis porttitor volutpat. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec sollicitudin molestie malesuada. Praesent sapien massa, convallis a pellentesque nec, egestas non nisi. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Pellentesque in ipsum id orci porta dapibus.</p>',NULL),
	(3,'2014-08-20 09:24:02','2014-08-20 11:06:52',3,'New product 3','new-product-3','','','','','','Manager','Olblrb lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',1,'<p>Proin eget tortor risus. Cras ultricies ligula sed magna dictum porta. Donec sollicitudin molestie malesuada. Vivamus suscipit tortor eget felis porttitor volutpat. Cras ultricies ligula sed magna dictum porta. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula. Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Donec rutrum congue leo eget malesuada. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor sit amet aliquam vel, ullamcorper sit amet ligula.</p>',1,'1','Curabitur non nulla sit amet nisl tempus convallis quis ac lectus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur aliquet quam id dui posuere blandit. Proin eget tortor risus. Lorem ipsum dolor sit amet, consectetur adipiscing eli','<h2 class=\"box-primary__title\">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed.</h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue justo sit amet neque accumsan aliquet. Aliquam viverra leo quis massa elementum gravida. Maecenas turpis orci, viverra tempor dapibus a, pulvinar ac tellus. Aenean ultricies.</p>\n<ul>\n<li>Lorem ipsum dolor sit amet, consectetur.</li>\n<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>\n<li>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue justo sit.</li>\n</ul>','<h2>Lorem.</h2>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue justo sit amet neque accumsan aliquet. Aliquam viverra leo quis massa elementum gravida. Maecenas turpis orci, viverra tempor dapibus a, pulvinar ac tellus. Aenean ultricies, est nec mollis hendrerit, nisl neque porta nulla, vitae malesuada magna.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed congue justo sit amet neque accumsan aliquet. Aliquam viverra leo quis massa elementum gravida. Maecenas turpis orci, viverra.</p>','<p>Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula sed magna dictum porta. Nulla porttitor accumsan tincidunt. Proin eget tortor risus. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Quisque velit nisi, pretium ut lacinia in, elementum id enim. Curabitur aliquet quam id dui posuere blandit. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus suscipit tortor eget felis porttitor volutpat. Nulla quis lorem ut libero malesuada feugiat.</p>',NULL);

/*!40000 ALTER TABLE `store_product` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_shippings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_shippings`;

CREATE TABLE `store_shippings` (
  `store_shippings_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `display_mess` varchar(255) DEFAULT NULL,
  `cost` varchar(255) DEFAULT NULL,
  `destination` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`store_shippings_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_shippings` WRITE;
/*!40000 ALTER TABLE `store_shippings` DISABLE KEYS */;

INSERT INTO `store_shippings` (`store_shippings_id`, `created_date`, `updated_date`, `order_index`, `name`, `display_mess`, `cost`, `destination`, `status`)
VALUES
	(1,'2014-09-03 12:12:52','2014-09-03 15:20:32',1,'Aus shipping ','Australia wide shipping $11.00','11.00','Australia','1'),
	(2,'2014-09-03 12:14:19','2014-09-03 12:14:19',0,'Others','Default Shipping 10.00','10.00','Other','1');

/*!40000 ALTER TABLE `store_shippings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table store_spent_over_discount
# ------------------------------------------------------------

DROP TABLE IF EXISTS `store_spent_over_discount`;

CREATE TABLE `store_spent_over_discount` (
  `store_spent_over_discount_id` int(10) NOT NULL AUTO_INCREMENT,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `display_mess` varchar(255) DEFAULT NULL,
  `expiry` date DEFAULT NULL,
  `amt` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  `expiry_check` tinyint(1) DEFAULT NULL,
  `limit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`store_spent_over_discount_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `store_spent_over_discount` WRITE;
/*!40000 ALTER TABLE `store_spent_over_discount` DISABLE KEYS */;

INSERT INTO `store_spent_over_discount` (`store_spent_over_discount_id`, `created_date`, `updated_date`, `order_index`, `name`, `display_mess`, `expiry`, `amt`, `status`, `expiry_check`, `limit`)
VALUES
	(2,'2014-08-27 14:47:09','2014-09-01 10:55:07',1,'testing2','Testing 10','2015-08-29','10.00','1',1,'400.00');

/*!40000 ALTER TABLE `store_spent_over_discount` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
