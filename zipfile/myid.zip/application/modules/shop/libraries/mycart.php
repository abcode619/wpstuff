<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
	/*
	 * MYCART
	  *  Cart class
	 *  Responsibility :  helper to cart library - by adding a bit more functionality
	 * 		-  has functions to  access session, create sessions, update  and remove
	 * 		-  adding the session values
	 *      TODO : can be used more widly
	 *
	 *
	 */
	class Mycart extends CI_Cart
	{


		function __construct ()
		{
			parent::__construct ();
			//$this->load->library('session');
			// Adding commas, quotes and parenthesis to product names
			$this->product_name_rules = '\,\(\)\"\'\.\:\-_ a-z0-9\/&';

		}

		public function make_suk ($product_id,$id)
		{
			return (int)$product_id.'-sep-'.(int)$id;
		}



		function update_all ($items = array ())
		{

			if (!is_array ($items) OR count ($items) == 0)// Was any cart data passed?
			{
				return false;
			}

			// You can either update a single product using a one-dimensional array,
			// or multiple products using a multi-dimensional one.
			// The way we determine the array type is by looking for a required array key named "rowid".
			// If it's not found we assume it's a multi-dimensional array
			if (isset($items[ 'rowid' ]))
			{
				$this->_update_item ($items);
			} else
			{
				foreach ($items as $item)
				{
					$this->_update_item ($item);
				}
			}
			$this->_save_cart ();
		}

		/*
		 * Function: _update_item
		 * Param: Array with a rowid and information about the item to be updated
		 * 			such as qty, name, price, custom fields.
		 */
		function _update_item ($item)
		{
			foreach ($item as $key => $value)
			{
				if ($key == 'rowid')
				{//don't allow them to change the rowid
					continue;
				}
				//do some processing if qty is updated since it has strict requirements
				if ($key == "qty")
				{
					$item[ 'qty' ] = preg_replace ('/([^0-9])/i', '', $item[ 'qty' ]);
					if (!is_numeric ($item[ 'qty' ]))
					{
						continue;
					}
					// Is the new quantity different than what is already saved in the cart?
					if ($this->_cart_contents[ $item[ 'rowid' ] ][ 'qty' ] == $item[ 'qty' ])
					{
						continue;
					}
					// Is the quantity zero?  If so we will remove the item from the cart.
					if ($item[ 'qty' ] == 0)
					{
						unset($this->_cart_contents[ $item[ 'rowid' ] ]);
						continue;
					}
				}
				$this->_cart_contents[ $item[ 'rowid' ] ][ $key ] = $value;
			}
		}

		//is this product in the cart?
		// pass the product id
		// returns the  product id specific cart session value
		public function in_cart ($id = null)
		{   
                                        
			if ($this->total_items () > 0)
			{
				$in_cart = array ();
				// Fetch data for all products in cart
				foreach ($this->contents () AS $item)
				{
					$in_cart[ $item[ 'id' ] ] = $item;
				}

				if ($id)
				{
					if (array_key_exists ($id, $in_cart))
					{
						return $in_cart[ $id ];
					}

					return null;

				} else
				{
					return $in_cart;
				}
			}

			return null;
		}

		// Decorative patter approach
		public function contents ()
		{
			return parent::contents();
		}

		// Decorative approch
		public function completecontents ()
		{
                  /*Added this line from Esparkbiz to get total USD price in Cart*/
                   // $this->chintan_save_cart();

                  return parent::completecontents();

		}

		public  function save_to_cart($name,$data)
		{ 
                  
			$total = $this->all_item_count();
			if($total > 0)
			{
				$cartcontent = $this->CI->session->userdata('cart_contents');
                                
				$cartcontent[$name]= $data;
				$this->CI->session->set_userdata(array('cart_contents' => $cartcontent));
				return true;

			}else
			{
				return false; // no cart items DONT ADD !!!
			}

		}

		public function update_cart($items){

			//$items = array('id'=>2,'qty'=>3); example input you can update anything
			if(array_key_exists('id', $items) == false ){
				return false;// should conatain product id
			}

			$result = $this->in_cart($items['id']);
					if(!empty($result)){
						$items['rowid'] = $result['rowid'];
					  return $this->update_all($items); // returns true or false
					}else{
						return false; // product not found in cart
					}

		}


		/**
		 *  Removes all Items or  particular product id
		 * @param null $id
		 * @return bool
		 */
		public function remove ($id=NULL)
		{
			if(!empty($id)){
				$return = $this->in_cart($id);

				if(!empty($return)){
					$this->_update_item(array('rowid' => $return[ 'rowid' ],'qty'=>0)); // removing  simgle item

				}else{
					return false;
				}
			}else{
				 $this->destroy();// Remove all items
			}

			return true;
		}



		//count all items including multiples of each product
		public function all_item_count ()
		{

			$total = 0;
			if ($this->total_items () > 0)
			{
					foreach ($this->contents () AS $item)
				{
					$total = $item[ 'qty' ] + $total;
				}
			}

			return $total;
		}

		/**
		 * chek if its valid function
		 * @return bool
		 */
		public function is_cart_valid()
		{
			if($this->total_items() > 0)
			{
				return true;

			}else
			{
				return false;
			}
		}
                
	}