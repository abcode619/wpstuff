<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
class Westpac {
	var $customer_id;
	var $password;
	var $mode;
	
	var $gateway;

	function __construct() {

		if (!defined('WESTPAC_CUSTOMER_ID')) die("No configuration found. Please set WESTPAC_CUSTOMER_ID in config/constants.php.");
		if (!defined('WESTPAC_PASSWORD')) die("No configuration found. Please set WESTPAC_PASSWORD in config/constants.php.");
		if (!defined('WESTPAC_MODE')) die("No configuration found. Please set WESTPAC_MODE in config/constants.php.");
		if (!in_array(WESTPAC_MODE, array('live', 'test')))
			die ("Invalid value for WESTPAC_MODE: ".WESTPAC_MODE.". Allowed values: live, test.");

		$this->customer_id = WESTPAC_CUSTOMER_ID;
		$this->password = WESTPAC_PASSWORD;
		$this->mode = WESTPAC_MODE;
		$this->gateway = "https://whatever.com.au/";
	}
	
	function pay($amount, $card_no, $card_expiry, $card_cvv, $order_no) {
		if (!preg_match('!^[0-9]{16}$!', $card_no))
			return "Invalid Card number";
		return "Westpac payment is not implemented yet";
	}
	
	//Send XML Transaction Data and receive XML response
	function http_post($postdata) {
		$ch = curl_init($this->gateway);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			   
		$xmlResponse = curl_exec($ch);
		
		if (curl_errno($ch) == CURLE_OK)
			return $xmlResponse;
		return false;
	}
}

?>
