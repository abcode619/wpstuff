<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
class Nab {
	var $customer_id;
	var $password;
	var $mode;

	var $gateway;

	function __construct($settings) {
            
		if (!in_array(PAYMENT_MODE, array('live', 'test')))
			die ("Invalid value for NAB_MODE: ".PAYMENT_MODE.". Allowed values: live, test.");

		$this->customer_id =  $settings->username;
		$this->password = $settings->password;
		$this->mode = PAYMENT_MODE;
		$this->gateway = "https://transact.nab.com.au/{$this->mode}/xmlapi/payment";
	}

	function pay($amount, $card_no, $card_expiry, $card_cvv, $order_no) {
		$amount = intval($amount)*100;
		if (!preg_match('!^[0-9]{16}$!', $card_no))
			return "Invalid Card number";

		$xmlRequest = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>
			<NABTransactMessage>
				<MessageInfo>
					<messageID>".md5(mktime())."</messageID>
					<messageTimestamp>".date("YdmHis")."000000+660</messageTimestamp>
					<timeoutValue>60</timeoutValue>
					<apiVersion>xml-4.2</apiVersion>
				</MessageInfo>
				<MerchantInfo><merchantID>{$this->customer_id}</merchantID><password>{$this->password}</password>
				</MerchantInfo>
				<RequestType>Payment</RequestType>
				<Payment>
					<TxnList count=\"1\">
						<Txn ID=\"1\">
							<txnType>0</txnType>
							<txnSource>23</txnSource>
							<amount>$amount</amount>
							<currency>AUD</currency>
							<purchaseOrderNo>$order_no</purchaseOrderNo>
							<CreditCardInfo>
								<cardNumber>$card_no</cardNumber>
								<expiryDate>$card_expiry</expiryDate>
								<cvv>$card_cvv</cvv>
								<cardType></cardType>
							</CreditCardInfo>
						</Txn>
					</TxnList>
				</Payment>
			</NABTransactMessage>";

		$xmlResponse = $this->sendRequest($xmlRequest);

		if (!empty($xmlResponse)) {
			$res = $this->parseResponse($xmlResponse);

			if ($res['STATUSCODE'] === '000')
				return true;

			if (isset($res['STATUSDESCRIPTION']) && !empty($res['STATUSDESCRIPTION']))
				return $res['STATUSDESCRIPTION'];

			return "Unknown error";
		} else {
			return "Error in XML response from eWAY: " + $xmlResponse;
		}
	}

	//Send XML Transaction Data and receive XML response
	function sendRequest($xmlRequest) {
		$ch = curl_init($this->gateway);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlRequest);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$xmlResponse = curl_exec($ch);

		if (curl_errno($ch) == CURLE_OK)
			return $xmlResponse;
		return false;
	}


	//Parse XML response from eway and place them into an array
	private function parseResponse($xmlResponse){
		$xml_parser = xml_parser_create();
		xml_parse_into_struct($xml_parser,  $xmlResponse, $xmlData, $index);
		$responseFields = array();

		foreach ($xmlData as $data)
			$responseFields[$data['tag']] = isset($data['value']) ? $data['value'] : '';

		return $responseFields;
	}
}

?>
