<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */
class Anz {
	var $customer_id;
	var $password;
	var $mode;
	
	var $gateway;

	function __construct() {

		if (!defined('ANZ_CUSTOMER_ID')) die("No configuration found. Please set ANZ_CUSTOMER_ID in config/constants.php.");
		if (!defined('ANZ_PASSWORD')) die("No configuration found. Please set ANZ_PASSWORD in config/constants.php.");
		if (!defined('ANZ_MODE')) die("No configuration found. Please set ANZ_MODE in config/constants.php.");
		if (!in_array(ANZ_MODE, array('live', 'test')))
			die ("Invalid value for ANZ_MODE: ".ANZ_MODE.". Allowed values: live, test.");

		$this->customer_id = ANZ_CUSTOMER_ID;
		$this->password = ANZ_PASSWORD;
		$this->mode = ANZ_MODE;
		$this->gateway = "https://whatever.com.au/";
	}
	
	function pay($amount, $card_no, $card_expiry, $card_cvv, $order_no) {
		if (!preg_match('!^[0-9]{16}$!', $card_no))
			return "Invalid Card number";
		return "ANZ payment is not implemented yet";
	}
	
	//Send XML Transaction Data and receive XML response
	function http_post($postdata) {
		$ch = curl_init($this->gateway);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			   
		$xmlResponse = curl_exec($ch);
		
		if (curl_errno($ch) == CURLE_OK)
			return $xmlResponse;
		return false;
	}
}

?>
