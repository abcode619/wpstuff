<?php
	/**
	 *  Author : jay kora
	 *  Email : kora.jayaram@gmail.com
	 *  Company : Iddigital
	 */

class eway{ //wrapper class

	protected $eway_core;

	function __construct($settings){

	
            $type = (PAYMENT_MODE == 'live')?TRUE:FALSE;
		if(PAYMENT_MODE == 'live'){
			$this->eway_core = new EwayPaymentLive($settings->user_id,'REAL-TIME',$type);
		}else{
			$this->eway_core = new EwayPaymentLive($settings->sandbox_user_id,'REAL-TIME',$type);
		}
	}

	public function add_user_data($user_data){

		foreach($user_data as $key => $value){

			if($key == 'first_name'){	$this->eway_core->setTransactionData('CustomerFirstName',$value);}
			if($key == 'last_name'){	$this->eway_core->setTransactionData('CustomerLastName',$value);}
			if($key == 'email'){		$this->eway_core->setTransactionData('CustomerEmail',$value);	}
			if($key == 'address'){		$this->eway_core->setTransactionData('CustomerAddress',$value);	}
			if($key == 'postcode'){		$this->eway_core->setTransactionData('CustomerPostcode',$value);}
			if($key == 'name_on_card'){	$this->eway_core->setTransactionData('CardHoldersName',$value);	}
		}
	}

	public function pay($total, $cc_no, $cc_expiry_month_year, $cc_cvv, $order_no){                
            
		$expiry = explode('/', $cc_expiry_month_year);
		$customer_ip = $this->eway_core->getVisitorIP();

		//convert dollars to cents
		$total_in_cents = $total * 100;

		//$total_in_cents += 5;

		$this->eway_core->setTransactionData('TotalAmount',$total_in_cents);
		$this->eway_core->setTransactionData('CardNumber',$cc_no);
		$this->eway_core->setTransactionData('CardExpiryMonth',$expiry[0]);
		$this->eway_core->setTransactionData('CardExpiryYear',$expiry[1]);
		$this->eway_core->setTransactionData('CVN',$cc_cvv);
		$this->eway_core->setTransactionData('TrxnNumber',$order_no);
		$this->eway_core->setTransactionData('CustomerBillingCountry','Australia');
		$this->eway_core->setTransactionData('CustomerInvoiceRef',$order_no);
		$this->eway_core->setTransactionData('CustomerIPAddress',$customer_ip);
		$this->eway_core->setTransactionData('CustomerInvoiceDescription',"Order placed with Orgone Energy");

		//Optional fields
		$this->eway_core->setTransactionData('Option1','');
		$this->eway_core->setTransactionData('Option2','');
		$this->eway_core->setTransactionData('Option3','');

		//Do it!
		$response = $this->format_response($this->eway_core->doPayment());
		return $response;
	}

	protected function format_response($response_array){

		$response = array('success'=>FALSE,'eway_transaction_id'=>'NULL','response'=>"There was an issue with the EWAY transaction");

		if($response_array["EWAYTRXNSTATUS"]=="False"){

			$response['success'] = FALSE;
			$response['eway_transaction_id'] = 'NULL';
			$response['response'] = "There was an issue processing your transaction, please try again";
			$response['response'] .= "<br />Transaction Error: ".$response_array["EWAYTRXNERROR"];

		}else if($response_array["EWAYTRXNSTATUS"]=="True"){

			$response['success'] = TRUE;
			$response['eway_transaction_id'] = $response_array['EWAYTRXNNUMBER'];
			$response['response'] = "Transaction success, thankyou for your order.";

		}else{

			$response['success'] = FALSE;
			$response['eway_transaction_id'] = 'NULL';
			$response['response'] = "Please try again later, the eWAY payment system undergoing maintenance";
		}

		return $response;
	}
}


class EwayPaymentLive {

	var $myGatewayURL;
	var $myCustomerID;
	var $myTransactionData = array();
	var $myCurlPreferences = array();

	//Class Constructor
	function __construct($customerID='',$method='REAL-TIME',$liveGateway=TRUE) {

		$this->myCustomerID = $customerID;

		switch($method){

			case 'REAL-TIME':
				if($liveGateway){
					$this->myGatewayURL = 'https://www.eway.com.au/gateway/xmlpayment.asp';
				}else{
					$this->myGatewayURL = 'https://www.eway.com.au/gateway/xmltest/testpage.asp';
				}
			break;

			case 'REAL-TIME-CVN':
				if($liveGateway){
					$this->myGatewayURL = 'https://www.eway.com.au/gateway_cvn/xmlpayment.asp';
				}else{
					$this->myGatewayURL = 'https://www.eway.com.au/gateway_cvn/xmltest/testpage.asp';
				}
			break;

			case 'GEO-IP-ANTI-FRAUD':
				if($liveGateway){
					$this->myGatewayURL = 'https://www.eway.com.au/gateway_beagle/xmlbeagle.asp';
				}else{//in testing mode process with REAL-TIME
					$this->myGatewayURL = 'https://www.eway.com.au/gateway_beagle/test/xmlbeagle_test.asp';
				}
			break;

			default:
				if($liveGateway){
					$this->myGatewayURL = 'https://www.eway.com.au/gateway/xmlpayment.asp';
				}else{
					$this->myGatewayURL = 'https://www.eway.com.au/gateway/xmltest/testpage.asp';
				}
			break;
		}
	}


	//Payment Function
	function doPayment() {
		$xmlRequest = "<ewaygateway><ewayCustomerID>" . $this->myCustomerID . "</ewayCustomerID>";
		foreach($this->myTransactionData as $key=>$value){
			$xmlRequest .= "<$key>$value</$key>";
		}
		$xmlRequest .= "</ewaygateway>";
		// header("Content-Type: text/xml");
		// echo $xmlRequest;
		// die;
		$xmlResponse = $this->sendTransactionToEway($xmlRequest);

		if($xmlResponse!=""){
			return $this->parseResponse($xmlResponse);
		}else{
			die("Error in XML response from eWAY");
		}
	}

	//Send XML Transaction Data and receive XML response
	function sendTransactionToEway($xmlRequest) {

		$ch = curl_init($this->myGatewayURL);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xmlRequest);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		foreach($this->myCurlPreferences as $key=>$value){
			curl_setopt($ch, $key, $value);
		}

		$xmlResponse = curl_exec($ch);

		if(curl_errno($ch) == CURLE_OK){
			return $xmlResponse;
		}
		return '';
	}

	//Parse XML response from eway and place them into an array
	function parseResponse($xmlResponse){
		$xml_parser = xml_parser_create();
		xml_parse_into_struct($xml_parser, $xmlResponse, $xmlData, $index);
		$responseFields = array();
		// print_r($xmlData);
		// exit;
		foreach($xmlData as $data){
			if($data["level"] == 2 && isset($data["value"])){
				$responseFields[$data["tag"]] = $data["value"];
			}
		}

		return $responseFields;
	}

	function setTransactionData($field, $value) {
		$this->myTransactionData["eway" . $field] = htmlentities(trim($value));
	}

	//receive special preferences for Curl
	function setCurlPreferences($field, $value) {
		$this->myCurlPreferences[$field] = $value;
	}

	//obtain visitor IP even if is under a proxy
	function getVisitorIP(){

		$ip = $_SERVER["REMOTE_ADDR"];

		if(isset($_SERVER["HTTP_X_FORWARDED_FOR"])){
			$proxy = $_SERVER["HTTP_X_FORWARDED_FOR"];
			if(ereg("^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$",$proxy)){
				$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
			}
		}

		return $ip;
	}
}