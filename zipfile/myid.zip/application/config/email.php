<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Email
| -------------------------------------------------------------------------
| This file lets you define parameters for sending emails.
| Please see the user guide for info:
|
|	http://codeigniter.com/user_guide/libraries/email.html
|
*/


$config['mailtype'] = 'html';
$config['charset'] = 'utf-8';
$config['newline'] = "\r\n";


if(ACTIVE_GROUP =='LOCAL'){

	$config['protocol'] = 'smtp';
	$config['smtp_host']  = 'mailtrap.io';
	$config['smtp_port']  = 2525;
	$config['smtp_user']  = '334725d153cd14a16';
	$config['smtp_pass']  = '43245660ca2a54';
	$config['crlf']  = "\r\n";


}else{


	$config['protocol']  = 'smtp';
	$config['smtp_host'] = 'mailtrap.io';
	$config['smtp_port'] = 2525;
	$config['smtp_user'] = '334725d153cd14a16';
	$config['smtp_pass'] = '43245660ca2a54';
	$config['crlf']      = "\r\n";


}


/* End of file email.php */
/* Location: ./application/config/email.php */