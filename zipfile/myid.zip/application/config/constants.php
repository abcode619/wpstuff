<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);
//	 Not used
define("AUS_TO_US_DOLLAR", 0.88);
define("WHOLESALER_DISCOUNT", 30); // in percentage
define("REFERRAL_PERCENTAGES", 2.00); // in percentage

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/

define('FOPEN_READ',							'rb');
define('FOPEN_READ_WRITE',						'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE',		'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE',	'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE',					'ab');
define('FOPEN_READ_WRITE_CREATE',				'a+b');
define('FOPEN_WRITE_CREATE_STRICT',				'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT',		'x+b');

// DO NOT INCLUDE HTTP FOR HOSTS
define('SITE_TITLE', '4 Step Cart');
define('GOOGLE_TRACKER_ON', FALSE);
define('GOOGLE_TRACKER_KEY', '');

// MAILCHIMP
define('APIKEY', '');
define('LISTID', '');

// LIVE DEBUG SETTINGS
define('OFFICE_IPADDRESS','60.241.199.168');

// HOST SETTINGS
define('LOCAL_HOST', 'basemyid');
define('PREFLIGHT_HOST', 'myidcart2015');
define('LIVE_HOST', 'xxxx.com');
/* -------------------------------- */

$host = preg_replace('!^(m|www)\.!', '', $_SERVER['HTTP_HOST']);

switch($host) {

//	case (preg_match("/".LOCAL_HOST."\.(.*)\.dev/", $host, $match) ? true : false):
	case (preg_match("/".LOCAL_HOST."/", $host, $match) ? true : false):
		define('ACTIVE_GROUP', 'local');
		define('ENVIRONMENT', 'development');
//		define('SITE_EMAIL', $match[1] . '@iddigital.com.au');
		define('SITE_EMAIL', 'jaykay@idgitial.com.au');
		define('PAYMENT_MODE','testing');
	break;

	case PREFLIGHT_HOST:
		define('ACTIVE_GROUP', 'preflight');
		define('ENVIRONMENT', 'development');
		define('SITE_EMAIL', 'jay@iddigital.com.au');
		define('PAYMENT_MODE','testing');
		define('SITE_NOREPLY_EMAIL','support@iddigital.com.au');
	break;

	case LIVE_HOST:
		define('ACTIVE_GROUP', 'live');
		define('ENVIRONMENT', 'production');
		define('SITE_EMAIL', 'sales@orgoneenergy.com');
		define('PAYMENT_MODE','live'); // testing
	break;

	default:
		die('Host not found. check constants file');
	break;

}

// SITE DETAILS
define('SITE_NAME', 'myidcart2015 ');
define('SITE_PHONE', 'xxxxxxxxx');
define('SITE_FAX', '03 9999 9998');
define('SITE_ADDRESS', 'xxxxxx');
define('SITE_SUPPORT_EMAIL', 'support@iddigital.com.au');

/* End of file constants.php */
/* Location: ./application/config/constants.php */
