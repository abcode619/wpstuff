mkdir myid/temp resources resources/redactor uploads tt/cache assets/cache
chmod 777 -R myid/temp resources uploads tt/cache assets/cache
touch robots.txt
chmod 777 robots.txt
echo "Permissions are updated !!!"
echo " run ./fresh.sh  if its a fresh Installation to updated git remote url"
echo  " run  this for  ftyc cp ./vendor/maoosi/frontyc/compiler/ftyc.sh ftyc.sh ; chmod 0777 ftyc.sh ; ./ftyc.sh"

