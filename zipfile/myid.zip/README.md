Readme file.
---------------------

Coding Standards :

Migration Folder :
 will always  have latest changes done to Db structure.





Fresh project Installation please run the following commands

once  you  have grab the project to  your repo 
run 
./setup.sh ( This  will create necessay  files and will give relevant
premissions to folders )
./fresh.sh ( This will allow you change  you current project repo
remote origin url )

# MYID CART 2015 

MYID cart is a Codeigniter HMVC module developed with minimum dependency of codeigniter custome class 

## Includes 
- HMVC SHOP module 
- Ion auth Libiary 
- MYID 

### Ion Auth 

 This is Codeigniter basic auth library  [Docs link](http://benedmunds.com/ion_auth/)
 
 What  have you got it repo : 
  folder - application / config / ion_auth.php - for basic configuration
  folder- application  / controlles / Auth  - all contollers for auth functions 
  folder- application / models / ino_auth_model.php - db operations 
  and lib installs with Bcrypt dependency 
  
  
### MYID Cart
	
	This custom build cart application for specific projects - readme file in  applications / modules /  shop readme.txt
	
	 you need to  edit config  file - in shop / config  file 
	 
	 Any views regarding shop should be done in the shop / view folder -  please dont remove any classes  as this break ajax  cart.
	
	  Any Questions  contact jaikay@iddigital.com  or Kora.jayaram@gmail.com
