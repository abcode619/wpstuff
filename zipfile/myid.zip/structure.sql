# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: localhost (MySQL 5.5.33)
# Database: myidcart_2015
# Generation Time: 2014-09-26 06:46:21 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table ci_sessions
# ------------------------------------------------------------

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `last_activity_idx` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

LOCK TABLES `ci_sessions` WRITE;
/*!40000 ALTER TABLE `ci_sessions` DISABLE KEYS */;

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`)
VALUES
	('d46935cae029ea03f16cd9e26ffba685','127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36',1411713530,'a:4:{s:9:\"user_data\";s:0:\"\";s:4:\"user\";s:1:\"1\";s:8:\"username\";s:9:\"Developer\";s:10:\"user_level\";s:2:\"10\";}');

/*!40000 ALTER TABLE `ci_sessions` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table map
# ------------------------------------------------------------

DROP TABLE IF EXISTS `map`;

CREATE TABLE `map` (
  `map_table_a` varchar(25) DEFAULT NULL,
  `map_id_a` int(10) DEFAULT NULL,
  `map_table_b` varchar(25) DEFAULT NULL,
  `map_id_b` int(10) DEFAULT NULL,
  KEY `map_table_a_map_id_a` (`map_table_a`,`map_id_a`),
  KEY `map_table_b_map_id_b` (`map_table_b`,`map_id_b`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



# Dump of table modules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `modules`;

CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `status` enum('enabled','disabled') NOT NULL,
  `updated_date` datetime DEFAULT NULL,
  `visibility` enum('visible','invisible','nav') NOT NULL DEFAULT 'visible',
  `parent` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `user_level` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;

INSERT INTO `modules` (`id`, `name`, `url`, `status`, `updated_date`, `visibility`, `parent`, `created_date`, `order_index`, `user_level`)
VALUES
	(1,'* myid Modules','module','enabled','2014-09-26 16:39:43','nav',0,'2013-01-15 14:22:32',0,'10'),
	(16,'Site Settings ','setting','enabled','2014-09-26 16:39:43','visible',0,'2014-04-30 15:38:46',4,'1'),
	(17,'Users','myiduser','enabled','2014-05-07 10:43:22','nav',0,'2014-04-30 16:01:04',5,'9');

/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table quick_links
# ------------------------------------------------------------

DROP TABLE IF EXISTS `quick_links`;

CREATE TABLE `quick_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) NOT NULL,
  `page` varchar(255) NOT NULL,
  `clicks` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `url` (`url`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `quick_links` WRITE;
/*!40000 ALTER TABLE `quick_links` DISABLE KEYS */;

INSERT INTO `quick_links` (`id`, `url`, `page`, `clicks`)
VALUES
	(1,'modules/module/add','Modules &gt; Add',2),
	(3,'modules/module/edit','Modules &gt; Edit',7),
	(6,'modules/setting/add','Settings &gt; Add',3);

/*!40000 ALTER TABLE `quick_links` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table sample
# ------------------------------------------------------------

DROP TABLE IF EXISTS `sample`;

CREATE TABLE `sample` (
  `sample_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` mediumint(5) DEFAULT NULL,
  PRIMARY KEY (`sample_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `username`, `password`, `user_level`, `full_name`)
VALUES
	(1,'development','759b74ce43947f5f4c91aeddc3e5bad3',10,'Developer');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users_myid
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users_myid`;

CREATE TABLE `users_myid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_level` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  `order_index` int(11) NOT NULL DEFAULT '0',
  `email` varchar(255) DEFAULT NULL,
  `status` enum('1','0') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `users_myid` WRITE;
/*!40000 ALTER TABLE `users_myid` DISABLE KEYS */;

INSERT INTO `users_myid` (`id`, `username`, `password`, `user_level`, `full_name`, `created_date`, `updated_date`, `order_index`, `email`, `status`)
VALUES
	(1,'development','5f4dcc3b5aa765d61d8327deb882cf99',10,'Developer',NULL,NULL,0,NULL,NULL),
	(2,'mainuser','8aa0606b7e3547a234c80fc3017fae97',9,'Main user','2014-05-06 16:11:02','2014-05-06 16:47:56',0,'mainuser@iddigital.com',NULL),
	(11,'testing','ae2b1fca515949e5d54fb22b8ed95575',8,'testing','2014-05-07 10:33:03','2014-05-07 10:33:23',0,'testing@gmail.com',NULL),
	(14,'test','098f6bcd4621d373cade4e832627b4f6',8,'test','2014-05-07 10:43:22','2014-05-07 10:43:22',1,'test@gmail.com',NULL);

/*!40000 ALTER TABLE `users_myid` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
